[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
$AppRoot=$PSScriptRoot
try{
    $dpiSource=@'
using System;
using System.Runtime.InteropServices;
public static class NyxDpiAwareness {
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr value);
}
'@
    Add-Type -TypeDefinition $dpiSource -ErrorAction SilentlyContinue
    try{[NyxDpiAwareness]::SetProcessDpiAwarenessContext([IntPtr](-4))|Out-Null}catch{}
    Add-Type -AssemblyName System.Windows.Forms
    $created=$false
    $mutex=[Threading.Mutex]::new($true,'Local\DietrichAI.NyxPCCheckup.v1',[ref]$created)
    if(-not $created){[Windows.Forms.MessageBox]::Show('Nyx PC Checkup is already open for this Windows user.','Nyx PC Checkup','OK','Information')|Out-Null;exit 0}
    Import-Module (Join-Path $AppRoot 'core\Diagnostics.psm1') -Force
    Import-Module (Join-Path $AppRoot 'ui\MainWindow.psm1') -Force
    Write-NyxLog -Level 'INFO' -Message 'Nyx PC Checkup started.'
    Show-NyxMainWindow
    Write-NyxLog -Level 'INFO' -Message 'Nyx PC Checkup closed.'
    $mutex.ReleaseMutex();$mutex.Dispose()
}catch{
    try{Import-Module (Join-Path $AppRoot 'core\Diagnostics.psm1') -Force;Write-NyxLog -Level 'ERROR' -Message ("Unhandled application error: {0}" -f $_.Exception.ToString())}catch{}
    try{Add-Type -AssemblyName System.Windows.Forms;[Windows.Forms.MessageBox]::Show("Nyx PC Checkup could not continue.`r`n`r`n$($_.Exception.Message)`r`n`r`nNo changes were made to this computer.",'Nyx PC Checkup','OK','Error')|Out-Null}catch{}
    exit 1
}
