Set-StrictMode -Version 2.0

function Get-NyxDataRoot {
    $base = $env:LOCALAPPDATA
    if ([string]::IsNullOrWhiteSpace($base)) {
        $base = [Environment]::GetFolderPath('LocalApplicationData')
    }
    if ([string]::IsNullOrWhiteSpace($base)) { throw 'Windows did not provide a local application-data folder.' }
    return (Join-Path $base 'Dietrich AI Labs\Nyx PC Checkup')
}

function Get-NyxPathMap {
    $root = Get-NyxDataRoot
    return [pscustomobject][ordered]@{
        Root = $root
        Config = Join-Path $root 'config.json'
        Logs = Join-Path $root 'logs'
        Scans = Join-Path $root 'scans'
        Actions = Join-Path $root 'actions'
        ActionHistory = Join-Path $root 'actions\history.jsonl'
        DisabledStartup = Join-Path $root 'actions\disabled-startup'
        Reports = Join-Path $root 'reports'
        Temp = Join-Path $root 'temp'
        LastScan = Join-Path $root 'scans\last-scan.json'
    }
}

function Assert-NyxOrdinaryDataDirectory {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    if (-not $item.PSIsContainer) { throw "The Nyx local-data path is not a directory: $Path" }
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "The Nyx local-data directory cannot be a junction or symbolic link: $Path"
    }
    return $item
}

function Initialize-NyxDataDirectories {
    $paths = Get-NyxPathMap
    @($paths.Root,$paths.Logs,$paths.Scans,$paths.Actions,$paths.DisabledStartup,$paths.Reports,$paths.Temp) | ForEach-Object {
        if (-not (Test-Path -LiteralPath $_)) {
            New-Item -ItemType Directory -Path $_ -Force -ErrorAction Stop | Out-Null
        }
        [void](Assert-NyxOrdinaryDataDirectory -Path $_)
    }
    return $paths
}

function Get-NyxInstallRoot {
    param([string]$ScriptRoot)
    return (Resolve-Path (Join-Path $ScriptRoot '..\..')).Path
}

Export-ModuleMember -Function Get-NyxDataRoot,Get-NyxPathMap,Assert-NyxOrdinaryDataDirectory,Initialize-NyxDataDirectories,Get-NyxInstallRoot
