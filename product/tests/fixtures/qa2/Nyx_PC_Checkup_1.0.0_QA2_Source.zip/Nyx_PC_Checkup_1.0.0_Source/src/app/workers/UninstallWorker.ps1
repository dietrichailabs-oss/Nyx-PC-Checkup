[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$InstallRoot,[int]$Confirmed=0,[int]$Quiet=0,[int]$PurgeData=0)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
Add-Type -AssemblyName System.Windows.Forms
$expected=Join-Path $env:LOCALAPPDATA 'Programs\Dietrich AI Labs\Nyx PC Checkup'
try{$actualFull=[IO.Path]::GetFullPath($InstallRoot).TrimEnd('\');$expectedFull=[IO.Path]::GetFullPath($expected).TrimEnd('\')}catch{exit 2}
if(-not [string]::Equals($actualFull,$expectedFull,[StringComparison]::OrdinalIgnoreCase)){[Windows.Forms.MessageBox]::Show('The uninstall location failed its safety boundary check. Nothing was removed.','Nyx PC Checkup Uninstaller','OK','Error')|Out-Null;exit 2}
$InstallRoot=$actualFull
try{
    $installItem=Get-Item -LiteralPath $InstallRoot -Force -ErrorAction Stop
    if(-not $installItem.PSIsContainer -or (($installItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)){throw 'The installation directory is not an ordinary directory.'}
}catch{if($Quiet -ne 1){[Windows.Forms.MessageBox]::Show('The uninstall location is missing, invalid, or reparse-backed. Nothing was removed.','Nyx PC Checkup Uninstaller','OK','Error')|Out-Null};exit 2}
$AppRoot=Join-Path $InstallRoot 'app'
try{
    $appItem=Get-Item -LiteralPath $AppRoot -Force -ErrorAction Stop
    if(-not $appItem.PSIsContainer -or (($appItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)){throw 'The application directory is not ordinary.'}
}catch{if($Quiet -ne 1){[Windows.Forms.MessageBox]::Show('The application directory failed its safety boundary check. Nothing was removed.','Nyx PC Checkup Uninstaller','OK','Error')|Out-Null};exit 2}
Import-Module (Join-Path $AppRoot 'actions\StartupActions.psm1') -Force
Import-Module (Join-Path $AppRoot 'core\ActionHistory.psm1') -Force
Import-Module (Join-Path $AppRoot 'core\Paths.psm1') -Force
if($Confirmed -ne 1 -and $Quiet -ne 1){
    $answer=[Windows.Forms.MessageBox]::Show('Uninstall Nyx PC Checkup? Reversible startup changes made by Nyx will be restored first.','Nyx PC Checkup Uninstaller','YesNo','Question')
    if($answer -ne [Windows.Forms.DialogResult]::Yes){exit 0}
}
$active=@(Get-NyxActiveStartupDisables)
$needsAdmin=$false
foreach($entry in $active){try{$state=Unprotect-NyxState -ProtectedText ([string]$entry.ProtectedState);if([bool]$state.RequiresElevation){$needsAdmin=$true}}catch{}}
if($needsAdmin -and -not(Test-NyxAdministrator)){
    if($Quiet -ne 1){[Windows.Forms.MessageBox]::Show('Administrator approval is required only to restore an all-users startup entry before uninstalling.','Nyx PC Checkup','OK','Information')|Out-Null}
    $args="-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -InstallRoot `"$InstallRoot`" -Confirmed 1 -Quiet $Quiet -PurgeData $PurgeData"
    try{$p=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $args -Verb RunAs -Wait -PassThru;exit $p.ExitCode}catch{exit 5}
}
$restores=@(Restore-AllNyxStartupApplications -Confirmed)
$failed=@($restores|Where-Object{-not $_.Success})
if($failed.Count -gt 0){
    if($Quiet -ne 1){[Windows.Forms.MessageBox]::Show('One or more startup entries could not be restored. Uninstall was stopped before removing the application, shortcuts, registration, or local recovery data. Resolve the displayed startup conflict and run uninstall again.','Nyx PC Checkup Uninstaller','OK','Warning')|Out-Null}
    exit 6
}
$paths=Get-NyxPathMap
$removeData=$false
if($PurgeData -eq 1){
    $removeData=$true
}elseif($Quiet -ne 1){
    $dataAnswer=[Windows.Forms.MessageBox]::Show('Also remove local settings, logs, scan history, and action history?','Nyx PC Checkup Uninstaller','YesNo','Question')
    $removeData=($dataAnswer -eq [Windows.Forms.DialogResult]::Yes)
}
Remove-Item -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\NyxPCCheckup' -Recurse -Force -ErrorAction SilentlyContinue
$startFolder=Join-Path ([Environment]::GetFolderPath('Programs')) 'Dietrich AI Labs'
$start=Join-Path $startFolder 'Nyx PC Checkup.lnk'
Remove-Item -LiteralPath $start -Force -ErrorAction SilentlyContinue
try{if((Test-Path -LiteralPath $startFolder -PathType Container) -and @(Get-ChildItem -LiteralPath $startFolder -Force -ErrorAction Stop).Count -eq 0){Remove-Item -LiteralPath $startFolder -Force -ErrorAction Stop}}catch{}
$desktop=Join-Path ([Environment]::GetFolderPath('Desktop')) 'Nyx PC Checkup.lnk'
Remove-Item -LiteralPath $desktop -Force -ErrorAction SilentlyContinue
$commands=New-Object System.Collections.Generic.List[string]
$commands.Add('ping 127.0.0.1 -n 3 >nul')
$commands.Add("rmdir /s /q `"$InstallRoot`"")
if($removeData){$commands.Add("rmdir /s /q `"$($paths.Root)`"")}
Start-Process -FilePath "$env:SystemRoot\System32\cmd.exe" -ArgumentList ('/d /c '+($commands -join ' & ')) -WindowStyle Hidden
exit 0
