Set-StrictMode -Version 2.0

function Protect-NyxText {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$InputObject,
        [switch]$IncludeUserName,
        [switch]$IncludeIpAddresses
    )
    if ($null -eq $InputObject) { return $null }
    $text = [string]$InputObject

    $userProfile = $env:USERPROFILE
    if (-not [string]::IsNullOrWhiteSpace($userProfile)) {
        $text = $text.Replace($userProfile, '%USERPROFILE%')
    }
    if (-not $IncludeUserName -and -not [string]::IsNullOrWhiteSpace($env:USERNAME)) {
        $text = $text -replace [regex]::Escape($env:USERNAME), '[USER]'
    }
    if (-not $IncludeIpAddresses) {
        $text = $text -replace '(?<!\d)(?:\d{1,3}\.){3}\d{1,3}(?!\d)', '[IP REDACTED]'
        $text = $text -replace '(?i)(?:[a-f0-9]{1,4}:){2,7}[a-f0-9]{1,4}', '[IP REDACTED]'
    }
    $text = $text -replace '(?i)(authorization\s*[:=]\s*)(bearer\s+)?[^\s;,]+', '$1[REDACTED]'
    $text = $text -replace '(?i)((?:api[_-]?key|token|password|secret)\s*[:=]\s*)[^\s;,]+', '$1[REDACTED]'
    $text = $text -replace '(?i)([A-Z0-9._%+-]+)@([A-Z0-9.-]+\.[A-Z]{2,})', '[EMAIL REDACTED]'
    return $text
}

function Protect-NyxObject {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][object]$InputObject,
        [switch]$IncludeUserName,
        [switch]$IncludeIpAddresses
    )
    $json = $InputObject | ConvertTo-Json -Depth 12
    $safe = Protect-NyxText -InputObject $json -IncludeUserName:$IncludeUserName -IncludeIpAddresses:$IncludeIpAddresses
    return ($safe | ConvertFrom-Json)
}

function Get-NyxPrivacyStatement {
    return 'Privacy: Everything analyzed by PC Checkup stays on this computer unless you explicitly export it.'
}

Export-ModuleMember -Function Protect-NyxText,Protect-NyxObject,Get-NyxPrivacyStatement
