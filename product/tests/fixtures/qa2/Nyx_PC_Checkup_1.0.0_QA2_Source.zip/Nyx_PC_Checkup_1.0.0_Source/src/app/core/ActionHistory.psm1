Set-StrictMode -Version 2.0
Import-Module (Join-Path $PSScriptRoot 'Paths.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Configuration.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Privacy.psm1') -Force

function Protect-NyxState {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][object]$State)
    Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
    $json = $State | ConvertTo-Json -Depth 10 -Compress
    $plain = [Text.Encoding]::UTF8.GetBytes($json)
    $entropy = [Text.Encoding]::UTF8.GetBytes('DietrichAI.NyxPCCheckup.v1')
    $protected = [Security.Cryptography.ProtectedData]::Protect($plain,$entropy,[Security.Cryptography.DataProtectionScope]::CurrentUser)
    return 'DPAPI1:' + [Convert]::ToBase64String($protected)
}

function Unprotect-NyxState {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$ProtectedText)
    if (-not $ProtectedText.StartsWith('DPAPI1:')) { throw 'Unsupported protected-state format.' }
    Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
    $cipher = [Convert]::FromBase64String($ProtectedText.Substring(7))
    $entropy = [Text.Encoding]::UTF8.GetBytes('DietrichAI.NyxPCCheckup.v1')
    $plain = [Security.Cryptography.ProtectedData]::Unprotect($cipher,$entropy,[Security.Cryptography.DataProtectionScope]::CurrentUser)
    return ([Text.Encoding]::UTF8.GetString($plain) | ConvertFrom-Json)
}

function Get-NyxActionHistory {
    $paths = Initialize-NyxDataDirectories
    if (-not (Test-Path -LiteralPath $paths.ActionHistory)) { return @() }
    $items = New-Object System.Collections.Generic.List[object]
    Get-Content -LiteralPath $paths.ActionHistory -Encoding UTF8 -ErrorAction SilentlyContinue | ForEach-Object {
        if (-not [string]::IsNullOrWhiteSpace($_)) {
            try { $items.Add(($_ | ConvertFrom-Json)) } catch { }
        }
    }
    return @($items)
}

function Add-NyxActionHistory {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][object]$Action)
    $paths = Initialize-NyxDataDirectories
    $config = Get-NyxConfiguration
    $safe = Protect-NyxObject -InputObject $Action -IncludeIpAddresses:$false -IncludeUserName:$false
    Add-Content -LiteralPath $paths.ActionHistory -Value ($safe | ConvertTo-Json -Compress -Depth 10) -Encoding UTF8
    $all = @(Get-NyxActionHistory)
    $limit = [int]$config.actionHistoryLimit
    if ($all.Count -gt $limit) {
        $keep = @($all | Select-Object -Last $limit)
        $keep | ForEach-Object { $_ | ConvertTo-Json -Compress -Depth 10 } | Set-Content -LiteralPath $paths.ActionHistory -Encoding UTF8
    }
}

function Get-NyxActiveStartupDisables {
    # Active reversible startup changes are discovered from the write-ahead
    # rollback journals, not inferred from a best-effort log.  This preserves
    # recovery information even if the process stops between the change and
    # the human-readable history append.
    $paths = Initialize-NyxDataDirectories
    $active = New-Object System.Collections.Generic.List[object]
    try {
        $root=Get-Item -LiteralPath $paths.DisabledStartup -Force -ErrorAction Stop
        if (-not $root.PSIsContainer -or (($root.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) { return @() }
    } catch { return @() }
    Get-ChildItem -LiteralPath $paths.DisabledStartup -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
        $folder=$_
        $actionId = $folder.Name
        if ($actionId -notmatch '^[a-f0-9]{32}$') { return }
        if (($folder.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { return }
        $journal = Join-Path $folder.FullName 'rollback.dpapi'
        try {
            $journalItem=Get-Item -LiteralPath $journal -Force -ErrorAction Stop
            if ($journalItem.PSIsContainer -or (($journalItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) -or $journalItem.Length -gt 1048576) { return }
            $protected = (Get-Content -LiteralPath $journalItem.FullName -Raw -Encoding UTF8 -ErrorAction Stop).Trim()
            if (-not $protected.StartsWith('DPAPI1:')) { return }
            # Decrypt once here so corrupt, oversized, reparse-backed, or
            # wrong-user journals are not presented as reversible actions.
            # Keep only the protected state in the returned record.
            $state = Unprotect-NyxState -ProtectedText $protected
            $active.Add([pscustomobject][ordered]@{
                ActionId=$actionId; ActionType='StartupDisable'; RelatedActionId=''; Success=$true;
                DisplayName=[string]$state.Name; DisplaySource=[string]$state.SourceLabel; UndoAvailable=$true;
                ProtectedState=$protected; Timestamp=$journalItem.LastWriteTimeUtc.ToString('o')
            })
        } catch { }
    }
    return @($active)
}

Export-ModuleMember -Function Protect-NyxState,Unprotect-NyxState,Get-NyxActionHistory,Add-NyxActionHistory,Get-NyxActiveStartupDisables
