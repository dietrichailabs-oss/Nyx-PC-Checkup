Set-StrictMode -Version 2.0
Import-Module (Join-Path $PSScriptRoot '..\core\Paths.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\core\ActionHistory.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\core\Diagnostics.psm1') -Force

function Test-NyxAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-NyxCurrentUserSid {
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    if($null -eq $identity.User){throw 'The current Windows user SID is unavailable.'}
    return [string]$identity.User.Value
}

function New-NyxActionResponse {
    param([bool]$Success,[string]$Status,[string]$Message,[string]$ActionId='', [object]$Details=$null)
    return [pscustomobject][ordered]@{ Success=$Success; Status=$Status; Message=$Message; ActionId=$ActionId; Details=$Details; Timestamp=(Get-Date).ToUniversalTime().ToString('o') }
}

function Get-NyxStartupBoundary {
    $registry = @{
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' = $false
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce' = $false
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run' = $true
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce' = $true
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run' = $true
    }
    $folders = @(
        [pscustomobject]@{ Path=[Environment]::GetFolderPath('Startup'); Elevated=$false },
        [pscustomobject]@{ Path=[Environment]::GetFolderPath('CommonStartup'); Elevated=$true }
    )
    return [pscustomobject]@{ Registry=$registry; Folders=$folders }
}

function Test-NyxStartupStateBoundary {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][object]$State)
    $boundary=Get-NyxStartupBoundary
    if ([string]$State.SourceType -eq 'Registry') {
        $match=$null
        foreach($key in $boundary.Registry.Keys){if([string]::Equals([string]$key,[string]$State.SourcePath,[StringComparison]::OrdinalIgnoreCase)){$match=$key;break}}
        if($null -eq $match){throw 'The startup registry location is outside the Nyx allowlist.'}
        if([string]::IsNullOrWhiteSpace([string]$State.ValueName) -or [string]$State.ValueName -match "[\r\n\x00]"){throw 'The startup registry value name is invalid.'}
        if([bool]$State.RequiresElevation -ne [bool]$boundary.Registry[$match]){throw 'The startup elevation boundary did not match the source location.'}
        return $true
    }
    if ([string]$State.SourceType -eq 'StartupFile') {
        $full=[IO.Path]::GetFullPath([string]$State.SourcePath)
        $parent=[IO.Path]::GetDirectoryName($full)
        foreach($folder in $boundary.Folders){
            if([string]::IsNullOrWhiteSpace([string]$folder.Path)){continue}
            $allowed=[IO.Path]::GetFullPath([string]$folder.Path).TrimEnd('\')
            if([string]::Equals($parent.TrimEnd('\'),$allowed,[StringComparison]::OrdinalIgnoreCase)){
                if([bool]$State.RequiresElevation -ne [bool]$folder.Elevated){throw 'The startup elevation boundary did not match the Startup folder.'}
                return $true
            }
        }
        throw 'The startup file location is outside the Nyx allowlist.'
    }
    throw 'Unsupported startup source type.'
}

function Get-NyxMachineStartupRollbackRoot {
    $base=$env:ProgramData
    if([string]::IsNullOrWhiteSpace($base)){$base=[Environment]::GetFolderPath('CommonApplicationData')}
    if([string]::IsNullOrWhiteSpace($base)){throw 'The Windows common application-data folder is unavailable.'}
    return (Join-Path $base 'DietrichAI.NyxPCCheckup\startup-rollback')
}

function Get-NyxMachineStartupRollbackPaths {
    param([Parameter(Mandatory=$true)][string]$ActionId)
    if($ActionId -notmatch '^[a-f0-9]{32}$'){throw 'The rollback identifier is invalid.'}
    $root=Get-NyxMachineStartupRollbackRoot
    $folder=Join-Path $root $ActionId
    return [pscustomobject]@{SecurityRoot=(Split-Path -Parent $root);Root=$root;Folder=$folder;Journal=(Join-Path $folder 'rollback.json');Payload=(Join-Path $folder 'payload')}
}

function Assert-NyxMachineDirectoryChain {
    param([Parameter(Mandatory=$true)][string]$Path)
    $base=$env:ProgramData
    if([string]::IsNullOrWhiteSpace($base)){$base=[Environment]::GetFolderPath('CommonApplicationData')}
    $trim=[char[]]@('\','/')
    $baseFull=[IO.Path]::GetFullPath($base).TrimEnd($trim)
    $target=[IO.Path]::GetFullPath($Path).TrimEnd($trim)
    $prefix=$baseFull+[IO.Path]::DirectorySeparatorChar
    if(-not $target.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){throw 'The protected rollback path is outside ProgramData.'}
    $baseItem=Get-Item -LiteralPath $baseFull -Force -ErrorAction Stop
    if(($baseItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'ProgramData is unexpectedly a reparse point.'}
    $relative=$target.Substring($baseFull.Length).TrimStart($trim)
    $current=$baseFull
    foreach($segment in $relative.Split([char[]]@('\','/'),[StringSplitOptions]::RemoveEmptyEntries)){
        $current=Join-Path $current $segment
        if(-not(Test-Path -LiteralPath $current -PathType Container)){New-Item -ItemType Directory -Path $current -Force -ErrorAction Stop|Out-Null}
        $item=Get-Item -LiteralPath $current -Force -ErrorAction Stop
        if(-not $item.PSIsContainer -or (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)){throw 'A protected rollback directory is a reparse point or is not a directory.'}
    }
    return $true
}

function Set-NyxMachineRollbackAcl {
    param([Parameter(Mandatory=$true)][string]$Path,[string]$ReadSid='')
    $item=Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'A protected rollback directory cannot be a reparse point.'}
    $acl=New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true,$false)
    $inherit=[Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit
    $none=[Security.AccessControl.PropagationFlags]::None
    $allow=[Security.AccessControl.AccessControlType]::Allow
    $system=[Security.Principal.SecurityIdentifier]::new('S-1-5-18')
    $admins=[Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
    $acl.SetOwner($admins)
    [void]$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($system,[Security.AccessControl.FileSystemRights]::FullControl,$inherit,$none,$allow))
    [void]$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($admins,[Security.AccessControl.FileSystemRights]::FullControl,$inherit,$none,$allow))
    if(-not [string]::IsNullOrWhiteSpace($ReadSid)){
        $reader=[Security.Principal.SecurityIdentifier]::new($ReadSid)
        [void]$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($reader,[Security.AccessControl.FileSystemRights]::ReadAndExecute,$inherit,$none,$allow))
    }
    $item.SetAccessControl($acl)
}

function New-NyxUserStartupRollbackJournal {
    param([Parameter(Mandatory=$true)][string]$ActionId,[Parameter(Mandatory=$true)][object]$State)
    $paths=Initialize-NyxDataDirectories
    $folder=Join-Path $paths.DisabledStartup $ActionId
    if(Test-Path -LiteralPath $folder){throw 'A rollback folder already exists for this action.'}
    New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop|Out-Null
    $journal=Join-Path $folder 'rollback.dpapi'
    $temp="$journal.tmp"
    try{
        $protected=Protect-NyxState -State $State
        [IO.File]::WriteAllText($temp,$protected,[Text.Encoding]::UTF8)
        Move-Item -LiteralPath $temp -Destination $journal -Force -ErrorAction Stop
        return [pscustomobject]@{Folder=$folder;Journal=$journal;ProtectedState=$protected}
    }catch{
        Remove-Item -LiteralPath $folder -Recurse -Force -ErrorAction SilentlyContinue
        throw
    }
}

function New-NyxMachineStartupRollbackJournal {
    param([Parameter(Mandatory=$true)][string]$ActionId,[Parameter(Mandatory=$true)][object]$State)
    if(-not(Test-NyxAdministrator)){throw 'Administrator approval is required to create an all-users rollback journal.'}
    $paths=Get-NyxMachineStartupRollbackPaths -ActionId $ActionId
    if(Test-Path -LiteralPath $paths.Folder){throw 'A protected machine rollback folder already exists for this action.'}
    [void](Assert-NyxMachineDirectoryChain -Path $paths.SecurityRoot)
    Set-NyxMachineRollbackAcl -Path $paths.SecurityRoot
    [void](Assert-NyxMachineDirectoryChain -Path $paths.Root)
    Set-NyxMachineRollbackAcl -Path $paths.Root
    [void](Assert-NyxMachineDirectoryChain -Path $paths.Folder)
    Set-NyxMachineRollbackAcl -Path $paths.Folder -ReadSid ([string]$State.OwnerSid)
    $temp="$($paths.Journal).tmp"
    try{
        $json=$State|ConvertTo-Json -Depth 12
        [IO.File]::WriteAllText($temp,$json,[Text.Encoding]::UTF8)
        Move-Item -LiteralPath $temp -Destination $paths.Journal -Force -ErrorAction Stop
        $journalItem=Get-Item -LiteralPath $paths.Journal -Force -ErrorAction Stop
        if(($journalItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'The protected machine rollback journal became a reparse point.'}
        return $paths
    }catch{
        Remove-Item -LiteralPath $paths.Folder -Recurse -Force -ErrorAction SilentlyContinue
        throw
    }
}

function New-NyxMachinePointerState {
    param([Parameter(Mandatory=$true)][object]$State)
    return [pscustomobject][ordered]@{
        JournalScope='Machine'; ActionId=[string]$State.ActionId; Id=[string]$State.Id; Name=[string]$State.Name;
        Publisher=[string]$State.Publisher; SourceType=[string]$State.SourceType; SourcePath=[string]$State.SourcePath;
        SourceLabel=[string]$State.SourceLabel; ValueName=[string]$State.ValueName; Command=[string]$State.Command;
        ExecutablePath=[string]$State.ExecutablePath; RequiresElevation=$true; BackupPath=''; SourceLength=$null; SourceHash=''
    }
}

function New-NyxStartupRollbackJournal {
    param([Parameter(Mandatory=$true)][string]$ActionId,[Parameter(Mandatory=$true)][object]$State)
    if([string]$State.JournalScope -eq 'Machine'){
        $machine=$null
        try{
            $machine=New-NyxMachineStartupRollbackJournal -ActionId $ActionId -State $State
            $user=New-NyxUserStartupRollbackJournal -ActionId $ActionId -State (New-NyxMachinePointerState -State $State)
            return [pscustomobject]@{Folder=$user.Folder;Journal=$user.Journal;ProtectedState=$user.ProtectedState;MachineFolder=$machine.Folder;Scope='Machine'}
        }catch{
            if($null -ne $machine){Remove-Item -LiteralPath $machine.Folder -Recurse -Force -ErrorAction SilentlyContinue}
            throw
        }
    }
    $user=New-NyxUserStartupRollbackJournal -ActionId $ActionId -State $State
    return [pscustomobject]@{Folder=$user.Folder;Journal=$user.Journal;ProtectedState=$user.ProtectedState;MachineFolder='';Scope='User'}
}

function Get-NyxStartupJournalScope {
    param([Parameter(Mandatory=$true)][object]$State)
    $property=$State.PSObject.Properties['JournalScope']
    if($null -ne $property -and -not [string]::IsNullOrWhiteSpace([string]$property.Value)){return [string]$property.Value}
    if([bool]$State.RequiresElevation){return 'LegacyElevated'}
    return 'User'
}

function Get-NyxMachineStartupRollbackState {
    param([Parameter(Mandatory=$true)][string]$ActionId)
    if(-not(Test-NyxAdministrator)){throw 'Administrator approval is required to read an all-users rollback journal.'}
    $paths=Get-NyxMachineStartupRollbackPaths -ActionId $ActionId
    foreach($directoryPath in @($paths.SecurityRoot,$paths.Root,$paths.Folder)){
        $directory=Get-Item -LiteralPath $directoryPath -Force -ErrorAction Stop
        if(-not $directory.PSIsContainer -or (($directory.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)){throw 'The protected machine rollback directory chain is invalid.'}
        $directoryAcl=Get-Acl -LiteralPath $directory.FullName -ErrorAction Stop
        if(-not $directoryAcl.AreAccessRulesProtected){throw 'The protected machine rollback directory inherited an untrusted ACL.'}
    }
    $folder=Get-Item -LiteralPath $paths.Folder -Force -ErrorAction Stop
    $journal=Get-Item -LiteralPath $paths.Journal -Force -ErrorAction Stop
    if($journal.PSIsContainer -or (($journal.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) -or $journal.Length -gt 1048576){throw 'The protected machine rollback journal is invalid or too large.'}
    $state=Get-Content -LiteralPath $journal.FullName -Raw -Encoding UTF8 -ErrorAction Stop|ConvertFrom-Json
    if([string]$state.JournalScope -ne 'Machine' -or [string]$state.ActionId -ne $ActionId){throw 'The protected machine rollback identity does not match.'}
    if([string]$state.OwnerSid -ne (Get-NyxCurrentUserSid)){throw 'The protected machine rollback journal belongs to a different Windows user.'}
    if(-not [bool]$state.RequiresElevation){throw 'The protected machine rollback journal has an invalid elevation boundary.'}
    [void](Test-NyxStartupStateBoundary -State $state)
    if([string]$state.SourceType -eq 'StartupFile'){
        $backup=[IO.Path]::GetFullPath([string]$state.BackupPath)
        $payload=[IO.Path]::GetFullPath($paths.Payload).TrimEnd('\')
        $parent=[IO.Path]::GetDirectoryName($backup).TrimEnd('\')
        if(-not [string]::Equals($parent,$payload,[StringComparison]::OrdinalIgnoreCase)){throw 'The protected startup-file backup path is outside its machine rollback folder.'}
    }
    return $state
}

function Remove-NyxStartupRollbackJournal {
    param([Parameter(Mandatory=$true)][string]$ActionId,[switch]$Machine)
    $paths=Initialize-NyxDataDirectories
    $userFolder=Join-Path $paths.DisabledStartup $ActionId
    if($Machine){
        if(-not(Test-NyxAdministrator)){throw 'Administrator approval is required to close an all-users rollback journal.'}
        $machine=Get-NyxMachineStartupRollbackPaths -ActionId $ActionId
        if(Test-Path -LiteralPath $machine.Folder){Remove-Item -LiteralPath $machine.Folder -Recurse -Force -ErrorAction Stop}
        foreach($folder in @($machine.Root,$machine.SecurityRoot)){
            try{if((Test-Path -LiteralPath $folder -PathType Container) -and @(Get-ChildItem -LiteralPath $folder -Force -ErrorAction Stop).Count -eq 0){Remove-Item -LiteralPath $folder -Force -ErrorAction Stop}}catch{}
        }
    }
    if(Test-Path -LiteralPath $userFolder){Remove-Item -LiteralPath $userFolder -Recurse -Force -ErrorAction Stop}
}

function Disable-NyxStartupApplication {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][object]$Application,[switch]$Confirmed)
    if (-not $Confirmed) { return New-NyxActionResponse -Success $false -Status 'ConfirmationRequired' -Message 'Disabling a startup entry requires explicit confirmation.' }
    if (-not [bool]$Application.Enabled) { return New-NyxActionResponse -Success $false -Status 'NoChange' -Message 'This startup entry is already disabled.' }
    $paths = Initialize-NyxDataDirectories
    $actionId = [guid]::NewGuid().ToString('N')
    $requiresElevation=[bool]$Application.RequiresElevation
    $state = [pscustomobject][ordered]@{
        JournalScope=$(if($requiresElevation){'Machine'}else{'User'}); ActionId=$actionId; OwnerSid=$(if($requiresElevation){Get-NyxCurrentUserSid}else{''});
        Id=[string]$Application.Id; Name=[string]$Application.Name; Publisher=[string]$Application.Publisher;
        SourceType=[string]$Application.SourceType; SourcePath=[string]$Application.SourcePath; SourceLabel=[string]$Application.SourceLabel;
        ValueName=[string]$Application.ValueName; ValueKind=''; Command=[string]$Application.Command; ExecutablePath=[string]$Application.ExecutablePath;
        RequiresElevation=$requiresElevation; BackupPath=''; SourceLength=$null; SourceHash=''
    }
    try{[void](Test-NyxStartupStateBoundary -State $state)}catch{return New-NyxActionResponse -Success $false -Status 'Rejected' -Message $_.Exception.Message}
    if ($requiresElevation -and -not (Test-NyxAdministrator)) {
        return New-NyxActionResponse -Success $false -Status 'NeedsElevation' -Message 'This all-users startup entry requires administrator approval for this action only.'
    }
    $modified=$false;$journal=$null
    try {
        if ($state.SourceType -eq 'Registry') {
            $key=Get-Item -LiteralPath $state.SourcePath -ErrorAction Stop
            $kind=[string]$key.GetValueKind($state.ValueName)
            if($kind -notin @('String','ExpandString')){throw 'Only string-based Windows Run values are supported.'}
            $state.ValueKind=$kind
            $current=(Get-ItemProperty -LiteralPath $state.SourcePath -Name $state.ValueName -ErrorAction Stop).($state.ValueName)
            if ([string]$current -ne [string]$state.Command) { throw 'The startup registry value changed after it was scanned. Refresh and try again.' }
        } elseif ($state.SourceType -eq 'StartupFile') {
            $source=Get-Item -LiteralPath $state.SourcePath -Force -ErrorAction Stop
            if(-not $source.PSIsContainer -and (($source.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0)){
                $folder=if($requiresElevation){(Get-NyxMachineStartupRollbackPaths -ActionId $actionId).Folder}else{Join-Path $paths.DisabledStartup $actionId}
                $state.BackupPath=Join-Path $folder ('payload\'+[IO.Path]::GetFileName($source.FullName))
                $state.SourceLength=[int64]$source.Length
                $state.SourceHash=(Get-FileHash -LiteralPath $source.FullName -Algorithm SHA256 -ErrorAction Stop).Hash
            }else{throw 'Reparse points and directories are not supported startup-file actions.'}
        }
        # Both the user-visible pointer and, for all-users entries, the
        # administrator-protected machine journal are durable before change.
        $journal=New-NyxStartupRollbackJournal -ActionId $actionId -State $state
        if ($state.SourceType -eq 'Registry') {
            Remove-ItemProperty -LiteralPath $state.SourcePath -Name $state.ValueName -ErrorAction Stop
            $modified=$true
        } else {
            $backupParent=Split-Path -Parent $state.BackupPath
            New-Item -ItemType Directory -Path $backupParent -Force -ErrorAction Stop|Out-Null
            Move-Item -LiteralPath $state.SourcePath -Destination $state.BackupPath -ErrorAction Stop
            $modified=$true
        }
        Add-NyxActionHistory -Action ([pscustomobject][ordered]@{
            ActionId=$actionId; ActionType='StartupDisable'; RelatedActionId=''; Success=$true;
            DisplayName=[string]$state.Name; DisplaySource=[string]$state.SourceLabel; UndoAvailable=$true;
            ProtectedState=[string]$journal.ProtectedState; Timestamp=(Get-Date).ToUniversalTime().ToString('o')
        })
        Write-NyxLog -Level 'INFO' -Message ("Disabled startup entry '{0}' with rollback {1}." -f $state.Name,$actionId)
        return New-NyxActionResponse -Success $true -Status 'Completed' -Message 'The startup entry was disabled and its exact rollback state was written first.' -ActionId $actionId
    } catch {
        if(-not $modified -and $null -ne $journal){try{Remove-NyxStartupRollbackJournal -ActionId $actionId -Machine:$requiresElevation}catch{}}
        $message=$_.Exception.Message
        if($modified){$message+=' The protected rollback journal was preserved for recovery.'}
        Write-NyxLog -Level 'ERROR' -Message ("Startup disable failed: {0}" -f $message)
        return New-NyxActionResponse -Success $false -Status $(if($modified){'FailedWithRollback'}else{'Failed'}) -Message $message -ActionId $(if($modified){$actionId}else{''})
    }
}

function Enable-NyxStartupApplication {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$RollbackActionId,[switch]$Confirmed)
    if (-not $Confirmed) { return New-NyxActionResponse -Success $false -Status 'ConfirmationRequired' -Message 'Re-enabling a startup entry requires explicit confirmation.' }
    if($RollbackActionId -notmatch '^[a-f0-9]{32}$'){return New-NyxActionResponse -Success $false -Status 'Rejected' -Message 'The rollback identifier is invalid.'}
    $active = @(Get-NyxActiveStartupDisables | Where-Object { $_.ActionId -eq $RollbackActionId } | Select-Object -First 1)
    if ($active.Count -eq 0) { return New-NyxActionResponse -Success $false -Status 'NotFound' -Message 'No active rollback journal was found.' }
    try{$pointer=Unprotect-NyxState -ProtectedText ([string]$active[0].ProtectedState)}catch{return New-NyxActionResponse -Success $false -Status 'Failed' -Message 'The rollback pointer could not be validated for this Windows user.'}
    $scope=Get-NyxStartupJournalScope -State $pointer
    if($scope -eq 'LegacyElevated'){return New-NyxActionResponse -Success $false -Status 'Failed' -Message 'A legacy elevated rollback journal was rejected because it is not protected by the Version 1 machine-journal boundary.'}
    if($scope -eq 'Machine' -and -not(Test-NyxAdministrator)){
        return New-NyxActionResponse -Success $false -Status 'NeedsElevation' -Message 'Restoring this all-users startup entry requires administrator approval for this action only.'
    }
    try{
        if($scope -eq 'Machine'){$state=Get-NyxMachineStartupRollbackState -ActionId $RollbackActionId}else{$state=$pointer;[void](Test-NyxStartupStateBoundary -State $state)}
    }catch{return New-NyxActionResponse -Success $false -Status 'Failed' -Message ($_.Exception.Message+' No startup setting was changed.')}
    $newActionId = [guid]::NewGuid().ToString('N')
    try {
        if ($state.SourceType -eq 'Registry') {
            if (-not (Test-Path -LiteralPath $state.SourcePath)) { New-Item -Path $state.SourcePath -Force | Out-Null }
            $existing = $null
            try { $existing = (Get-ItemProperty -LiteralPath $state.SourcePath -Name $state.ValueName -ErrorAction Stop).($state.ValueName) } catch { }
            if ($null -eq $existing) {
                $kind=if([string]$state.ValueKind -eq 'ExpandString'){'ExpandString'}else{'String'}
                New-ItemProperty -LiteralPath $state.SourcePath -Name $state.ValueName -Value ([string]$state.Command) -PropertyType $kind -Force -ErrorAction Stop | Out-Null
            } elseif ([string]$existing -ne [string]$state.Command) {
                throw 'A different startup value now uses the same name. Nyx did not overwrite it.'
            }
        } elseif ($state.SourceType -eq 'StartupFile') {
            $sourceExists=Test-Path -LiteralPath ([string]$state.SourcePath) -PathType Leaf
            $backupExists=Test-Path -LiteralPath ([string]$state.BackupPath) -PathType Leaf
            if(-not $sourceExists -and $backupExists){
                $backup=Get-Item -LiteralPath ([string]$state.BackupPath) -Force -ErrorAction Stop
                if(($backup.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'The protected startup backup became a reparse point.'}
                $hash=(Get-FileHash -LiteralPath $backup.FullName -Algorithm SHA256 -ErrorAction Stop).Hash
                if([int64]$backup.Length -ne [int64]$state.SourceLength -or $hash -ne [string]$state.SourceHash){throw 'The protected startup backup no longer matches its recorded identity.'}
                $parent=Split-Path -Parent ([string]$state.SourcePath)
                if(-not(Test-Path -LiteralPath $parent)){New-Item -ItemType Directory -Path $parent -Force|Out-Null}
                $parentItem=Get-Item -LiteralPath $parent -Force -ErrorAction Stop
                if(($parentItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'The original Startup folder became a reparse point.'}
                Move-Item -LiteralPath $backup.FullName -Destination ([string]$state.SourcePath) -ErrorAction Stop
            }elseif($sourceExists -and -not $backupExists){
                $source=Get-Item -LiteralPath ([string]$state.SourcePath) -Force -ErrorAction Stop
                if(($source.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'The restored startup file became a reparse point.'}
                $hash=(Get-FileHash -LiteralPath $source.FullName -Algorithm SHA256 -ErrorAction Stop).Hash
                if([int64]$source.Length -ne [int64]$state.SourceLength -or $hash -ne [string]$state.SourceHash){throw 'A different file now exists at the original startup location. Nyx preserved the rollback journal.'}
                # The move completed in an earlier interrupted attempt; finish journaling.
            }elseif($sourceExists -and $backupExists){throw 'A file already exists at the original startup location. Nyx did not overwrite it.'}
            else{throw 'The disabled startup file is no longer available.'}
        }
        Add-NyxActionHistory -Action ([pscustomobject][ordered]@{
            ActionId=$newActionId; ActionType='StartupEnable'; RelatedActionId=$RollbackActionId; Success=$true;
            DisplayName=[string]$state.Name; DisplaySource=[string]$state.SourceLabel; UndoAvailable=$false;
            ProtectedState=''; Timestamp=(Get-Date).ToUniversalTime().ToString('o')
        })
        Remove-NyxStartupRollbackJournal -ActionId $RollbackActionId -Machine:($scope -eq 'Machine')
        Write-NyxLog -Level 'INFO' -Message ("Restored startup entry '{0}' from rollback {1}." -f $state.Name,$RollbackActionId)
        return New-NyxActionResponse -Success $true -Status 'Completed' -Message 'The startup entry was restored to its recorded location and the active journal was closed.' -ActionId $newActionId
    } catch {
        Write-NyxLog -Level 'ERROR' -Message ("Startup restore failed: {0}" -f $_.Exception.Message)
        return New-NyxActionResponse -Success $false -Status 'Failed' -Message ($_.Exception.Message+' The rollback journal was preserved.')
    }
}

function Restore-AllNyxStartupApplications {
    [CmdletBinding()]
    param([switch]$Confirmed)
    $results = New-Object System.Collections.Generic.List[object]
    foreach ($entry in @(Get-NyxActiveStartupDisables)) {
        $results.Add((Enable-NyxStartupApplication -RollbackActionId ([string]$entry.ActionId) -Confirmed:$Confirmed))
    }
    return @($results)
}

Export-ModuleMember -Function Test-NyxAdministrator,Test-NyxStartupStateBoundary,Disable-NyxStartupApplication,Enable-NyxStartupApplication,Restore-AllNyxStartupApplications
