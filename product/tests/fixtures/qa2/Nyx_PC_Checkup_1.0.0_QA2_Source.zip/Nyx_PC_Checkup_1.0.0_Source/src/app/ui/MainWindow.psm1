Set-StrictMode -Version 2.0
Import-Module (Join-Path $PSScriptRoot 'Theme.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Controls.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Dialogs.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\core\Models.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\core\Paths.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\core\Configuration.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\core\CheckupEngine.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\core\Diagnostics.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\core\Privacy.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\reports\ReportExport.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\checks\StartupApps.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\platform\windows\WindowsHelpers.psm1') -Force

$script:NyxUi=$null

function Get-NyxPowerShellPath { return (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') }
function Invoke-NyxOpen {
    param([string]$Target,[string]$Arguments='')
    try { if($Arguments){Start-Process -FilePath $Target -ArgumentList $Arguments}else{Start-Process $Target} } catch { [Windows.Forms.MessageBox]::Show("Could not open the requested Windows page or folder.`r`n$($_.Exception.Message)",'Nyx PC Checkup','OK','Warning')|Out-Null }
}
function Clear-NyxPage {
    foreach($control in @($script:NyxUi.Content.Controls)){try{$control.Dispose()}catch{}}
    $script:NyxUi.Content.Controls.Clear()
}
function Get-NyxPageWidth { return [math]::Max(790,$script:NyxUi.Content.ClientSize.Width-52) }
function Add-NyxPageHeading {
    param([string]$Title,[string]$Subtitle)
    $w=Get-NyxPageWidth
    $script:NyxUi.Content.Controls.Add((New-NyxLabel -Text $Title -X 24 -Y 20 -Width $w -Height 42 -Size 21 -Bold $true -Palette $script:NyxUi.Palette))
    $script:NyxUi.Content.Controls.Add((New-NyxLabel -Text $Subtitle -X 24 -Y 64 -Width $w -Height 46 -Size 10 -Palette $script:NyxUi.Palette -Color 'Muted'))
}
function Get-NyxResultsByCategory {
    param([string[]]$Categories)
    if($null -eq $script:NyxUi.Scan){return @()}
    return @($script:NyxUi.Scan.Results|Where-Object{$Categories -contains [string]$_.Category})
}
function Get-NyxGroupStatus {
    param([object[]]$Results)
    $r=@($Results)
    if(@($r|Where-Object{$_.Status -eq 'NeedsAttention'}).Count -gt 0){return 'NeedsAttention'}
    if($r.Count -eq 0 -or @($r|Where-Object{$_.Status -eq 'Unknown'}).Count -eq $r.Count){return 'Unknown'}
    if(@($r|Where-Object{$_.Status -eq 'Optional'}).Count -gt 0){return 'Optional'}
    return 'Good'
}
function Add-NyxScanButtons {
    param([int]$X,[int]$Y)
    $quick=New-NyxButton -Text 'Quick Check' -X $X -Y $Y -Width 150 -Palette $script:NyxUi.Palette -Primary $true
    $full=New-NyxButton -Text 'Full Check' -X ($X+164) -Y $Y -Width 150 -Palette $script:NyxUi.Palette
    $quick.Add_Click({Start-NyxScan -Mode 'Quick'});$full.Add_Click({Start-NyxScan -Mode 'Full'})
    $script:NyxUi.Content.Controls.AddRange(@($quick,$full))
}
function New-NyxResultsGridControl {
    param([object[]]$Results,[int]$Y,[int]$Height=420)
    $w=Get-NyxPageWidth
    $grid=New-NyxGrid -X 24 -Y $Y -Width $w -Height $Height -Palette $script:NyxUi.Palette
    $grid.Anchor='Top,Left,Right'
    [void]$grid.Columns.Add('Status','Status');[void]$grid.Columns.Add('Category','Category');[void]$grid.Columns.Add('Check','Check');[void]$grid.Columns.Add('Finding','What Nyx found')
    $grid.Columns['Status'].FillWeight=20;$grid.Columns['Category'].FillWeight=20;$grid.Columns['Check'].FillWeight=28;$grid.Columns['Finding'].FillWeight=80
    foreach($result in @($Results)){
        $symbol=Get-NyxStatusSymbol ([string]$result.Status);$label=Get-NyxStatusLabel ([string]$result.Status)
        $index=$grid.Rows.Add("$symbol $label",[string]$result.Category,[string]$result.Name,[string]$result.Finding)
        $grid.Rows[$index].Tag=$result;$grid.Rows[$index].Cells[0].Style.ForeColor=Get-NyxStatusColor -Status ([string]$result.Status) -Palette $script:NyxUi.Palette
    }
    $grid.Add_CellDoubleClick({param($sender,$eventArgs)if($eventArgs.RowIndex -ge 0){$r=$sender.Rows[$eventArgs.RowIndex].Tag;if($r){Show-NyxResultDetailDialog -Result $r -Palette $script:NyxUi.Palette}}})
    return $grid
}
function Add-NyxNoScanCard {
    param([int]$Y=125)
    $w=Get-NyxPageWidth;$card=New-NyxCard -X 24 -Y $Y -Width $w -Height 190 -Palette $script:NyxUi.Palette;$card.Anchor='Top,Left,Right'
    $card.Controls.Add((New-NyxLabel -Text 'No check has been run yet' -X 22 -Y 22 -Width ($w-50) -Height 36 -Size 16 -Bold $true -Palette $script:NyxUi.Palette))
    $card.Controls.Add((New-NyxLabel -Text 'Scanning is read-only, normally needs no administrator privileges, and never performs cleanup or changes startup settings.' -X 22 -Y 64 -Width ($w-50) -Height 48 -Size 10 -Palette $script:NyxUi.Palette -Color 'Muted'))
    $q=New-NyxButton -Text 'Check My PC' -X 22 -Y 124 -Width 170 -Palette $script:NyxUi.Palette -Primary $true;$q.Add_Click({Start-NyxScan -Mode 'Quick'})
    $f=New-NyxButton -Text 'Run Full Check' -X 206 -Y 124 -Width 170 -Palette $script:NyxUi.Palette;$f.Add_Click({Start-NyxScan -Mode 'Full'})
    $card.Controls.AddRange(@($q,$f));$script:NyxUi.Content.Controls.Add($card)
}

function Show-NyxHomePage {
    Clear-NyxPage
    Add-NyxPageHeading -Title 'Your PC' -Subtitle (Get-NyxPrivacyStatement)
    if($null -eq $script:NyxUi.Scan){Add-NyxNoScanCard -Y 124;return}
    $w=Get-NyxPageWidth;$summary=$script:NyxUi.Scan.Summary
    $card=New-NyxCard -X 24 -Y 122 -Width $w -Height 150 -Palette $script:NyxUi.Palette;$card.Anchor='Top,Left,Right'
    $card.Controls.Add((New-NyxStatusPill -Status ([string]$summary.OverallStatus) -X 22 -Y 18 -Palette $script:NyxUi.Palette))
    $card.Controls.Add((New-NyxLabel -Text ([string]$summary.Headline) -X 22 -Y 51 -Width ($w-250) -Height 44 -Size 18 -Bold $true -Palette $script:NyxUi.Palette))
    $card.Controls.Add((New-NyxLabel -Text ("Good {0}   |   Needs Attention {1}   |   Optional {2}   |   Unknown {3}" -f $summary.Good,$summary.NeedsAttention,$summary.Optional,$summary.Unknown) -X 22 -Y 101 -Width ($w-50) -Height 28 -Size 10 -Palette $script:NyxUi.Palette -Color 'Muted'))
    $check=New-NyxButton -Text 'Check My PC' -X ($w-190) -Y 48 -Width 150 -Palette $script:NyxUi.Palette -Primary $true;$check.Anchor='Top,Right';$check.Add_Click({Start-NyxScan -Mode 'Quick'});$card.Controls.Add($check)
    $script:NyxUi.Content.Controls.Add($card)
    $groups=[ordered]@{Storage=@('Storage','Downloads','Cleanup');Updates=@('Updates');Security=@('Security');Startup=@('Startup');Backup=@('Backup');System=@('System','Battery','Drive Health','Performance','Network','Applications')}
    $i=0
    foreach($name in $groups.Keys){
        $col=$i%3;$row=[math]::Floor($i/3);$x=24+($col*268);$y=292+($row*132);$groupResults=Get-NyxResultsByCategory -Categories $groups[$name];$status=Get-NyxGroupStatus -Results $groupResults
        $c=New-NyxCard -X $x -Y $y -Width 250 -Height 112 -Palette $script:NyxUi.Palette
        $c.Controls.Add((New-NyxLabel -Text $name -X 16 -Y 14 -Width 205 -Height 28 -Size 12 -Bold $true -Palette $script:NyxUi.Palette))
        $c.Controls.Add((New-NyxStatusPill -Status $status -X 16 -Y 48 -Palette $script:NyxUi.Palette))
        $count=@($groupResults|Where-Object{$_.Status -eq 'NeedsAttention'}).Count
        $detail=if($count -gt 0){"$count recommended action(s)"}elseif($status -eq 'Optional'){'Optional items available'}elseif($status -eq 'Good'){'No action needed'}else{'Could not determine'}
        $c.Controls.Add((New-NyxLabel -Text $detail -X 16 -Y 78 -Width 210 -Height 24 -Size 9 -Palette $script:NyxUi.Palette -Color 'Muted'))
        $script:NyxUi.Content.Controls.Add($c);$i++
    }
    $findings=@($script:NyxUi.Scan.Results|Sort-Object @{Expression={switch($_.Status){'NeedsAttention'{0};'Optional'{1};'Unknown'{2};default{3}}}},Category|Where-Object{$_.Status -ne 'Good'}|Select-Object -First 6)
    $y=572;$title=if($findings.Count -gt 0){'Things worth looking at'}else{'No action list'}
    $script:NyxUi.Content.Controls.Add((New-NyxLabel -Text $title -X 24 -Y $y -Width $w -Height 36 -Size 16 -Bold $true -Palette $script:NyxUi.Palette));$y+=42
    if($findings.Count -eq 0){$script:NyxUi.Content.Controls.Add((New-NyxLabel -Text 'Your PC looks good. Nothing needs fixing.' -X 24 -Y $y -Width $w -Height 34 -Size 11 -Palette $script:NyxUi.Palette))}
    else{foreach($r in $findings){$symbol=Get-NyxStatusSymbol $r.Status;$label=New-NyxLabel -Text ("{0}  {1}: {2}" -f $symbol,$r.Name,$r.Finding) -X 30 -Y $y -Width ($w-30) -Height 42 -Size 10 -Palette $script:NyxUi.Palette;$label.ForeColor=Get-NyxStatusColor -Status $r.Status -Palette $script:NyxUi.Palette;$script:NyxUi.Content.Controls.Add($label);$y+=44}}
    $script:NyxUi.Content.AutoScrollMinSize=New-Object Drawing.Size(0,($y+60))
}

function Show-NyxCheckupPage {
    Clear-NyxPage;Add-NyxPageHeading -Title 'Checkup' -Subtitle 'Quick Check covers the most important common health indicators. Full Check adds storage analysis, Downloads, cleanup preview, battery, drives, performance, and installed applications.'
    Add-NyxScanButtons -X 24 -Y 116
    if($null -eq $script:NyxUi.Scan){Add-NyxNoScanCard -Y 174;return}
    $grid=New-NyxResultsGridControl -Results @($script:NyxUi.Scan.Results) -Y 174 -Height 505;$script:NyxUi.Content.Controls.Add($grid)
    $script:NyxUi.Content.Controls.Add((New-NyxLabel -Text 'Double-click any result to see evidence, limitations, and the exact recommendation.' -X 24 -Y 690 -Width (Get-NyxPageWidth) -Height 28 -Size 9 -Palette $script:NyxUi.Palette -Color 'Muted'))
}

function Show-NyxCategoryPage {
    param([string]$Title,[string]$Subtitle,[string[]]$Categories,[string]$ActionText='',[scriptblock]$Action=$null)
    Clear-NyxPage;Add-NyxPageHeading -Title $Title -Subtitle $Subtitle
    $y=116
    if($ActionText){$button=New-NyxButton -Text $ActionText -X 24 -Y $y -Width 205 -Palette $script:NyxUi.Palette -Primary $true;$button.Add_Click($Action);$script:NyxUi.Content.Controls.Add($button);$y+=56}
    if($null -eq $script:NyxUi.Scan){Add-NyxNoScanCard -Y $y;return}
    $results=Get-NyxResultsByCategory -Categories $Categories
    if($results.Count -eq 0){$script:NyxUi.Content.Controls.Add((New-NyxLabel -Text 'This module did not return a result in the last scan. Run a Full Check where applicable.' -X 24 -Y $y -Width (Get-NyxPageWidth) -Height 54 -Size 11 -Palette $script:NyxUi.Palette));Add-NyxScanButtons -X 24 -Y ($y+65);return}
    $grid=New-NyxResultsGridControl -Results $results -Y $y -Height 500;$script:NyxUi.Content.Controls.Add($grid)
}

function Show-NyxStoragePage {
    Clear-NyxPage;Add-NyxPageHeading -Title 'Storage' -Subtitle 'Nyx measures storage and shows opportunities. Large, old, or duplicated does not mean unwanted, and this page never deletes anything.'
    $open=New-NyxButton -Text 'Open Storage settings' -X 24 -Y 116 -Width 190 -Palette $script:NyxUi.Palette -Primary $true;$open.Add_Click({Invoke-NyxOpen 'ms-settings:storagesense'})
    $downloads=New-NyxButton -Text 'Open Downloads' -X 228 -Y 116 -Width 170 -Palette $script:NyxUi.Palette;$downloads.Add_Click({Invoke-NyxOpen 'explorer.exe' ('"'+(Get-NyxDownloadsPath)+'"')})
    $full=New-NyxButton -Text 'Run Full Check' -X 412 -Y 116 -Width 160 -Palette $script:NyxUi.Palette;$full.Add_Click({Start-NyxScan -Mode 'Full'})
    $script:NyxUi.Content.Controls.AddRange(@($open,$downloads,$full))
    if($null -eq $script:NyxUi.Scan){Add-NyxNoScanCard -Y 174;return}
    $results=Get-NyxResultsByCategory -Categories @('Storage','Downloads');$grid=New-NyxResultsGridControl -Results $results -Y 174 -Height 280;$script:NyxUi.Content.Controls.Add($grid)
    $folderResult=@($script:NyxUi.Scan.Results|Where-Object{$_.CheckId -eq 'storage.user-folders'}|Select-Object -First 1)
    if($folderResult.Count -gt 0){
        $script:NyxUi.Content.Controls.Add((New-NyxLabel -Text 'Measured user folders' -X 24 -Y 474 -Width 360 -Height 32 -Size 14 -Bold $true -Palette $script:NyxUi.Palette))
        $fg=New-NyxGrid -X 24 -Y 512 -Width (Get-NyxPageWidth) -Height 210 -Palette $script:NyxUi.Palette;[void]$fg.Columns.Add('Folder','Folder');[void]$fg.Columns.Add('Size','Size');[void]$fg.Columns.Add('Files','Files');[void]$fg.Columns.Add('Complete','Complete')
        foreach($f in @($folderResult[0].Details.Folders)){$fg.Rows.Add([string]$f.Name,(ConvertTo-NyxBytesText ([int64]$f.Bytes)),[string]$f.Files,[string]$f.Complete)|Out-Null};$script:NyxUi.Content.Controls.Add($fg)
        $script:NyxUi.Content.Controls.Add((New-NyxLabel -Text 'Largest files found' -X 24 -Y 742 -Width 360 -Height 32 -Size 14 -Bold $true -Palette $script:NyxUi.Palette))
        $lg=New-NyxGrid -X 24 -Y 780 -Width (Get-NyxPageWidth) -Height 330 -Palette $script:NyxUi.Palette;[void]$lg.Columns.Add('Name','File');[void]$lg.Columns.Add('Size','Size');[void]$lg.Columns.Add('Folder','Folder')
        $lg.Columns['Name'].FillWeight=45;$lg.Columns['Size'].FillWeight=15;$lg.Columns['Folder'].FillWeight=70
        foreach($f in @($folderResult[0].Details.LargestFiles)){$i=$lg.Rows.Add([IO.Path]::GetFileName([string]$f.Path),(ConvertTo-NyxBytesText ([int64]$f.SizeBytes)),[IO.Path]::GetDirectoryName([string]$f.Path));$lg.Rows[$i].Tag=$f}
        $lg.Add_CellDoubleClick({param($s,$e)if($e.RowIndex -ge 0){$f=$s.Rows[$e.RowIndex].Tag;if($f){Invoke-NyxOpen 'explorer.exe' ('/select,"'+[string]$f.Path+'"')}}});$script:NyxUi.Content.Controls.Add($lg)
        $script:NyxUi.Content.AutoScrollMinSize=New-Object Drawing.Size(0,1140)
    }
}

function Invoke-NyxUiAction {
    param([Parameter(Mandatory=$true)][object]$Request)
    $paths=Initialize-NyxDataDirectories;$id=[guid]::NewGuid().ToString('N');$req=Join-Path $paths.Temp ("action-$id-request.json");$out=Join-Path $paths.Temp ("action-$id-result.json")
    if($null -eq $Request.PSObject.Properties['ConfirmedByUser']){$Request|Add-Member -NotePropertyName ConfirmedByUser -NotePropertyValue $true}else{$Request.ConfirmedByUser=$true}
    $requestJson=$Request|ConvertTo-Json -Depth 12 -Compress
    [IO.File]::WriteAllText($req,$requestJson,[Text.UTF8Encoding]::new($false))
    $requestHash=(Get-FileHash -LiteralPath $req -Algorithm SHA256 -ErrorAction Stop).Hash
    $worker=Join-Path $script:NyxUi.AppRoot 'workers\ActionWorker.ps1';$ps=Get-NyxPowerShellPath
    function Run-Worker([bool]$Elevated){
        if(Test-Path -LiteralPath $out){Remove-Item -LiteralPath $out -Force}
        $args="-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$worker`" -RequestPath `"$req`" -OutputPath `"$out`" -RequestSha256 $requestHash"
        try{if($Elevated){$p=Start-Process -FilePath $ps -ArgumentList $args -Verb RunAs -PassThru}else{$p=Start-Process -FilePath $ps -ArgumentList $args -WindowStyle Hidden -PassThru}}catch{return $null}
        $script:NyxUi.FooterProgress.Style='Marquee';$script:NyxUi.FooterLabel.Text='Applying the explicitly confirmed action...';$script:NyxUi.Form.Enabled=$false
        while(-not $p.HasExited){[Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 90}
        $script:NyxUi.Form.Enabled=$true;$script:NyxUi.Form.Activate();$script:NyxUi.FooterProgress.Style='Continuous';$script:NyxUi.FooterProgress.Value=0
        if(Test-Path -LiteralPath $out){try{return(Get-Content -LiteralPath $out -Raw -Encoding UTF8|ConvertFrom-Json)}catch{return $null}};return $null
    }
    $result=Run-Worker $false
    if($result -and $result.Status -eq 'NeedsElevation'){
        $answer=[Windows.Forms.MessageBox]::Show("$($result.Message)`r`n`r`nContinue with a Windows administrator approval prompt for this action only?",'Nyx PC Checkup','YesNo','Question')
        if($answer -eq [Windows.Forms.DialogResult]::Yes){$result=Run-Worker $true}
    }
    Remove-Item -LiteralPath $req,$out -Force -ErrorAction SilentlyContinue
    $script:NyxUi.FooterLabel.Text='Ready. No background monitor is running.'
    return $result
}

function Show-NyxStartupPage {
    Clear-NyxPage;Add-NyxPageHeading -Title 'Startup apps' -Subtitle 'These programs are configured to start with Windows. Nyx does not estimate impact without real evidence and never labels unfamiliar software as malicious.'
    $refresh=New-NyxButton -Text 'Refresh list' -X 24 -Y 116 -Width 140 -Palette $script:NyxUi.Palette -Primary $true;$script:NyxUi.Content.Controls.Add($refresh)
    $grid=New-NyxGrid -X 24 -Y 172 -Width (Get-NyxPageWidth) -Height 445 -Palette $script:NyxUi.Palette;$grid.Anchor='Top,Left,Right'
    [void]$grid.Columns.Add('State','State');[void]$grid.Columns.Add('Name','Application');[void]$grid.Columns.Add('Publisher','Publisher');[void]$grid.Columns.Add('Source','Startup source');[void]$grid.Columns.Add('Exists','File exists');[void]$grid.Columns.Add('Impact','Impact')
    $grid.Columns['State'].FillWeight=18;$grid.Columns['Name'].FillWeight=42;$grid.Columns['Publisher'].FillWeight=34;$grid.Columns['Source'].FillWeight=42;$grid.Columns['Exists'].FillWeight=18;$grid.Columns['Impact'].FillWeight=22
    $script:NyxUi.Content.Controls.Add($grid)
    $load={
        $grid.Rows.Clear();$apps=@(Get-NyxStartupApplications)
        foreach($app in $apps){$i=$grid.Rows.Add($(if($app.Enabled){'Enabled'}else{'Disabled by Nyx'}),[string]$app.Name,[string]$app.Publisher,[string]$app.SourceLabel,$(if($app.FileExists){'Yes'}else{'No / unknown'}),[string]$app.Impact);$grid.Rows[$i].Tag=$app;if(-not $app.Enabled){$grid.Rows[$i].Cells[0].Style.ForeColor=$script:NyxUi.Palette.Optional}}
    }
    $refresh.Add_Click($load);&$load
    $disable=New-NyxButton -Text 'Disable selected' -X 24 -Y 634 -Width 165 -Palette $script:NyxUi.Palette;$enable=New-NyxButton -Text 'Re-enable selected' -X 203 -Y 634 -Width 175 -Palette $script:NyxUi.Palette;$location=New-NyxButton -Text 'Open file location' -X 392 -Y 634 -Width 180 -Palette $script:NyxUi.Palette
    $disable.Add_Click({if($grid.SelectedRows.Count -eq 0){return};$app=$grid.SelectedRows[0].Tag;if(-not $app.Enabled){[Windows.Forms.MessageBox]::Show('The selected entry is already disabled.','Nyx PC Checkup')|Out-Null;return};$answer=[Windows.Forms.MessageBox]::Show("Disable '$($app.Name)' from starting automatically?`r`n`r`nNyx will record the exact prior state and provide Re-enable.",'Confirm reversible startup change','YesNo','Warning');if($answer -ne [Windows.Forms.DialogResult]::Yes){return};$r=Invoke-NyxUiAction -Request ([pscustomobject]@{Operation='DisableStartup';ApplicationId=[string]$app.Id});if($r){[Windows.Forms.MessageBox]::Show([string]$r.Message,'Nyx PC Checkup')|Out-Null};&$load})
    $enable.Add_Click({if($grid.SelectedRows.Count -eq 0){return};$app=$grid.SelectedRows[0].Tag;if($app.Enabled){[Windows.Forms.MessageBox]::Show('The selected entry is already enabled.','Nyx PC Checkup')|Out-Null;return};$answer=[Windows.Forms.MessageBox]::Show("Restore '$($app.Name)' to its exact previous startup location?",'Confirm startup restore','YesNo','Question');if($answer -ne [Windows.Forms.DialogResult]::Yes){return};$r=Invoke-NyxUiAction -Request ([pscustomobject]@{Operation='EnableStartup';RollbackActionId=[string]$app.RollbackActionId});if($r){[Windows.Forms.MessageBox]::Show([string]$r.Message,'Nyx PC Checkup')|Out-Null};&$load})
    $location.Add_Click({if($grid.SelectedRows.Count -eq 0){return};$app=$grid.SelectedRows[0].Tag;$path=[string]$app.ExecutablePath;if($path -and(Test-Path -LiteralPath $path)){Invoke-NyxOpen 'explorer.exe' ('/select,"'+$path+'"')}else{[Windows.Forms.MessageBox]::Show('The executable location is unavailable.','Nyx PC Checkup')|Out-Null}})
    $script:NyxUi.Content.Controls.AddRange(@($disable,$enable,$location))
    $script:NyxUi.Content.Controls.Add((New-NyxLabel -Text 'Every modification is explicit. All-users entries request elevation only for that one action. Disabled entries are not deleted.' -X 24 -Y 688 -Width (Get-NyxPageWidth) -Height 40 -Size 9 -Palette $script:NyxUi.Palette -Color 'Muted'))
}

function Show-NyxAppsPage {
    Clear-NyxPage;Add-NyxPageHeading -Title 'Installed applications' -Subtitle 'Search the supported Windows uninstall inventory. Nyx does not call programs junk and does not uninstall anything automatically.'
    $open=New-NyxButton -Text 'Open Installed Apps' -X 24 -Y 116 -Width 185 -Palette $script:NyxUi.Palette -Primary $true;$open.Add_Click({Invoke-NyxOpen 'ms-settings:appsfeatures'});$script:NyxUi.Content.Controls.Add($open)
    $search=New-Object Windows.Forms.TextBox;$search.Location=New-Object Drawing.Point(224,120);$search.Size=New-Object Drawing.Size(340,32);$search.Font=New-Object Drawing.Font('Segoe UI',10);$search.BackColor=$script:NyxUi.Palette.Surface;$search.ForeColor=$script:NyxUi.Palette.Text;$search.BorderStyle='FixedSingle';$script:NyxUi.Content.Controls.Add($search)
    $grid=New-NyxGrid -X 24 -Y 172 -Width (Get-NyxPageWidth) -Height 500 -Palette $script:NyxUi.Palette;[void]$grid.Columns.Add('Name','Application');[void]$grid.Columns.Add('Publisher','Publisher');[void]$grid.Columns.Add('Version','Version');[void]$grid.Columns.Add('Date','Install date');[void]$grid.Columns.Add('Size','Reported size');$script:NyxUi.Content.Controls.Add($grid)
    $apps=@();if($script:NyxUi.Scan){$r=@($script:NyxUi.Scan.Results|Where-Object{$_.CheckId -eq 'apps.inventory'}|Select-Object -First 1);if($r.Count -gt 0){$apps=@($r[0].Details)}}
    $render={param([string]$Filter='')$grid.Rows.Clear();foreach($app in $apps){if($Filter -and((([string]$app.Name)+' '+([string]$app.Publisher)) -notmatch [regex]::Escape($Filter))){continue};$size=if($null -ne $app.EstimatedSizeBytes){ConvertTo-NyxBytesText ([int64]$app.EstimatedSizeBytes)}else{'Unknown'};$i=$grid.Rows.Add([string]$app.Name,[string]$app.Publisher,[string]$app.Version,[string]$app.InstallDate,$size);$grid.Rows[$i].Tag=$app}}
    $search.Add_TextChanged({&$render $search.Text});&$render ''
    if($apps.Count -eq 0){$script:NyxUi.Content.Controls.Add((New-NyxLabel -Text 'Run a Full Check to populate the installed-application list.' -X 24 -Y 688 -Width 520 -Height 32 -Size 10 -Palette $script:NyxUi.Palette -Color 'Muted'));$full=New-NyxButton -Text 'Run Full Check' -X 560 -Y 682 -Width 160 -Palette $script:NyxUi.Palette;$full.Add_Click({Start-NyxScan -Mode 'Full'});$script:NyxUi.Content.Controls.Add($full)}
    $folder=New-NyxButton -Text 'Open selected folder' -X 24 -Y 686 -Width 190 -Palette $script:NyxUi.Palette;$folder.Add_Click({if($grid.SelectedRows.Count -eq 0){return};$app=$grid.SelectedRows[0].Tag;if($app.InstallLocation -and(Test-Path -LiteralPath ([string]$app.InstallLocation))){Invoke-NyxOpen 'explorer.exe' ('"'+[string]$app.InstallLocation+'"')}else{[Windows.Forms.MessageBox]::Show('No usable install folder was reported for this application.','Nyx PC Checkup')|Out-Null}});$script:NyxUi.Content.Controls.Add($folder)
}

function Show-NyxCleanupPage {
    Clear-NyxPage;Add-NyxPageHeading -Title 'Safe cleanup' -Subtitle 'Nothing is selected automatically. Nyx displays the exact supported items, total size, consequence, and confirmation before acting.'
    $full=New-NyxButton -Text 'Refresh with Full Check' -X 24 -Y 116 -Width 210 -Palette $script:NyxUi.Palette -Primary $true;$full.Add_Click({Start-NyxScan -Mode 'Full'});$script:NyxUi.Content.Controls.Add($full)
    $result=$null;if($script:NyxUi.Scan){$r=@($script:NyxUi.Scan.Results|Where-Object{$_.CheckId -eq 'cleanup.preview'}|Select-Object -First 1);if($r.Count -gt 0){$result=$r[0]}}
    if($null -eq $result){Add-NyxNoScanCard -Y 172;return}
    $grid=New-NyxGrid -X 24 -Y 172 -Width (Get-NyxPageWidth) -Height 450 -Palette $script:NyxUi.Palette;$grid.ReadOnly=$false;$grid.EditMode='EditOnEnter'
    $select=New-Object Windows.Forms.DataGridViewCheckBoxColumn;$select.Name='Select';$select.HeaderText='Select';$select.FillWeight=14;[void]$grid.Columns.Add($select)
    [void]$grid.Columns.Add('Category','Category');[void]$grid.Columns.Add('Name','Item');[void]$grid.Columns.Add('Age','Age');[void]$grid.Columns.Add('Size','Size');[void]$grid.Columns.Add('Consequence','What happens')
    $grid.Columns['Category'].FillWeight=32;$grid.Columns['Name'].FillWeight=52;$grid.Columns['Age'].FillWeight=14;$grid.Columns['Size'].FillWeight=18;$grid.Columns['Consequence'].FillWeight=62
    foreach($item in @($result.Details.Candidates)){$consequence=if($item.Category -eq 'Recycle Bin'){'Permanently empties items already in the Recycle Bin.'}else{'Moves this exact item to the Windows Recycle Bin.'};$i=$grid.Rows.Add($false,[string]$item.Category,[string]$item.Name,$(if([int]$item.AgeDays -gt 0){"$($item.AgeDays) days"}else{'—'}),(ConvertTo-NyxBytesText ([int64]$item.SizeBytes)),$consequence);$grid.Rows[$i].Tag=$item;for($c=1;$c -lt $grid.Columns.Count;$c++){$grid.Rows[$i].Cells[$c].ReadOnly=$true}}
    $script:NyxUi.Content.Controls.Add($grid)
    $summary=New-NyxLabel -Text 'Selected: 0 items, 0 B' -X 24 -Y 638 -Width 420 -Height 32 -Size 10 -Bold $true -Palette $script:NyxUi.Palette;$script:NyxUi.Content.Controls.Add($summary)
    $update={ $count=0;$bytes=[int64]0;foreach($row in $grid.Rows){if([bool]$row.Cells['Select'].Value){$count++;$bytes += [int64]$row.Tag.SizeBytes}};$summary.Text="Selected: $count item(s), $(ConvertTo-NyxBytesText $bytes)" }
    $grid.Add_CellValueChanged($update);$grid.Add_CurrentCellDirtyStateChanged({if($grid.IsCurrentCellDirty){$grid.CommitEdit([Windows.Forms.DataGridViewDataErrorContexts]::Commit)}})
    $run=New-NyxButton -Text 'Review and clean selected' -X 24 -Y 682 -Width 230 -Palette $script:NyxUi.Palette -Primary $true
    $run.Add_Click({$ids=New-Object System.Collections.Generic.List[string];$bytes=[int64]0;$recycle=$false;foreach($row in $grid.Rows){if([bool]$row.Cells['Select'].Value){$ids.Add([string]$row.Tag.Id);$bytes += [int64]$row.Tag.SizeBytes;if($row.Tag.Category -eq 'Recycle Bin'){$recycle=$true}}};if($ids.Count -eq 0){[Windows.Forms.MessageBox]::Show('Select at least one displayed item.','Nyx PC Checkup')|Out-Null;return};$text="You selected $($ids.Count) item(s) totaling $(ConvertTo-NyxBytesText $bytes).`r`n`r`nFiles will be moved to the Windows Recycle Bin.";if($recycle){$text+="`r`n`r`nThe Recycle Bin selection will be emptied permanently."};$text+="`r`n`r`nContinue?";$answer=[Windows.Forms.MessageBox]::Show($text,'Confirm destructive cleanup action','YesNo','Warning');if($answer -ne [Windows.Forms.DialogResult]::Yes){return};$res=Invoke-NyxUiAction -Request ([pscustomobject]@{Operation='Cleanup';CandidateIds=@($ids)});if($res){[Windows.Forms.MessageBox]::Show([string]$res.Message,'Nyx PC Checkup')|Out-Null;if([string]$res.Status -in @('Completed','Partial')){$script:NyxUi.FooterLabel.Text='Cleanup finished. Refreshing the read-only cleanup preview.';Start-NyxScan -Mode 'Full';return}};Show-NyxCleanupPage})
    $script:NyxUi.Content.Controls.Add($run)
    $script:NyxUi.Content.Controls.Add((New-NyxLabel -Text 'If a deletion fails, the file is preserved and the exact failure is reported. Nyx never touches Documents, Photos, Videos, browser profiles, update caches, restore points, or application databases through this module.' -X 274 -Y 677 -Width ((Get-NyxPageWidth)-274) -Height 64 -Size 9 -Palette $script:NyxUi.Palette -Color 'Muted'))
}

function Show-NyxSettingsPage {
    Clear-NyxPage;Add-NyxPageHeading -Title 'Settings & privacy' -Subtitle 'Nyx PC Checkup is local-first: no telemetry, no analytics uploads, no account, no advertising, and no forced background process.'
    $config=Get-NyxConfiguration;$w=Get-NyxPageWidth;$card=New-NyxCard -X 24 -Y 122 -Width $w -Height 420 -Palette $script:NyxUi.Palette;$card.Anchor='Top,Left,Right'
    $card.Controls.Add((New-NyxLabel -Text 'Appearance' -X 22 -Y 22 -Width 300 -Height 32 -Size 14 -Bold $true -Palette $script:NyxUi.Palette))
    $card.Controls.Add((New-NyxLabel -Text 'Theme' -X 22 -Y 68 -Width 120 -Height 28 -Size 10 -Palette $script:NyxUi.Palette))
    $theme=New-Object Windows.Forms.ComboBox;$theme.Location=New-Object Drawing.Point(160,64);$theme.Size=New-Object Drawing.Size(220,34);$theme.DropDownStyle='DropDownList';$theme.Font=New-Object Drawing.Font('Segoe UI',10);[void]$theme.Items.AddRange(@('FollowWindows','Dark','Light'));$theme.SelectedItem=[string]$config.theme;$theme.BackColor=$script:NyxUi.Palette.Surface2;$theme.ForeColor=$script:NyxUi.Palette.Text;$card.Controls.Add($theme)
    $notify=New-Object Windows.Forms.CheckBox;$notify.Text='Enable conservative in-app notifications';$notify.Location=New-Object Drawing.Point(22,116);$notify.Size=New-Object Drawing.Size(360,30);$notify.Checked=[bool]$config.notificationsEnabled;$notify.ForeColor=$script:NyxUi.Palette.Text;$notify.BackColor=$script:NyxUi.Palette.Surface;$notify.Font=New-Object Drawing.Font('Segoe UI',10);$card.Controls.Add($notify)
    $card.Controls.Add((New-NyxLabel -Text 'Version 1 does not install a resident background monitor. This setting only controls messages while the app is open.' -X 45 -Y 148 -Width ($w-90) -Height 42 -Size 9 -Palette $script:NyxUi.Palette -Color 'Muted'))
    $card.Controls.Add((New-NyxLabel -Text 'Local data' -X 22 -Y 205 -Width 300 -Height 32 -Size 14 -Bold $true -Palette $script:NyxUi.Palette))
    $open=New-NyxButton -Text 'Open local data folder' -X 22 -Y 250 -Width 190 -Palette $script:NyxUi.Palette;$open.Add_Click({$p=Initialize-NyxDataDirectories;Invoke-NyxOpen 'explorer.exe' ('"'+$p.Root+'"')})
    $logs=New-NyxButton -Text 'Delete local logs' -X 226 -Y 250 -Width 160 -Palette $script:NyxUi.Palette;$logs.Add_Click({$a=[Windows.Forms.MessageBox]::Show('Delete all local Nyx diagnostic logs?','Nyx PC Checkup','YesNo','Question');if($a -eq [Windows.Forms.DialogResult]::Yes){Clear-NyxLogs;[Windows.Forms.MessageBox]::Show('Local logs were deleted.','Nyx PC Checkup')|Out-Null}})
    $card.Controls.AddRange(@($open,$logs))
    $save=New-NyxButton -Text 'Save settings' -X 22 -Y 330 -Width 170 -Palette $script:NyxUi.Palette -Primary $true
    $save.Add_Click({$config.theme=[string]$theme.SelectedItem;$config.notificationsEnabled=[bool]$notify.Checked;Save-NyxConfiguration -Configuration $config;[Windows.Forms.MessageBox]::Show('Settings were saved. Notification changes apply now; theme changes apply the next time Nyx is opened.','Nyx PC Checkup')|Out-Null})
    $card.Controls.Add($save);$script:NyxUi.Content.Controls.Add($card)
    $privacy=New-NyxCard -X 24 -Y 562 -Width $w -Height 190 -Palette $script:NyxUi.Palette;$privacy.Anchor='Top,Left,Right'
    $privacy.Controls.Add((New-NyxLabel -Text 'Privacy promise' -X 22 -Y 20 -Width 300 -Height 32 -Size 14 -Bold $true -Palette $script:NyxUi.Palette))
    $privacy.Controls.Add((New-NyxLabel -Text (Get-NyxPrivacyStatement) -X 22 -Y 61 -Width ($w-50) -Height 34 -Size 11 -Bold $true -Palette $script:NyxUi.Palette))
    $privacy.Controls.Add((New-NyxLabel -Text 'Reports are previewed before export and exclude passwords, tokens, private document contents, browser data, serial numbers, usernames, and IP addresses by default. Logs rotate locally and can be deleted here.' -X 22 -Y 104 -Width ($w-50) -Height 60 -Size 9 -Palette $script:NyxUi.Palette -Color 'Muted'))
    $script:NyxUi.Content.Controls.Add($privacy);$script:NyxUi.Content.AutoScrollMinSize=New-Object Drawing.Size(0,780)
}

function Export-NyxCurrentReport {
    if($null -eq $script:NyxUi.Scan){[Windows.Forms.MessageBox]::Show('Run a check before exporting a report.','Nyx PC Checkup')|Out-Null;return}
    try{$report=New-NyxSafeReport -Scan $script:NyxUi.Scan;$text=ConvertTo-NyxReportText -Report $report;if(-not(Show-NyxReportPreviewDialog -Text $text -Palette $script:NyxUi.Palette)){return};$dialog=New-Object Windows.Forms.SaveFileDialog;$dialog.Title='Export privacy-safe Nyx PC Checkup report';$dialog.Filter='Text report (*.txt)|*.txt|JSON report (*.json)|*.json|PDF summary (*.pdf)|*.pdf';$dialog.FileName='Nyx_PC_Checkup_Report_'+(Get-Date -Format 'yyyyMMdd_HHmmss');if($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK){return};$format=switch($dialog.FilterIndex){1{'TXT'};2{'JSON'};3{'PDF'};default{'TXT'}};Export-NyxReport -Scan $script:NyxUi.Scan -Path $dialog.FileName -Format $format|Out-Null;[Windows.Forms.MessageBox]::Show("Report saved to:`r`n$($dialog.FileName)",'Nyx PC Checkup')|Out-Null}catch{[Windows.Forms.MessageBox]::Show("The report could not be exported.`r`n$($_.Exception.Message)",'Nyx PC Checkup','OK','Error')|Out-Null}
}

function Show-NyxConservativeNotification {
    param([Parameter(Mandatory=$true)][object]$Scan)
    try{
        $config=Get-NyxConfiguration
        if(-not [bool]$config.notificationsEnabled -or [bool]$Scan.Cancelled){return}
        if($null -ne $Scan.PSObject.Properties['WorkerError']){return}
        $important=@($Scan.Results|Where-Object{
            [string]$_.Status -eq 'NeedsAttention' -and (
                [string]$_.Severity -eq 'High' -or
                [string]$_.CheckId -in @('storage.system-drive','updates.restart','updates.pending','drive.health','backup.status')
            )
        }|Select-Object -First 4)
        if($important.Count -eq 0){return}
        $lines=@($important|ForEach-Object{"- $($_.Name): $($_.Finding)"})
        $message="Nyx found $($important.Count) important item(s) worth reviewing:`r`n`r`n"+($lines -join "`r`n")+"`r`n`r`nNo change was made automatically."
        [Windows.Forms.MessageBox]::Show($message,'Nyx PC Checkup - review recommended','OK','Information')|Out-Null
    }catch{Write-NyxLog -Level 'WARN' -Message ("In-app notification could not be shown: {0}" -f $_.Exception.Message)}
}

function Start-NyxScan {
    param([ValidateSet('Quick','Full')][string]$Mode)
    if($script:NyxUi.ScanProcess -and -not $script:NyxUi.ScanProcess.HasExited){return}
    $paths=Initialize-NyxDataDirectories;$id=[guid]::NewGuid().ToString('N');$script:NyxUi.ScanOutput=Join-Path $paths.Temp ("scan-$id.json");$script:NyxUi.ProgressPath=Join-Path $paths.Temp ("scan-$id-progress.jsonl");$script:NyxUi.CancelPath=Join-Path $paths.Temp ("scan-$id.cancel");$script:NyxUi.ProgressLineCount=0
    $worker=Join-Path $script:NyxUi.AppRoot 'workers\ScanWorker.ps1';$args="-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$worker`" -Mode $Mode -OutputPath `"$($script:NyxUi.ScanOutput)`" -ProgressPath `"$($script:NyxUi.ProgressPath)`" -CancelPath `"$($script:NyxUi.CancelPath)`""
    try{$script:NyxUi.ScanProcess=Start-Process -FilePath (Get-NyxPowerShellPath) -ArgumentList $args -WindowStyle Hidden -PassThru;$script:NyxUi.FooterProgress.Value=0;$script:NyxUi.FooterLabel.Text="$Mode check starting. Scanning is read-only.";$script:NyxUi.CancelButton.Enabled=$true;$script:NyxUi.ScanTimer.Start()}catch{[Windows.Forms.MessageBox]::Show("The scan could not start.`r`n$($_.Exception.Message)",'Nyx PC Checkup','OK','Error')|Out-Null}
}
function Update-NyxScanProgress {
    try{
        if($script:NyxUi.ProgressPath -and(Test-Path -LiteralPath $script:NyxUi.ProgressPath)){
            $lines=@(Get-Content -LiteralPath $script:NyxUi.ProgressPath -Encoding UTF8 -ErrorAction SilentlyContinue)
            if($lines.Count -gt $script:NyxUi.ProgressLineCount){
                for($i=$script:NyxUi.ProgressLineCount;$i -lt $lines.Count;$i++){
                    try{$e=$lines[$i]|ConvertFrom-Json;$script:NyxUi.FooterLabel.Text=[string]$e.Message;$p=[int]$e.Percent;if($p -ge 0 -and $p -le 100){$script:NyxUi.FooterProgress.Value=$p}}catch{}
                }
                $script:NyxUi.ProgressLineCount=$lines.Count
            }
        }
        if($script:NyxUi.ScanProcess -and $script:NyxUi.ScanProcess.HasExited){
            $script:NyxUi.ScanTimer.Stop();$script:NyxUi.CancelButton.Enabled=$false
            if(Test-Path -LiteralPath $script:NyxUi.ScanOutput){
                $script:NyxUi.Scan=Get-Content -LiteralPath $script:NyxUi.ScanOutput -Raw -Encoding UTF8|ConvertFrom-Json
                if([bool]$script:NyxUi.Scan.Cancelled){$script:NyxUi.FooterLabel.Text='Check cancelled. Partial results were preserved.'}
                elseif($null -ne $script:NyxUi.Scan.PSObject.Properties['WorkerError']){$script:NyxUi.FooterLabel.Text='The check stopped unexpectedly. No changes were made.'}
                else{$script:NyxUi.FooterLabel.Text=[string]$script:NyxUi.Scan.Summary.Headline}
                $script:NyxUi.FooterProgress.Value=100
                Show-NyxPage -Page $script:NyxUi.CurrentPage
                Show-NyxConservativeNotification -Scan $script:NyxUi.Scan
            }else{$script:NyxUi.FooterLabel.Text='The check ended without a result file. No changes were made.'}
            Remove-Item -LiteralPath $script:NyxUi.ScanOutput,$script:NyxUi.ProgressPath,$script:NyxUi.CancelPath -Force -ErrorAction SilentlyContinue
            $script:NyxUi.ScanProcess=$null
        }
    }catch{Write-NyxLog -Level 'WARN' -Message ("UI progress update failed: {0}" -f $_.Exception.Message)}
}
function Cancel-NyxScan {
    if($script:NyxUi.ScanProcess -and -not $script:NyxUi.ScanProcess.HasExited){Set-Content -LiteralPath $script:NyxUi.CancelPath -Value 'cancel' -Encoding ASCII;$script:NyxUi.FooterLabel.Text='Cancelling safely. Partial results will remain visible.';$script:NyxUi.CancelButton.Enabled=$false}
}

function Show-NyxPage {
    param([string]$Page)
    $script:NyxUi.CurrentPage=$Page;$script:NyxUi.HeaderTitle.Text=$Page
    foreach($button in $script:NyxUi.NavButtons){if([string]$button.Tag -eq $Page){$button.BackColor=$script:NyxUi.Palette.Hover;$button.ForeColor=$script:NyxUi.Palette.Text}else{$button.BackColor=$script:NyxUi.Palette.Rail;$button.ForeColor=$script:NyxUi.Palette.Muted}}
    switch($Page){
        'Home'{Show-NyxHomePage};'Checkup'{Show-NyxCheckupPage};'Storage'{Show-NyxStoragePage};'Startup'{Show-NyxStartupPage};
        'Security'{Show-NyxCategoryPage -Title 'Security' -Subtitle 'Nyx reads Windows security status without disabling, replacing, or modifying protection.' -Categories @('Security') -ActionText 'Open Windows Security' -Action {Invoke-NyxOpen 'windowsdefender:'}};
        'Updates'{Show-NyxCategoryPage -Title 'Windows Updates' -Subtitle 'Nyx reports supported local indicators and opens the official Windows Update interface for action. It never claims full patch assurance from limited data.' -Categories @('Updates') -ActionText 'Open Windows Update' -Action {Invoke-NyxOpen 'ms-settings:windowsupdate'}};
        'Backup'{Show-NyxCategoryPage -Title 'Backup' -Subtitle 'Nyx checks supported Windows indicators and clearly acknowledges that third-party backup services may be undetectable.' -Categories @('Backup') -ActionText 'Open Windows Backup' -Action {Invoke-NyxOpen 'ms-settings:backup'}};
        'System'{Show-NyxCategoryPage -Title 'System details' -Subtitle 'Hardware class, uptime, battery, drive health, performance snapshot, and basic network status. Serial numbers and product keys are not collected.' -Categories @('System','Battery','Drive Health','Performance','Network') -ActionText 'Open Windows System About' -Action {Invoke-NyxOpen 'ms-settings:about'}};
        'Apps'{Show-NyxAppsPage};'Cleanup'{Show-NyxCleanupPage};'Settings'{Show-NyxSettingsPage};default{Show-NyxHomePage}
    }
}

function Show-NyxMainWindow {
    Add-Type -AssemblyName System.Windows.Forms;Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    $config=Get-NyxConfiguration;$theme=Get-NyxEffectiveTheme -Preference ([string]$config.theme);$palette=Get-NyxPalette -Theme $theme
    $appRoot=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path;$installRoot=(Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
    $form=New-Object Windows.Forms.Form;$form.Text='Nyx PC Checkup';$form.Size=New-Object Drawing.Size(1280,820);$form.MinimumSize=New-Object Drawing.Size(1050,700);$form.StartPosition='CenterScreen';$form.BackColor=$palette.Window;$form.ForeColor=$palette.Text;$form.AutoScaleMode='Dpi';$form.Font=New-Object Drawing.Font('Segoe UI',10)
    $iconPath=Join-Path $appRoot 'assets\nyx_pc_checkup.ico';if(Test-Path -LiteralPath $iconPath){try{$form.Icon=New-Object Drawing.Icon($iconPath)}catch{}}
    $rail=New-Object Windows.Forms.Panel;$rail.Dock='Left';$rail.Width=214;$rail.BackColor=$palette.Rail
    $brand=New-NyxLabel -Text 'NYX' -X 22 -Y 20 -Width 80 -Height 38 -Size 22 -Bold $true -Palette $palette;$brand.ForeColor=$palette.Accent2
    $product=New-NyxLabel -Text 'PC Checkup' -X 22 -Y 57 -Width 170 -Height 26 -Size 11 -Bold $true -Palette $palette
    $rail.Controls.AddRange(@($brand,$product))
    $navNames=@('Home','Checkup','Storage','Startup','Security','Updates','Backup','System','Apps','Cleanup','Settings');$navButtons=New-Object System.Collections.Generic.List[object];$y=105
    foreach($name in $navNames){$b=New-NyxNavButton -Text $name -Page $name -Y $y -Palette $palette;$b.Add_Click({param($sender,$eventArgs)Show-NyxPage -Page ([string]$sender.Tag)});$rail.Controls.Add($b);$navButtons.Add($b);$y+=46}
    $version=New-NyxLabel -Text 'v1.0.0 • Local-first' -X 22 -Y 640 -Width 170 -Height 28 -Size 8 -Palette $palette -Color 'Muted';$version.Anchor='Left,Bottom';$rail.Controls.Add($version)
    $header=New-Object Windows.Forms.Panel;$header.Dock='Top';$header.Height=76;$header.BackColor=$palette.Window
    $headerTitle=New-NyxLabel -Text 'Home' -X 28 -Y 20 -Width 400 -Height 36 -Size 16 -Bold $true -Palette $palette
    $export=New-NyxButton -Text 'Export report' -X 820 -Y 18 -Width 150 -Palette $palette;$export.Anchor='Top,Right';$export.Add_Click({Export-NyxCurrentReport})
    $header.Controls.AddRange(@($headerTitle,$export))
    $footer=New-Object Windows.Forms.Panel;$footer.Dock='Bottom';$footer.Height=54;$footer.BackColor=$palette.Rail
    $footerLabel=New-NyxLabel -Text 'Ready. No background monitor is running.' -X 22 -Y 14 -Width 520 -Height 28 -Size 9 -Palette $palette -Color 'Muted'
    $progress=New-Object Windows.Forms.ProgressBar;$progress.Location=New-Object Drawing.Point(550,18);$progress.Size=New-Object Drawing.Size(280,18);$progress.Anchor='Top,Right';$progress.Minimum=0;$progress.Maximum=100
    $cancel=New-NyxButton -Text 'Cancel scan' -X 845 -Y 8 -Width 125 -Height 36 -Palette $palette;$cancel.Anchor='Top,Right';$cancel.Enabled=$false;$cancel.Add_Click({Cancel-NyxScan})
    $footer.Controls.AddRange(@($footerLabel,$progress,$cancel))
    $content=New-Object Windows.Forms.Panel;$content.Dock='Fill';$content.BackColor=$palette.Window;$content.AutoScroll=$true
    $form.Controls.Add($content);$form.Controls.Add($footer);$form.Controls.Add($header);$form.Controls.Add($rail)
    $timer=New-Object Windows.Forms.Timer;$timer.Interval=400;$timer.Add_Tick({Update-NyxScanProgress})
    $last=Get-NyxLastScan
    $script:NyxUi=[ordered]@{Form=$form;Palette=$palette;Theme=$theme;AppRoot=$appRoot;InstallRoot=$installRoot;Rail=$rail;Header=$header;HeaderTitle=$headerTitle;Footer=$footer;FooterLabel=$footerLabel;FooterProgress=$progress;CancelButton=$cancel;Content=$content;NavButtons=@($navButtons);CurrentPage='Home';Scan=$last;ScanProcess=$null;ScanTimer=$timer;ScanOutput='';ProgressPath='';CancelPath='';ProgressLineCount=0}
    $form.Add_FormClosing({
        param($sender,$eventArgs)
        if($script:NyxUi.ScanProcess -and -not $script:NyxUi.ScanProcess.HasExited){
            $a=[Windows.Forms.MessageBox]::Show('A read-only check is still running. Cancel it and close Nyx?','Nyx PC Checkup','YesNo','Question')
            if($a -ne [Windows.Forms.DialogResult]::Yes){$eventArgs.Cancel=$true;return}
            Cancel-NyxScan
            try{
                [void]$script:NyxUi.ScanProcess.WaitForExit(5000)
                if(-not $script:NyxUi.ScanProcess.HasExited){
                    # Scan workers are read-only. Force-stop after the graceful
                    # cancellation window so closing the UI cannot leave an
                    # unnecessary background PowerShell process behind.
                    $script:NyxUi.ScanProcess.Kill()
                    [void]$script:NyxUi.ScanProcess.WaitForExit(2000)
                }
            }catch{}
        }
        $timer.Stop()
        Remove-Item -LiteralPath $script:NyxUi.ScanOutput,$script:NyxUi.ProgressPath,$script:NyxUi.CancelPath -Force -ErrorAction SilentlyContinue
    })
    Show-NyxPage -Page 'Home'
    [void][Windows.Forms.Application]::Run($form)
}

Export-ModuleMember -Function Show-NyxMainWindow
