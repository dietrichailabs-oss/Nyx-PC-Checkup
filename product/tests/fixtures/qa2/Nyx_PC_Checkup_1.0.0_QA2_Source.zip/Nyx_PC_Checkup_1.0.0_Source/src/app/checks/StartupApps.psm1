Set-StrictMode -Version 2.0
Import-Module (Join-Path $PSScriptRoot '..\core\Models.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\core\ActionHistory.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..\platform\windows\WindowsHelpers.psm1') -Force

function Get-NyxExecutableFromCommand {
    param([string]$Command)
    if ([string]::IsNullOrWhiteSpace($Command)) { return '' }
    $expanded = [Environment]::ExpandEnvironmentVariables($Command.Trim())
    if ($expanded.StartsWith('"')) {
        $end = $expanded.IndexOf('"',1)
        if ($end -gt 1) { return $expanded.Substring(1,$end-1) }
    }
    $match = [regex]::Match($expanded,'^(.*?\.(?:exe|com|bat|cmd|ps1|vbs))(?=\s|$)','IgnoreCase')
    if ($match.Success) { return $match.Groups[1].Value.Trim('"') }
    return ($expanded -split '\s+',2)[0].Trim('"')
}

function Get-NyxFilePublisher {
    param([string]$Path)
    try {
        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($Path)
            if ($version.CompanyName) { return [string]$version.CompanyName }
        }
    } catch { }
    return ''
}

function Get-NyxStartupApplications {
    $apps = New-Object System.Collections.Generic.List[object]
    $registrySources = @(
        @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'; Label='Current user Run'; Elevated=$false },
        @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce'; Label='Current user RunOnce'; Elevated=$false },
        @{ Path='HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'; Label='All users Run'; Elevated=$true },
        @{ Path='HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce'; Label='All users RunOnce'; Elevated=$true },
        @{ Path='HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'; Label='All users 32-bit Run'; Elevated=$true }
    )
    foreach ($source in $registrySources) {
        if (-not (Test-Path -LiteralPath $source.Path)) { continue }
        try {
            $item = Get-ItemProperty -LiteralPath $source.Path -ErrorAction Stop
            foreach ($prop in $item.PSObject.Properties) {
                if ($prop.Name.StartsWith('PS')) { continue }
                $command = [string]$prop.Value
                $exe = Get-NyxExecutableFromCommand -Command $command
                $id = Get-NyxStableId -Text ("registry|{0}|{1}" -f $source.Path,$prop.Name)
                $apps.Add([pscustomobject][ordered]@{
                    Id=$id; Name=$prop.Name; Publisher=(Get-NyxFilePublisher -Path $exe); SourceType='Registry';
                    SourcePath=$source.Path; SourceLabel=$source.Label; ValueName=$prop.Name; Command=$command;
                    ExecutablePath=$exe; FileExists=$(if ($exe) { Test-Path -LiteralPath $exe -PathType Leaf } else { $false });
                    Enabled=$true; RequiresElevation=[bool]$source.Elevated; Impact='Not measured'; RollbackActionId=''
                })
            }
        } catch { }
    }
    $startupFolders = @(
        @{ Path=[Environment]::GetFolderPath('Startup'); Label='Current user Startup folder'; Elevated=$false },
        @{ Path=[Environment]::GetFolderPath('CommonStartup'); Label='All users Startup folder'; Elevated=$true }
    )
    foreach ($source in $startupFolders) {
        if (-not (Test-Path -LiteralPath $source.Path -PathType Container)) { continue }
        Get-ChildItem -LiteralPath $source.Path -File -ErrorAction SilentlyContinue | ForEach-Object {
            $id = Get-NyxStableId -Text ("file|{0}" -f $_.FullName)
            $apps.Add([pscustomobject][ordered]@{
                Id=$id; Name=$_.BaseName; Publisher=(Get-NyxFilePublisher -Path $_.FullName); SourceType='StartupFile';
                SourcePath=$_.FullName; SourceLabel=$source.Label; ValueName=''; Command=$_.FullName; ExecutablePath=$_.FullName;
                FileExists=$true; Enabled=$true; RequiresElevation=[bool]$source.Elevated; Impact='Not measured'; RollbackActionId=''
            })
        }
    }
    foreach ($disabled in @(Get-NyxActiveStartupDisables)) {
        try {
            $state = Unprotect-NyxState -ProtectedText ([string]$disabled.ProtectedState)
            $apps.Add([pscustomobject][ordered]@{
                Id=[string]$state.Id; Name=[string]$state.Name; Publisher=[string]$state.Publisher; SourceType=[string]$state.SourceType;
                SourcePath=[string]$state.SourcePath; SourceLabel=[string]$state.SourceLabel; ValueName=[string]$state.ValueName;
                Command=[string]$state.Command; ExecutablePath=[string]$state.ExecutablePath;
                FileExists=$(if ($state.ExecutablePath) { Test-Path -LiteralPath ([string]$state.ExecutablePath) -PathType Leaf } else { $false });
                Enabled=$false; RequiresElevation=[bool]$state.RequiresElevation; Impact='Not measured'; RollbackActionId=[string]$disabled.ActionId
            })
        } catch { }
    }
    return @($apps | Sort-Object -Property @{Expression='Enabled';Descending=$true},@{Expression='Name';Descending=$false})
}

function Get-NyxStartupAppsCheck {
    $apps = @(Get-NyxStartupApplications)
    $enabled = @($apps | Where-Object Enabled)
    $broken = @($enabled | Where-Object { $_.ExecutablePath -and -not $_.FileExists })
    $status = if ($broken.Count -gt 0 -or $enabled.Count -gt 0) { 'Optional' } else { 'Good' }
    $finding = if ($enabled.Count -eq 0) { 'No startup applications were found in the supported locations.' } else { "$($enabled.Count) program(s) start automatically with Windows." }
    $reason = if ($broken.Count -gt 0) { "$($broken.Count) startup entry or entries point to a file that no longer exists. This is not automatically malicious." } elseif ($enabled.Count -gt 0) { 'Startup programs may be useful; review is optional.' } else { 'No supported startup entries require review.' }
    return New-NyxCheckResult -CheckId 'startup.entries' -Category 'Startup' -Name 'Startup applications' -Status $status -Severity 'Low' `
        -Finding $finding -Reason $reason -Evidence ([pscustomobject]@{ EnabledCount=$enabled.Count; DisabledByNyxCount=@($apps | Where-Object { -not $_.Enabled }).Count; BrokenPathCount=$broken.Count; Applications=$apps }) `
        -Recommendation 'Disable only programs you recognize and do not need at sign-in. Nyx records a rollback before changing anything.' `
        -ActionSafetyLevel 'ReversibleLocalChange' -DataSource 'Windows Run registry keys and Startup folders' -Details $apps
}

Export-ModuleMember -Function Get-NyxExecutableFromCommand,Get-NyxStartupApplications,Get-NyxStartupAppsCheck
