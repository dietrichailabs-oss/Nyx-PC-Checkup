# Nyx PC Checkup 1.0.0 — Engineering QA Handoff

**Publisher:** Dietrich AI Labs  
**Build:** `2026.08.23-eng-qa2`  
**Target:** Windows 10/11 x64  
**Candidate status:** Feature-complete Engineering candidate for independent Windows QA  
**Default operation:** Local-only, non-elevated, no telemetry, no background service

## Candidate identity

The primary Windows candidate is `candidate/Nyx_PC_Checkup_1.0.0_Setup.exe`. The portable comparison artifact is `candidate/Nyx_PC_Checkup_1.0.0_Portable.zip`. Exact sizes and SHA-256 values are recorded in `MASTER_MANIFEST.json` and `SHA256SUMS.txt` at the root of the final handoff ZIP.

## What is implemented

Nyx PC Checkup provides a plain-language Quick Check and Full Check covering system information, system-drive space, user folders, Downloads, Windows Update indicators, Windows security indicators, startup entries, backup indicators, uptime, network basics, battery health when present, drive health, a performance snapshot, installed applications, and a safe cleanup preview.

The application uses four deterministic states: **Good**, **Needs Attention**, **Optional**, and **Unknown / Could Not Check**. A healthy result can truthfully display: **“Your PC looks good. Nothing needs fixing.”**

Scanning is read-only. Startup changes require confirmation and are constrained to an allowlist. Current-user changes use a DPAPI CurrentUser-protected write-ahead journal; all-users changes use an administrator-protected ProgramData journal as the authoritative rollback record plus a DPAPI user pointer. Cleanup requires a displayed preview and confirmation, re-enumerates candidates immediately before acting, and sends supported files to the Windows Recycle Bin. Emptying the Recycle Bin is separately identified as permanent.

## Install and test first

Use a disposable Windows 10/11 x64 VM or a QA workstation snapshot.

1. Record the candidate SHA-256 and compare it with `SHA256SUMS.txt`.
2. Run `candidate/Nyx_PC_Checkup_1.0.0_Setup.exe` as a normal user.
3. Run `tests/powershell/Run-WindowsSmokeTests.ps1`.
4. From an elevated PowerShell session in a disposable VM, run `tests/powershell/Run-WindowsElevatedStartupRollback.ps1 -DestructiveCleanVmAcknowledged`.
5. Run `tests/powershell/Run-WindowsInstallerLifecycle.ps1 -SetupPath <exact setup path> -DestructiveCleanVmAcknowledged` from a clean VM snapshot.
6. Execute the independent matrix in `docs/QA_TEST_PLAN.md`.

The setup program installs per-user beneath `%LOCALAPPDATA%\Programs\Dietrich AI Labs\Nyx PC Checkup`; it does not install a service, driver, scheduled task, updater, or resident background process.

## Important test boundary

The candidate was authored and cross-compiled in a Linux engineering environment. Source-contract, safety-invariant, manifest, archive, and PE-format tests were run there. The three included Windows PowerShell suites—normal-user smoke/rollback, elevated all-users rollback, and installer lifecycle—are designed to execute the application’s actual Windows modules and must be run by independent QA on Windows. See `docs/KNOWN_LIMITATIONS.md` and `evidence/ENGINEERING_TEST_REPORT.json` for the exact evidence boundary.

## Bundle map

- `candidate/` — exact installer and portable package
- `source/` — exact buildable source ZIP
- `docs/` — architecture, contracts, operation, security/privacy, limitations, and QA plan
- `tests/` — static tests and executable Windows tests
- `evidence/` — Engineering test reports, PE inspection, packaging evidence, and timing
- `metadata/` — version, SBOM, payload manifest, license, notices, and source identity

## Safety statement

Nyx PC Checkup is not antivirus software, a registry cleaner, a driver updater, a RAM optimizer, or an automatic PC “fixer.” It does not make unsupported speed or security guarantees.

## Routing

Independent QA receives this exact immutable handoff first. Sable and Iris receive only the exact QA-approved candidate and matching hashes afterward. Release Manager may publish only the fully approved immutable artifact. Full routing and authority are in `docs/WHO_GETS_WHAT_NEXT.md`.
