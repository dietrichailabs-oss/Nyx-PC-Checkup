[CmdletBinding()]
param(
    [string]$AppRoot = '',
    [string]$OutputPath = ''
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0

function Add-TestResult {
    param([string]$Name,[bool]$Passed,[string]$Details='')
    $script:Results.Add([pscustomobject][ordered]@{Name=$Name;Passed=$Passed;Details=$Details})
    if(-not $Passed){$script:Failures++}
}
function Assert-True {
    param([string]$Name,[bool]$Condition,[string]$Details='')
    Add-TestResult -Name $Name -Passed $Condition -Details $Details
}
function Get-RunKeySnapshot {
    $paths=@(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'
    )
    $result=New-Object System.Collections.Generic.List[object]
    foreach($path in $paths){
        $values=[ordered]@{}
        try{
            $item=Get-ItemProperty -LiteralPath $path -ErrorAction Stop
            foreach($p in @($item.PSObject.Properties|Where-Object{-not $_.Name.StartsWith('PS')}|Sort-Object Name)){$values[$p.Name]=[string]$p.Value}
        }catch{}
        $result.Add([pscustomobject]@{Path=$path;Values=$values})
    }
    return ($result|ConvertTo-Json -Depth 8 -Compress)
}

$started=(Get-Date).ToUniversalTime()
$script:Results=New-Object System.Collections.Generic.List[object]
$script:Failures=0
if([string]::IsNullOrWhiteSpace($AppRoot)){
    $installed=Join-Path $env:LOCALAPPDATA 'Programs\Dietrich AI Labs\Nyx PC Checkup\app'
    if(Test-Path -LiteralPath $installed -PathType Container){$AppRoot=$installed}else{$AppRoot=(Resolve-Path (Join-Path $PSScriptRoot '..\..\src\app')).Path}
}
$AppRoot=(Resolve-Path $AppRoot).Path
if([string]::IsNullOrWhiteSpace($OutputPath)){$OutputPath=Join-Path (Get-Location) ('Nyx_PC_Checkup_Windows_Smoke_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.json')}

try{
    $parseErrors=New-Object System.Collections.Generic.List[object]
    Get-ChildItem -LiteralPath $AppRoot -Recurse -File|Where-Object{$_.Extension -in @('.ps1','.psm1')}|ForEach-Object{
        $tokens=$null;$errors=$null
        [void][System.Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$tokens,[ref]$errors)
        foreach($error in @($errors)){$parseErrors.Add([pscustomobject]@{File=$_.FullName;Message=$error.Message;Extent=$error.Extent.Text})}
    }
    Assert-True 'PowerShell 5 parser accepts every runtime script' ($parseErrors.Count -eq 0) ($parseErrors|ConvertTo-Json -Depth 5 -Compress)

    Import-Module (Join-Path $AppRoot 'core\Models.psm1') -Force
    Import-Module (Join-Path $AppRoot 'core\Paths.psm1') -Force
    Import-Module (Join-Path $AppRoot 'core\Privacy.psm1') -Force
    Import-Module (Join-Path $AppRoot 'core\Configuration.psm1') -Force
    Import-Module (Join-Path $AppRoot 'health_rules\HealthRules.psm1') -Force
    Import-Module (Join-Path $AppRoot 'reports\PdfWriter.psm1') -Force
    Import-Module (Join-Path $AppRoot 'reports\ReportExport.psm1') -Force
    Import-Module (Join-Path $AppRoot 'checks\StartupApps.psm1') -Force
    Import-Module (Join-Path $AppRoot 'checks\CleanupScan.psm1') -Force
    Import-Module (Join-Path $AppRoot 'actions\StartupActions.psm1') -Force
    Import-Module (Join-Path $AppRoot 'actions\CleanupActions.psm1') -Force

    $healthy=Get-NyxResultSummary -Results @(
        (New-NyxCheckResult -CheckId 't1' -Category 'Test' -Name 'One' -Status Good),
        (New-NyxCheckResult -CheckId 't2' -Category 'Test' -Name 'Two' -Status Good)
    )
    Assert-True 'Healthy acceptance sentence is exact' ($healthy.Headline -eq 'Your PC looks good. Nothing needs fixing.') ([string]$healthy.Headline)
    Assert-True 'Needs Attention outranks other states' ((Get-NyxResultSummary -Results @((New-NyxCheckResult -CheckId a -Category t -Name a -Status Good),(New-NyxCheckResult -CheckId b -Category t -Name b -Status NeedsAttention))).OverallStatus -eq 'NeedsAttention')
    Assert-True 'All Unknown aggregates to Unknown' ((Get-NyxResultSummary -Results @((New-NyxCheckResult -CheckId a -Category t -Name a -Status Unknown))).OverallStatus -eq 'Unknown')

    $gb=[int64]1073741824
    Assert-True 'Thirty GB free is not automatically critical' ((Get-NyxStorageRuleResult -FreeBytes (30*$gb) -TotalBytes (500*$gb)).Status -eq 'Good')
    Assert-True 'Four GB free needs attention' ((Get-NyxStorageRuleResult -FreeBytes (4*$gb) -TotalBytes (500*$gb)).Status -eq 'NeedsAttention')
    Assert-True 'Zero-capacity storage becomes Unknown' ((Get-NyxStorageRuleResult -FreeBytes 0 -TotalBytes 0).Status -eq 'Unknown')
    Assert-True 'Fourteen-day uptime is Optional without pending restart' ((Get-NyxUptimeRuleResult -Days 14 -RestartPending $false).Status -eq 'Optional')
    Assert-True 'Pending restart plus long uptime needs attention' ((Get-NyxUptimeRuleResult -Days 8 -RestartPending $true).Status -eq 'NeedsAttention')
    Assert-True 'Ordinary battery aging remains Optional' ((Get-NyxBatteryRuleResult -HealthPercent 70).Status -eq 'Optional')
    Assert-True 'Severe battery wear needs attention' ((Get-NyxBatteryRuleResult -HealthPercent 40).Status -eq 'NeedsAttention')

    $oldUser=$env:USERNAME
    $secret="user=$oldUser ip=192.168.1.9 token=abc123 password=hunter2 email=a@example.com authorization=Bearer xyz"
    $safe=Protect-NyxText -InputObject $secret
    Assert-True 'Privacy redaction removes username' (-not $safe.Contains($oldUser)) $safe
    Assert-True 'Privacy redaction removes IPv4' (-not $safe.Contains('192.168.1.9')) $safe
    Assert-True 'Privacy redaction removes token/password/authorization values' (-not($safe.Contains('abc123') -or $safe.Contains('hunter2') -or $safe.Contains('xyz'))) $safe
    Assert-True 'Privacy redaction removes email address' (-not $safe.Contains('a@example.com')) $safe

    $startupNoConfirm=Disable-NyxStartupApplication -Application ([pscustomobject]@{Enabled=$true})
    Assert-True 'Startup change without confirmation is rejected' ($startupNoConfirm.Status -eq 'ConfirmationRequired') ([string]$startupNoConfirm.Status)
    $cleanupNoConfirm=Invoke-NyxCleanup -CandidateIds @('not-a-candidate')
    Assert-True 'Cleanup without confirmation is rejected' ($cleanupNoConfirm.Status -eq 'ConfirmationRequired') ([string]$cleanupNoConfirm.Status)
    $boundaryRejected=$false
    try{[void](Test-NyxStartupStateBoundary -State ([pscustomobject]@{SourceType='Registry';SourcePath='HKCU:\Software\Bad';ValueName='x';RequiresElevation=$false}))}catch{$boundaryRejected=$true}
    Assert-True 'Startup registry path outside allowlist is rejected' $boundaryRejected

    $repaired=Repair-NyxConfiguration -Configuration ([pscustomobject]@{
        theme='UnsafeTheme';notificationsEnabled='not-a-boolean';developerLogging=$false;maxLogBytes=-50;maxLogFiles=999;
        actionHistoryLimit=0;reportIncludeUserName=$false;reportIncludeIpAddresses=$false;
        scan=[pscustomobject]@{maxFiles=999999999;maxSeconds=999999;duplicateHashMaxBytes=-1;duplicateHashMaxFiles=999999}
    })
    Assert-True 'Corrupt theme is repaired to FollowWindows' ([string]$repaired.theme -eq 'FollowWindows') ([string]$repaired.theme)
    Assert-True 'Invalid notification boolean is repaired to disabled' (-not [bool]$repaired.notificationsEnabled) ([string]$repaired.notificationsEnabled)
    Assert-True 'Configuration numeric bounds are enforced' ([int64]$repaired.maxLogBytes -eq 65536 -and [int64]$repaired.maxLogFiles -eq 10 -and [int64]$repaired.scan.maxFiles -eq 2000000 -and [int64]$repaired.scan.maxSeconds -eq 900) ($repaired|ConvertTo-Json -Depth 5 -Compress)

    $boundedCleanup=Get-NyxCleanupCandidates -Limit 1 -MaxVisitedFiles 1 -MaxSeconds 1
    Assert-True 'Cleanup preview honors traversal bound' ([int]$boundedCleanup.VisitedFiles -le 1) ("VisitedFiles="+$boundedCleanup.VisitedFiles)
    Assert-True 'Cleanup preview candidates remain unselected by default' (@($boundedCleanup.Candidates|Where-Object{[bool]$_.SelectedByDefault}).Count -eq 0)
    Assert-True 'Cleanup preview exposes completeness and stop reason' ($null -ne $boundedCleanup.PSObject.Properties['Complete'] -and $null -ne $boundedCleanup.PSObject.Properties['LimitReason']) ($boundedCleanup|ConvertTo-Json -Depth 5 -Compress)

    $qaRunPath='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    $qaStartupName='NyxPCCheckup_QA_'+[guid]::NewGuid().ToString('N')
    $qaStartupCommand='"'+(Join-Path $env:SystemRoot 'System32\notepad.exe')+'" --nyx-pc-checkup-rollback-test'
    $qaRollbackId=''
    try{
        if(-not(Test-Path -LiteralPath $qaRunPath)){New-Item -Path $qaRunPath -Force|Out-Null}
        New-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -Value $qaStartupCommand -PropertyType String -Force|Out-Null
        $qaApp=@(Get-NyxStartupApplications|Where-Object{$_.SourcePath -eq $qaRunPath -and $_.ValueName -eq $qaStartupName -and $_.Enabled}|Select-Object -First 1)
        Assert-True 'Current-user QA startup entry is enumerated' ($qaApp.Count -eq 1)
        if($qaApp.Count -eq 1){
            $disabled=Disable-NyxStartupApplication -Application $qaApp[0] -Confirmed
            $qaRollbackId=[string]$disabled.ActionId
            Assert-True 'Current-user startup disable completes' ([bool]$disabled.Success -and [string]$disabled.Status -eq 'Completed') ($disabled|ConvertTo-Json -Depth 6 -Compress)
            $stillPresent=$true
            try{[void](Get-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -ErrorAction Stop)}catch{$stillPresent=$false}
            Assert-True 'Startup disable removes only the selected value' (-not $stillPresent)
            Assert-True 'Current-user rollback journal is active' (@(Get-NyxActiveStartupDisables|Where-Object{$_.ActionId -eq $qaRollbackId}).Count -eq 1)
            $restored=Enable-NyxStartupApplication -RollbackActionId $qaRollbackId -Confirmed
            Assert-True 'Current-user startup restore completes' ([bool]$restored.Success -and [string]$restored.Status -eq 'Completed') ($restored|ConvertTo-Json -Depth 6 -Compress)
            $actualCommand=(Get-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -ErrorAction Stop).($qaStartupName)
            Assert-True 'Startup restore preserves the exact command' ([string]$actualCommand -eq $qaStartupCommand) ([string]$actualCommand)
            Assert-True 'Successful restore closes active journal' (@(Get-NyxActiveStartupDisables|Where-Object{$_.ActionId -eq $qaRollbackId}).Count -eq 0)
            $qaRollbackId=''
        }
    }catch{
        Add-TestResult -Name 'Current-user startup rollback round trip completed without error' -Passed $false -Details $_.Exception.ToString()
    }finally{
        if($qaRollbackId){
            Remove-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -Force -ErrorAction SilentlyContinue
            try{[void](Enable-NyxStartupApplication -RollbackActionId $qaRollbackId -Confirmed)}catch{}
        }
        Remove-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -Force -ErrorAction SilentlyContinue
    }

    $paths=Initialize-NyxDataDirectories
    $pdf=Join-Path $paths.Temp ('smoke-'+[guid]::NewGuid().ToString('N')+'.pdf')
    Write-NyxSimplePdf -Path $pdf -Lines @('Nyx PC Checkup','Unicode is safely normalized: café')
    $bytes=[IO.File]::ReadAllBytes($pdf)
    $header=[Text.Encoding]::ASCII.GetString($bytes,0,[Math]::Min(5,$bytes.Length))
    Assert-True 'PDF writer creates a PDF header' ($header -eq '%PDF-') $header
    Remove-Item -LiteralPath $pdf -Force -ErrorAction SilentlyContinue

    $fake=[pscustomobject]@{Mode='Quick';StartedUtc=(Get-Date).ToUniversalTime().ToString('o');CompletedUtc=(Get-Date).ToUniversalTime().ToString('o');Summary=$healthy;Results=@((New-NyxCheckResult -CheckId 'network.basics' -Category Network -Name Network -Status Good -Evidence ([pscustomobject]@{Adapters=@();Profiles=@();DnsResolutionSucceeded=$true}) -Finding $secret -Reason $secret -Recommendation $secret))}
    $reportJson=(New-NyxSafeReport -Scan $fake|ConvertTo-Json -Depth 15)
    Assert-True 'Export report redacts injected secrets' (-not($reportJson.Contains('192.168.1.9') -or $reportJson.Contains('abc123') -or $reportJson.Contains('hunter2') -or $reportJson.Contains('a@example.com'))) $reportJson

    $before=Get-RunKeySnapshot
    $sentinel=Join-Path $paths.Temp ('scan-sentinel-'+[guid]::NewGuid().ToString('N')+'.txt')
    [IO.File]::WriteAllText($sentinel,'Nyx scan must not modify this file',[Text.Encoding]::UTF8)
    $sentinelHash=(Get-FileHash -LiteralPath $sentinel -Algorithm SHA256).Hash
    $id=[guid]::NewGuid().ToString('N')
    $out=Join-Path $paths.Temp ("scan-$id.json")
    $progress=Join-Path $paths.Temp ("scan-$id-progress.jsonl")
    $cancel=Join-Path $paths.Temp ("scan-$id.cancel")
    $worker=Join-Path $AppRoot 'workers\ScanWorker.ps1'
    $args="-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$worker`" -Mode Quick -OutputPath `"$out`" -ProgressPath `"$progress`" -CancelPath `"$cancel`""
    $proc=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $args -WindowStyle Hidden -Wait -PassThru
    Assert-True 'Quick scan worker exits successfully' ($proc.ExitCode -eq 0) ("ExitCode="+$proc.ExitCode)
    Assert-True 'Quick scan produced a result file' (Test-Path -LiteralPath $out -PathType Leaf)
    if(Test-Path -LiteralPath $out -PathType Leaf){
        $scan=Get-Content -LiteralPath $out -Raw -Encoding UTF8|ConvertFrom-Json
        Assert-True 'Scan envelope is explicitly read-only' ([bool]$scan.ReadOnly)
        Assert-True 'Quick scan returned results' (@($scan.Results).Count -ge 8) ("Count="+@($scan.Results).Count)
        Assert-True 'Quick scan status values are valid' (@($scan.Results|Where-Object{$_.Status -notin @('Good','NeedsAttention','Optional','Unknown')}).Count -eq 0)
        Assert-True 'Every result has explanation fields' (@($scan.Results|Where-Object{[string]::IsNullOrWhiteSpace([string]$_.CheckId) -or [string]::IsNullOrWhiteSpace([string]$_.Finding) -or [string]::IsNullOrWhiteSpace([string]$_.Reason) -or [string]::IsNullOrWhiteSpace([string]$_.Recommendation)}).Count -eq 0)
        Assert-True 'Quick scan had no worker-level fatal error' ($null -eq $scan.PSObject.Properties['WorkerError'])
    }
    $after=Get-RunKeySnapshot
    Assert-True 'Quick scan did not modify supported startup registry keys' ($before -eq $after)
    Assert-True 'Quick scan did not modify sentinel file' ((Get-FileHash -LiteralPath $sentinel -Algorithm SHA256).Hash -eq $sentinelHash)
    Remove-Item -LiteralPath $out,$progress,$cancel,$sentinel -Force -ErrorAction SilentlyContinue
}catch{
    Add-TestResult -Name 'Smoke test harness completed without unhandled error' -Passed $false -Details $_.Exception.ToString()
}

$stopped=(Get-Date).ToUniversalTime()
$report=[pscustomobject][ordered]@{
    Schema='dietrich-ai-labs.nyx-pc-checkup.windows-smoke.v1'
    StartedUtc=$started.ToString('o')
    CompletedUtc=$stopped.ToString('o')
    ElapsedSeconds=[math]::Round(($stopped-$started).TotalSeconds,3)
    ComputerName=$env:COMPUTERNAME
    WindowsVersion=[Environment]::OSVersion.VersionString
    PowerShellVersion=$PSVersionTable.PSVersion.ToString()
    IsAdministrator=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    AppRoot=$AppRoot
    Passed=($script:Failures -eq 0)
    Total=$script:Results.Count
    Failed=$script:Failures
    Results=@($script:Results)
}
$report|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Host ("Windows smoke tests: {0}/{1} passed. Evidence: {2}" -f ($report.Total-$report.Failed),$report.Total,$OutputPath)
if($script:Failures -gt 0){exit 1}
exit 0
