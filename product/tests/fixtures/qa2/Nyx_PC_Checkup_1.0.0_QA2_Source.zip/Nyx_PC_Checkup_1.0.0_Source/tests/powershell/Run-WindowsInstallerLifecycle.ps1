[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$SetupPath,
    [switch]$DestructiveCleanVmAcknowledged,
    [string]$OutputPath=''
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
if(-not $DestructiveCleanVmAcknowledged){throw 'This test installs, repairs, uninstalls, and purges Nyx PC Checkup. Run only in a disposable clean Windows VM and pass -DestructiveCleanVmAcknowledged.'}
$SetupPath=(Resolve-Path $SetupPath).Path
if([string]::IsNullOrWhiteSpace($OutputPath)){$OutputPath=Join-Path (Get-Location) ('Nyx_PC_Checkup_Installer_Lifecycle_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.json')}
$installRoot=Join-Path $env:LOCALAPPDATA 'Programs\Dietrich AI Labs\Nyx PC Checkup'
$dataRoot=Join-Path $env:LOCALAPPDATA 'Dietrich AI Labs\Nyx PC Checkup'
$uninstallKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\NyxPCCheckup'
$startLink=Join-Path ([Environment]::GetFolderPath('Programs')) 'Dietrich AI Labs\Nyx PC Checkup.lnk'
$desktopLink=Join-Path ([Environment]::GetFolderPath('Desktop')) 'Nyx PC Checkup.lnk'
$results=New-Object System.Collections.Generic.List[object];$failures=0
function Test-Step([string]$Name,[bool]$Passed,[string]$Details=''){$script:results.Add([pscustomobject]@{Name=$Name;Passed=$Passed;Details=$Details});if(-not $Passed){$script:failures++}}
function Run-Exe([string]$Path,[string]$Arguments){$p=Start-Process -FilePath $Path -ArgumentList $Arguments -Wait -PassThru;return $p.ExitCode}
function Wait-Absent([string]$Path,[int]$Seconds=20){for($i=0;$i -lt ($Seconds*5);$i++){if(-not(Test-Path -LiteralPath $Path)){return $true};Start-Sleep -Milliseconds 200};return $false}
function Verify-Payload {
    param([string]$Root)
    $manifest=Get-Content -LiteralPath (Join-Path $Root 'PAYLOAD_MANIFEST.json') -Raw -Encoding UTF8|ConvertFrom-Json
    $fail=New-Object System.Collections.Generic.List[string]
    $expected=@{}
    foreach($e in @($manifest.files)){$expected[[string]$e.path]=$e;$full=Join-Path $Root ([string]$e.path).Replace('/','\');if(-not(Test-Path -LiteralPath $full -PathType Leaf)){$fail.Add('missing '+$e.path);continue};$f=Get-Item -LiteralPath $full;if($f.Length -ne [int64]$e.size){$fail.Add('size '+$e.path)};if((Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash -ne [string]$e.sha256){$fail.Add('hash '+$e.path)}}
    $actual=@(Get-ChildItem -LiteralPath $Root -Recurse -File|Where-Object{$_.Name -ne 'install-state.json' -and $_.Name -ne 'PAYLOAD_MANIFEST.json'})
    foreach($f in $actual){$rel=$f.FullName.Substring($Root.Length).TrimStart('\').Replace('\','/');if(-not $expected.ContainsKey($rel)){$fail.Add('unexpected '+$rel)}}
    return @($fail)
}

$started=(Get-Date).ToUniversalTime()
try{
    if(Test-Path -LiteralPath $installRoot){
        $oldUninstaller=Join-Path $installRoot 'Uninstall Nyx PC Checkup.exe'
        if(Test-Path -LiteralPath $oldUninstaller){[void](Run-Exe $oldUninstaller '/quiet /purgedata');[void](Wait-Absent $installRoot)}
        if(Test-Path -LiteralPath $installRoot){throw 'A prior installation remains. Revert the clean VM snapshot.'}
    }
    Remove-Item -LiteralPath $dataRoot -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $uninstallKey -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $startLink,$desktopLink -Force -ErrorAction SilentlyContinue

    $code=Run-Exe $SetupPath '/quiet /nolaunch'
    Test-Step 'Fresh quiet install exits 0' ($code -eq 0) ("ExitCode=$code")
    Test-Step 'Install root exists' (Test-Path -LiteralPath $installRoot -PathType Container)
    Test-Step 'Launcher exists' (Test-Path -LiteralPath (Join-Path $installRoot 'Nyx PC Checkup.exe') -PathType Leaf)
    Test-Step 'Uninstaller exists' (Test-Path -LiteralPath (Join-Path $installRoot 'Uninstall Nyx PC Checkup.exe') -PathType Leaf)
    $payloadProblems=@(Verify-Payload $installRoot)
    Test-Step 'Installed payload matches exact manifest' ($payloadProblems.Count -eq 0) ($payloadProblems -join '; ')
    Test-Step 'Start-menu shortcut exists' (Test-Path -LiteralPath $startLink -PathType Leaf)
    Test-Step 'Desktop shortcut is absent when not requested' (-not(Test-Path -LiteralPath $desktopLink))
    Test-Step 'Uninstall registration exists' (Test-Path -LiteralPath $uninstallKey)

    $mutex=New-Object Threading.Mutex($true,'Local\DietrichAI.NyxPCCheckup.v1',[ref]$created)
    try{$code=Run-Exe $SetupPath '/quiet /nolaunch';Test-Step 'Installer rejects running application mutex' ($code -eq 10) ("ExitCode=$code")}finally{if($created){$mutex.ReleaseMutex()};$mutex.Dispose()}

    $repairProbe=Join-Path $installRoot 'docs\USER_GUIDE.md'
    Add-Content -LiteralPath $repairProbe -Value 'intentional QA repair corruption'
    $code=Run-Exe $SetupPath '/quiet /nolaunch /desktop'
    Test-Step 'Same-version repair exits 0' ($code -eq 0) ("ExitCode=$code")
    $payloadProblems=@(Verify-Payload $installRoot)
    Test-Step 'Repair restores exact payload' ($payloadProblems.Count -eq 0) ($payloadProblems -join '; ')
    Test-Step 'Desktop shortcut created when requested' (Test-Path -LiteralPath $desktopLink -PathType Leaf)

    New-Item -ItemType Directory -Path $dataRoot -Force|Out-Null
    $marker=Join-Path $dataRoot 'qa-preserve-marker.txt';Set-Content -LiteralPath $marker -Value 'preserve' -Encoding ASCII
    $uninstaller=Join-Path $installRoot 'Uninstall Nyx PC Checkup.exe'

    # Prove uninstall is fail-closed when a reversible startup entry cannot be
    # restored. The first uninstall must leave the application, registration,
    # shortcut, and recovery journal intact. After the conflict is removed,
    # the second uninstall restores the exact value and completes.
    $qaRunPath='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    $qaStartupName='NyxPCCheckup_QA_Uninstall_'+[guid]::NewGuid().ToString('N')
    $qaStartupCommand='"'+(Join-Path $env:SystemRoot 'System32\notepad.exe')+'" --nyx-pc-checkup-uninstall-rollback-test'
    $qaConflictCommand='"'+(Join-Path $env:SystemRoot 'System32\cmd.exe')+'" /c exit 0'
    $qaRollbackId=''
    try{
        Import-Module (Join-Path $installRoot 'app\checks\StartupApps.psm1') -Force
        Import-Module (Join-Path $installRoot 'app\actions\StartupActions.psm1') -Force
        Import-Module (Join-Path $installRoot 'app\core\ActionHistory.psm1') -Force
        if(-not(Test-Path -LiteralPath $qaRunPath)){New-Item -Path $qaRunPath -Force|Out-Null}
        New-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -Value $qaStartupCommand -PropertyType String -Force|Out-Null
        $qaApp=@(Get-NyxStartupApplications|Where-Object{$_.SourcePath -eq $qaRunPath -and $_.ValueName -eq $qaStartupName -and $_.Enabled}|Select-Object -First 1)
        Test-Step 'Uninstall regression startup fixture is enumerated' ($qaApp.Count -eq 1)
        if($qaApp.Count -ne 1){throw 'The uninstall rollback fixture was not enumerated.'}
        $disabled=Disable-NyxStartupApplication -Application $qaApp[0] -Confirmed
        $qaRollbackId=[string]$disabled.ActionId
        Test-Step 'Uninstall regression startup fixture is disabled' ([bool]$disabled.Success -and [string]$disabled.Status -eq 'Completed') ($disabled|ConvertTo-Json -Depth 6 -Compress)
        if(-not $disabled.Success){throw 'The uninstall rollback fixture could not be disabled.'}
        New-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -Value $qaConflictCommand -PropertyType String -Force|Out-Null

        $code=Run-Exe $uninstaller '/quiet'
        Test-Step 'Uninstall aborts with exit 6 when startup restoration conflicts' ($code -eq 6) ("ExitCode=$code")
        Test-Step 'Failed restore preserves install root' (Test-Path -LiteralPath $installRoot -PathType Container)
        Test-Step 'Failed restore preserves uninstall registration' (Test-Path -LiteralPath $uninstallKey)
        Test-Step 'Failed restore preserves Start shortcut' (Test-Path -LiteralPath $startLink -PathType Leaf)
        Test-Step 'Failed restore preserves active rollback journal' (@(Get-NyxActiveStartupDisables|Where-Object{$_.ActionId -eq $qaRollbackId}).Count -eq 1)
        Test-Step 'Failed restore preserves local data' (Test-Path -LiteralPath $marker -PathType Leaf)

        Remove-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -Force -ErrorAction Stop
        $code=Run-Exe $uninstaller '/quiet'
        Test-Step 'Quiet uninstall exits 0 after conflict is removed' ($code -eq 0) ("ExitCode=$code")
        $restoredCommand=(Get-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -ErrorAction Stop).($qaStartupName)
        Test-Step 'Uninstall restores exact startup command before removal' ([string]$restoredCommand -eq $qaStartupCommand) ([string]$restoredCommand)
        Test-Step 'Quiet uninstall removes install root' (Wait-Absent $installRoot)
        Test-Step 'Quiet uninstall preserves local data' (Test-Path -LiteralPath $marker -PathType Leaf)
        Test-Step 'Quiet uninstall removes registration' (-not(Test-Path -LiteralPath $uninstallKey))
        Test-Step 'Quiet uninstall removes Start shortcut' (-not(Test-Path -LiteralPath $startLink))
        $startFolder=Split-Path -Parent $startLink
        Test-Step 'Quiet uninstall removes empty Dietrich AI Labs Start folder' (Wait-Absent $startFolder 5)
        $qaRollbackId=''
    }finally{
        Remove-ItemProperty -LiteralPath $qaRunPath -Name $qaStartupName -Force -ErrorAction SilentlyContinue
        if($qaRollbackId -and (Test-Path -LiteralPath $installRoot -PathType Container)){
            try{[void](Enable-NyxStartupApplication -RollbackActionId $qaRollbackId -Confirmed)}catch{}
        }
    }

    $code=Run-Exe $SetupPath '/quiet /nolaunch'
    Test-Step 'Reinstall after uninstall exits 0' ($code -eq 0) ("ExitCode=$code")
    $uninstaller=Join-Path $installRoot 'Uninstall Nyx PC Checkup.exe'
    $code=Run-Exe $uninstaller '/quiet /purgedata'
    Test-Step 'Explicit purge uninstall exits 0' ($code -eq 0) ("ExitCode=$code")
    Test-Step 'Purge uninstall removes install root' (Wait-Absent $installRoot)
    Test-Step 'Purge uninstall removes local data' (Wait-Absent $dataRoot)
    Test-Step 'Purge uninstall removes registration' (-not(Test-Path -LiteralPath $uninstallKey))
    Test-Step 'No Nyx service was installed' (@(Get-Service -ErrorAction SilentlyContinue|Where-Object{$_.Name -like '*Nyx*PC*Checkup*'}).Count -eq 0)
    try{Test-Step 'No Nyx scheduled task was installed' (@(Get-ScheduledTask -ErrorAction Stop|Where-Object{$_.TaskName -like '*Nyx*PC*Checkup*'}).Count -eq 0)}catch{Test-Step 'No Nyx scheduled task was installed' $true 'ScheduledTasks API unavailable; package manifest still contains no task component.'}
}catch{Test-Step 'Lifecycle harness completed without unhandled error' $false $_.Exception.ToString()}
$stopped=(Get-Date).ToUniversalTime()
$report=[pscustomobject][ordered]@{Schema='dietrich-ai-labs.nyx-pc-checkup.installer-lifecycle.v1';StartedUtc=$started.ToString('o');CompletedUtc=$stopped.ToString('o');ElapsedSeconds=[math]::Round(($stopped-$started).TotalSeconds,3);ComputerName=$env:COMPUTERNAME;WindowsVersion=[Environment]::OSVersion.VersionString;SetupPath=$SetupPath;SetupSha256=(Get-FileHash -LiteralPath $SetupPath -Algorithm SHA256).Hash;Passed=($failures -eq 0);Total=$results.Count;Failed=$failures;Results=@($results)}
$report|ConvertTo-Json -Depth 10|Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Host ("Installer lifecycle: {0}/{1} passed. Evidence: {2}" -f ($report.Total-$report.Failed),$report.Total,$OutputPath)
if($failures -gt 0){exit 1};exit 0
