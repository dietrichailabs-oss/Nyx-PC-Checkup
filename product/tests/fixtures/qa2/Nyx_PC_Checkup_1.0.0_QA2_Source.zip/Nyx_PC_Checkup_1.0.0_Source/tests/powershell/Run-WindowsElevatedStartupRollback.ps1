[CmdletBinding()]
param(
    [string]$AppRoot='',
    [switch]$DestructiveCleanVmAcknowledged,
    [string]$OutputPath=''
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
if(-not $DestructiveCleanVmAcknowledged){throw 'This test creates and removes one temporary HKLM Run value. Run only in a disposable Windows QA VM and pass -DestructiveCleanVmAcknowledged.'}

function Add-TestResult {
    param([string]$Name,[bool]$Passed,[string]$Details='')
    $script:Results.Add([pscustomobject][ordered]@{Name=$Name;Passed=$Passed;Details=$Details})
    if(-not $Passed){$script:Failures++}
}
function Assert-True { param([string]$Name,[bool]$Condition,[string]$Details='') Add-TestResult -Name $Name -Passed $Condition -Details $Details }
function Get-IdentitySid([object]$IdentityReference){
    try{return [string]$IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value}catch{return [string]$IdentityReference.Value}
}

$started=(Get-Date).ToUniversalTime()
$script:Results=New-Object System.Collections.Generic.List[object]
$script:Failures=0
$isAdmin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if(-not $isAdmin){throw 'Run this dedicated test from an elevated Windows PowerShell 5.1 session.'}
if([string]::IsNullOrWhiteSpace($AppRoot)){
    $installed=Join-Path $env:LOCALAPPDATA 'Programs\Dietrich AI Labs\Nyx PC Checkup\app'
    if(Test-Path -LiteralPath $installed -PathType Container){$AppRoot=$installed}else{$AppRoot=(Resolve-Path (Join-Path $PSScriptRoot '..\..\src\app')).Path}
}
$AppRoot=(Resolve-Path $AppRoot).Path
if([string]::IsNullOrWhiteSpace($OutputPath)){$OutputPath=Join-Path (Get-Location) ('Nyx_PC_Checkup_Elevated_Startup_Rollback_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.json')}

Import-Module (Join-Path $AppRoot 'core\Models.psm1') -Force
Import-Module (Join-Path $AppRoot 'core\Paths.psm1') -Force
Import-Module (Join-Path $AppRoot 'core\ActionHistory.psm1') -Force
Import-Module (Join-Path $AppRoot 'checks\StartupApps.psm1') -Force
Import-Module (Join-Path $AppRoot 'actions\StartupActions.psm1') -Force

$runPath='HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'
$name='NyxPCCheckup_QA_Machine_'+[guid]::NewGuid().ToString('N')
$command='"'+(Join-Path $env:SystemRoot 'System32\notepad.exe')+'" --nyx-pc-checkup-machine-rollback-test'
$rollbackId=''
$userFolder=''
$machineFolder=''
try{
    if(-not(Test-Path -LiteralPath $runPath)){New-Item -Path $runPath -Force|Out-Null}
    New-ItemProperty -LiteralPath $runPath -Name $name -Value $command -PropertyType String -Force|Out-Null
    $app=@(Get-NyxStartupApplications|Where-Object{$_.SourcePath -eq $runPath -and $_.ValueName -eq $name -and $_.Enabled}|Select-Object -First 1)
    Assert-True 'Temporary all-users startup entry is enumerated' ($app.Count -eq 1)
    if($app.Count -ne 1){throw 'The temporary all-users startup entry was not enumerated.'}
    Assert-True 'All-users entry requires action-specific elevation' ([bool]$app[0].RequiresElevation)

    $disabled=Disable-NyxStartupApplication -Application $app[0] -Confirmed
    $rollbackId=[string]$disabled.ActionId
    Assert-True 'Elevated all-users startup disable completes' ([bool]$disabled.Success -and [string]$disabled.Status -eq 'Completed') ($disabled|ConvertTo-Json -Depth 8 -Compress)
    $present=$true
    try{[void](Get-ItemProperty -LiteralPath $runPath -Name $name -ErrorAction Stop)}catch{$present=$false}
    Assert-True 'Only the selected HKLM Run value was removed' (-not $present)

    $paths=Initialize-NyxDataDirectories
    $userFolder=Join-Path $paths.DisabledStartup $rollbackId
    $pointerPath=Join-Path $userFolder 'rollback.dpapi'
    $machineFolder=Join-Path (Join-Path $env:ProgramData 'DietrichAI.NyxPCCheckup\startup-rollback') $rollbackId
    $machineJournal=Join-Path $machineFolder 'rollback.json'
    Assert-True 'Current-user DPAPI pointer exists' (Test-Path -LiteralPath $pointerPath -PathType Leaf)
    Assert-True 'Administrator-protected machine journal exists' (Test-Path -LiteralPath $machineJournal -PathType Leaf)

    $machineState=Get-Content -LiteralPath $machineJournal -Raw -Encoding UTF8|ConvertFrom-Json
    Assert-True 'Machine journal records exact identity' ([string]$machineState.ActionId -eq $rollbackId -and [string]$machineState.SourcePath -eq $runPath -and [string]$machineState.ValueName -eq $name -and [string]$machineState.Command -eq $command) ($machineState|ConvertTo-Json -Depth 8 -Compress)
    Assert-True 'Machine journal is bound to current user SID' ([string]$machineState.OwnerSid -eq [string][Security.Principal.WindowsIdentity]::GetCurrent().User.Value) ([string]$machineState.OwnerSid)

    $acl=Get-Acl -LiteralPath $machineFolder
    Assert-True 'Machine rollback ACL inheritance is disabled' ([bool]$acl.AreAccessRulesProtected)
    $ownerSid=[string][Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $writeMask=[Security.AccessControl.FileSystemRights]::Write -bor [Security.AccessControl.FileSystemRights]::Modify -bor [Security.AccessControl.FileSystemRights]::FullControl -bor [Security.AccessControl.FileSystemRights]::Delete -bor [Security.AccessControl.FileSystemRights]::ChangePermissions -bor [Security.AccessControl.FileSystemRights]::TakeOwnership
    $userWriteRules=@($acl.Access|Where-Object{(Get-IdentitySid $_.IdentityReference) -eq $ownerSid -and $_.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and (($_.FileSystemRights -band $writeMask) -ne 0)})
    Assert-True 'Owner user has no write authority over machine journal' ($userWriteRules.Count -eq 0) ($userWriteRules|ConvertTo-Json -Depth 5 -Compress)

    # The pointer is intentionally user-writable. Tamper its displayed source
    # fields and prove the elevated restore still uses only the protected
    # ProgramData journal as authority.
    $protected=(Get-Content -LiteralPath $pointerPath -Raw -Encoding UTF8).Trim()
    $pointer=Unprotect-NyxState -ProtectedText $protected
    $pointer.SourcePath='HKLM:\Software\NyxPointerMustNeverAuthorizeWrites'
    $pointer.ValueName='TamperedPointerValue'
    $pointer.Command='tampered-pointer-command.exe'
    [IO.File]::WriteAllText($pointerPath,(Protect-NyxState -State $pointer),[Text.Encoding]::UTF8)

    $restored=Enable-NyxStartupApplication -RollbackActionId $rollbackId -Confirmed
    Assert-True 'Restore ignores tampered user pointer and succeeds from machine authority' ([bool]$restored.Success -and [string]$restored.Status -eq 'Completed') ($restored|ConvertTo-Json -Depth 8 -Compress)
    $actual=(Get-ItemProperty -LiteralPath $runPath -Name $name -ErrorAction Stop).($name)
    Assert-True 'All-users startup command is restored exactly' ([string]$actual -eq $command) ([string]$actual)
    Assert-True 'Successful restore closes user pointer' (-not(Test-Path -LiteralPath $userFolder))
    Assert-True 'Successful restore closes machine journal' (-not(Test-Path -LiteralPath $machineFolder))
    $rollbackId=''
}catch{
    Add-TestResult -Name 'Elevated startup rollback harness completed without unhandled error' -Passed $false -Details $_.Exception.ToString()
}finally{
    Remove-ItemProperty -LiteralPath $runPath -Name $name -Force -ErrorAction SilentlyContinue
    if($rollbackId){
        try{[void](Enable-NyxStartupApplication -RollbackActionId $rollbackId -Confirmed)}catch{}
    }
    if($userFolder){Remove-Item -LiteralPath $userFolder -Recurse -Force -ErrorAction SilentlyContinue}
    if($machineFolder){Remove-Item -LiteralPath $machineFolder -Recurse -Force -ErrorAction SilentlyContinue}
}

$stopped=(Get-Date).ToUniversalTime()
$report=[pscustomobject][ordered]@{
    Schema='dietrich-ai-labs.nyx-pc-checkup.elevated-startup-rollback.v1'
    StartedUtc=$started.ToString('o')
    CompletedUtc=$stopped.ToString('o')
    ElapsedSeconds=[math]::Round(($stopped-$started).TotalSeconds,3)
    ComputerName=$env:COMPUTERNAME
    WindowsVersion=[Environment]::OSVersion.VersionString
    PowerShellVersion=$PSVersionTable.PSVersion.ToString()
    IsAdministrator=$isAdmin
    AppRoot=$AppRoot
    Passed=($script:Failures -eq 0)
    Total=$script:Results.Count
    Failed=$script:Failures
    Results=@($script:Results)
}
$report|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Host ("Elevated startup rollback: {0}/{1} passed. Evidence: {2}" -f ($report.Total-$report.Failed),$report.Total,$OutputPath)
if($script:Failures -gt 0){exit 1}
exit 0
