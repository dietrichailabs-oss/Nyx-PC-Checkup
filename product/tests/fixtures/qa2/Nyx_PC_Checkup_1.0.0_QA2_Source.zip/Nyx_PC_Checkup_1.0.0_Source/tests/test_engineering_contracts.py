from __future__ import annotations

import hashlib
import json
import re
import struct
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath

import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "src" / "app"
DIST = ROOT / "dist"
STAGE = ROOT / "release_staging" / "Nyx_PC_Checkup_1.0.0_Portable"

EXPECTED_MODULES = {
    "core/Models.psm1",
    "core/Paths.psm1",
    "core/Configuration.psm1",
    "core/Diagnostics.psm1",
    "core/Privacy.psm1",
    "core/CheckupEngine.psm1",
    "core/ActionHistory.psm1",
    "health_rules/HealthRules.psm1",
    "checks/SystemInfo.psm1",
    "checks/StorageHealth.psm1",
    "checks/StorageScan.psm1",
    "checks/DownloadsAnalysis.psm1",
    "checks/StartupApps.psm1",
    "checks/WindowsUpdates.psm1",
    "checks/SecurityStatus.psm1",
    "checks/BackupStatus.psm1",
    "checks/BatteryHealth.psm1",
    "checks/PerformanceSnapshot.psm1",
    "checks/DriveHealth.psm1",
    "checks/InstalledApps.psm1",
    "checks/Uptime.psm1",
    "checks/NetworkBasics.psm1",
    "checks/CleanupScan.psm1",
    "actions/StartupActions.psm1",
    "actions/CleanupActions.psm1",
    "reports/ReportExport.psm1",
    "reports/PdfWriter.psm1",
    "ui/Theme.psm1",
    "ui/Controls.psm1",
    "ui/Dialogs.psm1",
    "ui/MainWindow.psm1",
    "workers/ScanWorker.ps1",
    "workers/ActionWorker.ps1",
    "workers/InstallWorker.ps1",
    "workers/UninstallWorker.ps1",
    "platform/windows/WindowsHelpers.psm1",
}


def text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def all_runtime_source() -> str:
    return "\n".join(text(p) for p in sorted(APP.rglob("*")) if p.suffix.lower() in {".ps1", ".psm1"})


def parse_pe(path: Path) -> dict[str, int]:
    data = path.read_bytes()
    assert data[:2] == b"MZ"
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    assert data[pe : pe + 4] == b"PE\0\0"
    machine, sections = struct.unpack_from("<HH", data, pe + 4)
    opt = pe + 24
    magic = struct.unpack_from("<H", data, opt)[0]
    subsystem = struct.unpack_from("<H", data, opt + 68)[0]
    dll_characteristics = struct.unpack_from("<H", data, opt + 70)[0]
    resource_rva, resource_size = struct.unpack_from("<II", data, opt + 112 + 2 * 8)
    return {
        "machine": machine,
        "sections": sections,
        "magic": magic,
        "subsystem": subsystem,
        "dll_characteristics": dll_characteristics,
        "resource_rva": resource_rva,
        "resource_size": resource_size,
    }


def validate_zip(path: Path) -> list[str]:
    problems: list[str] = []
    lower: set[str] = set()
    with zipfile.ZipFile(path) as zf:
        assert zf.testzip() is None
        for info in zf.infolist():
            name = info.filename
            pp = PurePosixPath(name)
            if name.startswith(("/", "\\")) or ".." in pp.parts or re.match(r"^[A-Za-z]:", name):
                problems.append(f"unsafe path: {name}")
            key = name.casefold()
            if key in lower:
                problems.append(f"duplicate/case collision: {name}")
            lower.add(key)
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                problems.append(f"symlink: {name}")
    return problems


def test_version_and_product_identity() -> None:
    version = json.loads(text(ROOT / "VERSION.json"))
    assert version == {
        "product": "Nyx PC Checkup",
        "publisher": "Dietrich AI Labs",
        "version": "1.0.0",
        "build": "2026.08.23-eng-qa2",
        "channel": "Engineering QA Candidate",
        "platform": "Windows 10/11 x64",
        "architecture": "PowerShell 5.1 modular application with native x64 launchers",
        "telemetry": False,
    }


def test_expected_modular_structure_exists() -> None:
    actual = {p.relative_to(APP).as_posix() for p in APP.rglob("*") if p.is_file()}
    assert EXPECTED_MODULES <= actual
    assert len([p for p in actual if p.endswith((".ps1", ".psm1"))]) >= 34
    assert (APP / "platform" / "linux" / "CONTRACT.md").exists()


def test_powershell_structural_linter_passes() -> None:
    result = subprocess.run(
        [sys.executable, str(ROOT / "tools" / "ps_lint.py"), str(APP)],
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "PASS" in result.stdout


def test_no_placeholder_or_mock_runtime() -> None:
    bad = re.compile(r"\b(?:TODO|FIXME|PLACEHOLDER|coming soon|not implemented|mock result|fake result)\b", re.I)
    findings = []
    for p in APP.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".ps1", ".psm1", ".json"}:
            for n, line in enumerate(text(p).splitlines(), 1):
                if bad.search(line):
                    findings.append(f"{p.relative_to(ROOT)}:{n}:{line}")
    assert not findings


def test_no_upload_telemetry_or_remote_control_apis() -> None:
    source = all_runtime_source()
    forbidden = [
        r"Invoke-WebRequest",
        r"Invoke-RestMethod",
        r"Start-BitsTransfer",
        r"System\.Net\.WebClient",
        r"Net\.Http\.HttpClient",
        r"UploadFile",
        r"UploadString",
        r"TcpClient",
        r"UdpClient",
        r"HttpListener",
        r"New-PSSession",
        r"Invoke-Command\s+-ComputerName",
    ]
    for pattern in forbidden:
        assert re.search(pattern, source, re.I) is None, pattern
    defaults = json.loads(text(APP / "config" / "defaults.json"))
    assert defaults["notificationsEnabled"] is False
    assert "telemetry" not in defaults


def test_scan_worker_is_read_only_and_isolated() -> None:
    source = text(APP / "workers" / "ScanWorker.ps1")
    assert "ReadOnly=$true" in source
    assert "actions\\StartupActions" not in source
    assert "actions\\CleanupActions" not in source
    for forbidden in ["Set-ItemProperty", "New-ItemProperty", "Remove-ItemProperty", "Clear-RecycleBin", "-Verb RunAs"]:
        assert forbidden not in source
    check_source = "\n".join(text(p) for p in sorted((APP / "checks").glob("*.psm1")))
    for forbidden in ["Set-ItemProperty", "New-ItemProperty", "Remove-ItemProperty", "Clear-RecycleBin", "Stop-Process", "Disable-NetAdapter"]:
        assert forbidden not in check_source


def test_health_states_and_acceptance_sentence_are_fixed() -> None:
    source = text(APP / "core" / "Models.psm1")
    assert "[ValidateSet('Good','NeedsAttention','Optional','Unknown')]" in source
    assert "Your PC looks good. Nothing needs fixing." in source
    assert "0–100" not in all_runtime_source()
    rules = json.loads(text(APP / "health_rules" / "rules.json"))
    assert rules["storage"]["criticalFreeBytes"] == 10 * 1024**3
    assert rules["storage"]["attentionFreeBytes"] == 20 * 1024**3
    assert rules["uptime"]["optionalDays"] == 14
    assert rules["battery"]["attentionHealthPercent"] == 50


@pytest.mark.parametrize(
    ("free", "total", "expected"),
    [
        (30 * 1024**3, 500 * 1024**3, "Good"),
        (4 * 1024**3, 500 * 1024**3, "NeedsAttention"),
        (0, 0, "Unknown"),
        (10 * 1024**3, 100 * 1024**3, "Good"),
        (10 * 1024**3 - 1, 100 * 1024**3, "NeedsAttention"),
    ],
)
def test_storage_rule_reference_boundaries(free: int, total: int, expected: str) -> None:
    rules = json.loads(text(APP / "health_rules" / "rules.json"))["storage"]
    if total <= 0:
        result = "Unknown"
    else:
        percent = round((free / total) * 100, 1)
        hard_floor = rules["criticalFreeBytes"] // 2
        if free < hard_floor or (free < rules["criticalFreeBytes"] and percent < rules["criticalFreePercent"]):
            result = "NeedsAttention"
        elif free < rules["criticalFreeBytes"] or (free < rules["attentionFreeBytes"] and percent < rules["attentionFreePercent"]):
            result = "NeedsAttention"
        else:
            result = "Good"
    assert result == expected


def test_startup_write_ahead_rollback_precedes_change() -> None:
    source = text(APP / "actions" / "StartupActions.psm1")
    disable_start = source.index("function Disable-NyxStartupApplication")
    disable_end = source.index("function Enable-NyxStartupApplication")
    body = source[disable_start:disable_end]
    journal = body.index("$journal=New-NyxStartupRollbackJournal")
    registry_change = body.index("Remove-ItemProperty")
    file_change = body.index("Move-Item -LiteralPath $state.SourcePath")
    assert journal < registry_change
    assert journal < file_change
    assert "ProtectedData]::Protect" in text(APP / "core" / "ActionHistory.psm1")
    assert "DataProtectionScope]::CurrentUser" in text(APP / "core" / "ActionHistory.psm1")
    for key in [
        r"HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
        r"HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        r"HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
        r"HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        r"HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run",
    ]:
        assert key in source


def test_action_worker_accepts_only_fixed_operations_and_uuid_ipc() -> None:
    source = text(APP / "workers" / "ActionWorker.ps1")
    operations = set(re.findall(r"^\s*'([A-Za-z]+)'\s*\{", source, re.M))
    assert operations == {"DisableStartup", "EnableStartup", "Cleanup"}
    assert r"^action-([a-f0-9]{32})-request\.json$" in source
    assert r"^action-([a-f0-9]{32})-result\.json$" in source
    assert "RequestSha256" in source
    assert "ReadAllBytes($files.Request)" in source
    assert "confirmed action request changed before execution" in source
    assert "ConfirmedByUser" in source
    assert "Get-NyxStartupApplications" in source
    assert "ApplicationId" in source
    ui = text(APP / "ui" / "MainWindow.psm1")
    assert "Get-FileHash -LiteralPath $req -Algorithm SHA256" in ui
    assert "-RequestSha256 $requestHash" in ui


def test_cleanup_is_unselected_revalidated_and_recycled() -> None:
    scan = text(APP / "checks" / "CleanupScan.psm1")
    action = text(APP / "actions" / "CleanupActions.psm1")
    ui = text(APP / "ui" / "MainWindow.psm1")
    assert "SelectedByDefault=$false" in scan
    assert "$identity=" in scan and "$SizeBytes" in scan and "$LastWriteUtc" in scan
    assert "$fresh=Get-NyxCleanupCandidates" in action
    assert "The item changed after cleanup revalidation. It was preserved." in action
    assert "RecycleOption]::SendToRecycleBin" in action
    assert "Clear-RecycleBin -Force" in action
    assert "Nothing is selected automatically" in ui
    assert "The Recycle Bin selection will be emptied permanently" in ui


def test_reports_minimize_sensitive_evidence() -> None:
    privacy = text(APP / "core" / "Privacy.psm1")
    reports = text(APP / "reports" / "ReportExport.psm1")
    for token in ["[IP REDACTED]", "[EMAIL REDACTED]", "[REDACTED]", "%USERPROFILE%"]:
        assert token in privacy
    assert "system.overview" in reports
    assert "Hardware serial" not in reports
    assert "Full usernames" not in reports
    assert "Get-NyxReportEvidence" in reports
    assert "Show-NyxReportPreviewDialog" in text(APP / "ui" / "MainWindow.psm1")


def test_installer_and_uninstaller_enforce_exact_root_and_manifest() -> None:
    installer = text(APP / "workers" / "InstallWorker.ps1")
    uninstaller = text(APP / "workers" / "UninstallWorker.ps1")
    native = text(ROOT / "native" / "installer.cpp")
    exact = r"Programs\Dietrich AI Labs\Nyx PC Checkup"
    assert exact in installer
    assert exact in uninstaller
    assert "PAYLOAD_MANIFEST.json" in installer
    assert "Get-FileHash" in installer
    assert "unexpected file" in installer.lower()
    assert "rollback" in native.lower()
    assert "MoveFileExW(stage,target" in native
    assert "requestedExecutionLevel level=\"asInvoker\"" in text(ROOT / "native" / "app.manifest")


def test_native_pe_candidates_are_hardened_x64_gui_with_manifest() -> None:
    for name in ["Nyx PC Checkup.exe", "Uninstall Nyx PC Checkup.exe"]:
        path = ROOT / "build" / "native" / name
        assert path.exists(), path
        pe = parse_pe(path)
        assert pe["machine"] == 0x8664
        assert pe["magic"] == 0x20B
        assert pe["subsystem"] == 2
        assert pe["dll_characteristics"] & 0x40  # DYNAMIC_BASE
        assert pe["dll_characteristics"] & 0x100  # NX_COMPAT
        assert pe["dll_characteristics"] & 0x20  # HIGH_ENTROPY_VA
        assert pe["resource_rva"] != 0 and pe["resource_size"] > 0
        assert struct.unpack_from("<I", path.read_bytes(), struct.unpack_from("<I", path.read_bytes(), 0x3C)[0] + 8)[0] == 0
        assert b"asInvoker" in path.read_bytes()
    setup = DIST / "Nyx_PC_Checkup_1.0.0_Setup.exe"
    assert setup.exists()
    pe = parse_pe(setup)
    assert pe["machine"] == 0x8664 and pe["subsystem"] == 2
    assert pe["resource_rva"] != 0
    assert struct.unpack_from("<I", setup.read_bytes(), struct.unpack_from("<I", setup.read_bytes(), 0x3C)[0] + 8)[0] == 0
    assert b"asInvoker" in setup.read_bytes()


def test_stage_payload_manifest_is_exact_and_clean() -> None:
    manifest_path = STAGE / "PAYLOAD_MANIFEST.json"
    assert manifest_path.exists()
    manifest = json.loads(text(manifest_path))
    assert manifest["schema"] == "dietrich-ai-labs.nyx-pc-checkup.payload.v1"
    expected = {entry["path"]: entry for entry in manifest["files"]}
    actual = {
        p.relative_to(STAGE).as_posix(): p
        for p in STAGE.rglob("*")
        if p.is_file() and p != manifest_path
    }
    assert set(expected) == set(actual)
    for rel, p in actual.items():
        assert expected[rel]["size"] == p.stat().st_size
        assert expected[rel]["sha256"] == sha256(p)
    forbidden_parts = {"tests", "evidence", ".git", "__pycache__", ".pytest_cache", "source"}
    for rel in actual:
        assert forbidden_parts.isdisjoint(PurePosixPath(rel).parts)
        assert not rel.endswith((".pyc", ".log", ".dmp"))
    assert "app/platform/linux/CONTRACT.md" not in actual
    assert "Nyx PC Checkup.exe" in actual
    assert "Uninstall Nyx PC Checkup.exe" in actual


def test_release_archives_are_safe_and_have_expected_roots() -> None:
    archives = [
        DIST / "Nyx_PC_Checkup_1.0.0_Portable.zip",
        DIST / "Nyx_PC_Checkup_1.0.0_Source.zip",
    ]
    for archive in archives:
        assert archive.exists(), archive
        assert validate_zip(archive) == []
        with zipfile.ZipFile(archive) as zf:
            roots = {PurePosixPath(i.filename).parts[0] for i in zf.infolist() if i.filename}
            assert len(roots) == 1


def test_runtime_does_not_contain_excluded_pc_cleaner_features() -> None:
    source = all_runtime_source().lower()
    forbidden_behavior = [
        "driver updater",
        "registry cleaner",
        "ram booster",
        "ram optimizer",
        "overclock",
        "packet capture",
        "remote administration",
        "automatic service disabling",
    ]
    # Explanatory strings may explicitly say a feature is absent. Reject only
    # commands/APIs that could implement the prohibited behavior.
    command_forbidden = [
        "pnputil",
        "disable-windowsoptionalfeature",
        "set-service -startuptype disabled",
        "netsh interface ip set dns",
        "set-dnsclientserveraddress",
        "set-netfirewallprofile",
        "set-mppreference -disablerealtimemonitoring",
    ]
    for token in command_forbidden:
        assert token not in source
    assert "no ram-cleaning button" not in source  # prose belongs in docs, not runtime logic


def test_documentation_and_windows_test_handoff_are_complete() -> None:
    required_docs = {
        "ARCHITECTURE.md",
        "MODULE_MAP.md",
        "MODULE_CONTRACTS.md",
        "USER_GUIDE.md",
        "PRIVACY_AND_SECURITY.md",
        "INSTALL_UPGRADE_UNINSTALL.md",
        "KNOWN_LIMITATIONS.md",
        "BUILD_AND_REPRODUCE.md",
        "QA_TEST_PLAN.md",
        "WHO_GETS_WHAT_NEXT.md",
        "RELEASE_NOTES.md",
    }
    assert required_docs <= {p.name for p in (ROOT / "docs").glob("*.md")}
    assert (ROOT / "tests" / "powershell" / "Run-WindowsSmokeTests.ps1").exists()
    assert (ROOT / "tests" / "powershell" / "Run-WindowsInstallerLifecycle.ps1").exists()
    assert (ROOT / "tests" / "powershell" / "Run-WindowsElevatedStartupRollback.ps1").exists()
    sbom = json.loads(text(ROOT / "SBOM.json"))
    assert sbom["bomFormat"] == "CycloneDX"
    assert sbom["metadata"]["component"]["version"] == "1.0.0"


def test_cleanup_traversal_is_bounded_and_parent_chain_is_revalidated() -> None:
    scan = text(APP / "checks" / "CleanupScan.psm1")
    action = text(APP / "actions" / "CleanupActions.psm1")
    for token in [
        "MaxVisitedFiles=100000",
        "MaxSeconds=30",
        "VisitedFiles=$visitedFiles",
        "VisitedFileLimit",
        "TimeLimit",
        "AccessDeniedCount=$accessDenied",
        "Complete=$complete",
    ]:
        assert token in scan
    assert "Get-NyxCleanupStopReason" in scan
    assert "Assert-NyxCleanupParentChain" in action
    assert "Test-NyxPathInsideRoot" in action
    assert "A parent folder became a junction or symbolic link" in action
    assert action.count("Get-NyxValidatedCleanupFile -Candidate $item") >= 2
    second_validation = action.rfind("Get-NyxValidatedCleanupFile -Candidate $item")
    delete = action.index("RecycleOption]::SendToRecycleBin")
    assert second_validation < delete
    for category in ["User temporary files", "Old installer in Downloads", "Old archive in Downloads"]:
        assert category in action


def test_elevated_startup_rollback_uses_machine_protected_authority() -> None:
    source = text(APP / "actions" / "StartupActions.psm1")
    for token in [
        "$env:ProgramData",
        "startup-rollback",
        "SetAccessRuleProtection($true,$false)",
        "S-1-5-18",
        "S-1-5-32-544",
        "New-NyxMachineStartupRollbackJournal",
        "Get-NyxMachineStartupRollbackState",
        "New-NyxMachinePointerState",
        "JournalScope='Machine'",
        "OwnerSid",
        "legacy elevated rollback journal was rejected",
    ]:
        assert token in source
    enable = source[source.index("function Enable-NyxStartupApplication") :]
    assert "if($scope -eq 'Machine'){$state=Get-NyxMachineStartupRollbackState" in enable
    assert "Restoring this all-users startup entry requires administrator approval" in enable
    # The CurrentUser DPAPI record remains the UI pointer, but elevated restore
    # obtains its authoritative source/value/command from the protected machine journal.
    assert enable.index("Get-NyxMachineStartupRollbackState") < enable.index("New-ItemProperty")


def test_uninstall_aborts_before_removing_anything_when_restore_fails() -> None:
    source = text(APP / "workers" / "UninstallWorker.ps1")
    failed = source.index("$failed=@($restores|Where-Object")
    abort = source.index("exit 6", failed)
    registration_removal = source.index("Remove-Item -LiteralPath 'HKCU:\\Software", failed)
    assert failed < abort < registration_removal
    assert "Uninstall was stopped before removing the application, shortcuts, registration, or local recovery data." in source
    assert "Get-ChildItem -LiteralPath $startFolder" in source
    assert "Remove-Item -LiteralPath $startFolder" in source


def test_ui_settings_notifications_and_windows_identity_regressions() -> None:
    ui = text(APP / "ui" / "MainWindow.psm1")
    system = text(APP / "checks" / "SystemInfo.psm1")
    helper = text(APP / "platform" / "windows" / "WindowsHelpers.psm1")
    assert "Your PC looks good. Nothing needs fixing." in ui
    assert "function Show-NyxConservativeNotification" in ui
    assert "updates.restart" in ui and "backup.status" in ui
    assert "Notification changes apply now; theme changes apply the next time Nyx is opened." in ui
    assert "Nyx will restart once" not in ui
    settings = ui[ui.index("function Show-NyxSettingsPage") : ui.index("function Export-NyxCurrentReport")]
    assert "Start-Process -FilePath $launcher" not in settings
    assert "$os.Caption" in system
    assert "Get-CimInstance Win32_OperatingSystem" in helper


def test_unknown_state_conservatism_and_security_coverage() -> None:
    network = text(APP / "checks" / "NetworkBasics.psm1")
    security = text(APP / "checks" / "SecurityStatus.psm1")
    apps = text(APP / "checks" / "InstalledApps.psm1")
    assert "Nyx will not call the connection broken" in network
    assert "-Status 'Unknown'" in network
    assert "security.windows-security-service" in security
    assert "SecurityHealthService" in security and "wscsvc" in security
    assert "security.tpm" in security and "Get-Tpm" in security
    assert "Windows returned no firewall-profile records" in security
    assert "Windows returned no supported installed-application records" in apps
    assert "-Complete $false" in apps


def test_battery_profile_and_local_data_hardening_contracts() -> None:
    battery = text(APP / "checks" / "BatteryHealth.psm1")
    storage = text(APP / "checks" / "StorageScan.psm1")
    paths = text(APP / "core" / "Paths.psm1")
    assert "[math]::Min(100" in battery
    assert "ChargingState" in battery and "Get-NyxBatteryChargingState" in battery
    assert "Name='User profile'" in storage
    assert "UserProfile=$profileResult" in storage
    assert "Assert-NyxOrdinaryDataDirectory" in paths
    assert "FileAttributes]::ReparsePoint" in paths
    assert "cannot be a junction or symbolic link" in paths


def test_ui_cancel_cleanup_refresh_and_notification_contracts() -> None:
    ui = text(APP / "ui" / "MainWindow.psm1")
    assert "Check cancelled. Partial results were preserved." in ui
    assert "Cleanup finished. Refreshing the read-only cleanup preview." in ui
    assert "Start-NyxScan -Mode 'Full';return" in ui
    assert "Show-NyxConservativeNotification -Scan $script:NyxUi.Scan" in ui
    assert "Show-NyxCompletionNotification" not in ui
    assert "Save settings" in ui
    assert "$script:NyxUi.ScanProcess.Kill()" in ui
    assert "cannot leave an" in ui and "background PowerShell process" in ui


def test_native_launchers_do_not_disable_stack_argument_probing() -> None:
    builder = text(ROOT / "tools" / "build_release.py")
    assert "-mno-stack-arg-probe" not in builder
    for name in ["launcher.cpp", "uninstaller.cpp", "installer.cpp"]:
        native = text(ROOT / "native" / name)
        assert "static WCHAR" in native
    assert "WCHAR exe[1024]={0}" not in text(ROOT / "native" / "launcher.cpp")
    assert "WCHAR cmd[4096]={0}" not in text(ROOT / "native" / "installer.cpp")


def test_windows_lifecycle_repair_probe_targets_packaged_file() -> None:
    lifecycle = text(ROOT / "tests" / "powershell" / "Run-WindowsInstallerLifecycle.ps1")
    assert "docs\\USER_GUIDE.md" in lifecycle
    assert "documentation\\RELEASE_NOTES.md" not in lifecycle
    assert "Add-Content -LiteralPath $repairProbe" in lifecycle


def test_source_archive_identity_is_exact_and_self_excluding() -> None:
    source_zip = DIST / "Nyx_PC_Checkup_1.0.0_Source.zip"
    assert source_zip.exists()
    with zipfile.ZipFile(source_zip) as zf:
        identity_name = next(name for name in zf.namelist() if name.endswith("/SOURCE_TREE_IDENTITY.json"))
        archive_root = identity_name.rsplit("/", 1)[0] + "/"
        identity = json.loads(zf.read(identity_name))
        assert identity["identityExcludes"] == ["SOURCE_TREE_IDENTITY.json"]
        records = []
        aggregate = hashlib.sha256()
        for name in sorted(
            (name for name in zf.namelist() if not name.endswith("/") and name != identity_name),
            key=str.casefold,
        ):
            rel = name[len(archive_root) :]
            data = zf.read(name)
            digest = hashlib.sha256(data).hexdigest().upper()
            records.append({"path": rel, "size": len(data), "sha256": digest})
            aggregate.update(
                rel.encode("utf-8")
                + b"\0"
                + str(len(data)).encode("ascii")
                + b"\0"
                + digest.encode("ascii")
                + b"\n"
            )
        assert identity["files"] == records
        assert identity["fileCount"] == len(records)
        assert identity["treeSha256"] == aggregate.hexdigest().upper()
    builder = text(ROOT / "tools" / "build_release.py")
    assert 'rel.name == "SOURCE_TREE_IDENTITY.json"' in builder



def test_configuration_and_rollback_journal_inputs_are_bounded() -> None:
    configuration = text(APP / "core" / "Configuration.psm1")
    history = text(APP / "core" / "ActionHistory.psm1")
    for token in [
        "function Repair-NyxConfiguration",
        "UnsafeTheme" if False else "FollowWindows",
        "-Minimum 65536 -Maximum 10485760",
        "-Minimum 1000 -Maximum 2000000",
        "The configuration file is not an ordinary bounded file",
        "The configuration destination is not an ordinary file",
    ]:
        assert token in configuration
    assert "journalItem.Length -gt 1048576" in history
    assert "rollback.dpapi" in history
    assert "FileAttributes]::ReparsePoint" in history
    assert "Get-ChildItem -LiteralPath $paths.DisabledStartup -Directory -Force" in history


def test_windows_rollback_regression_scripts_cover_user_machine_and_uninstall_boundaries() -> None:
    smoke = text(ROOT / "tests" / "powershell" / "Run-WindowsSmokeTests.ps1")
    elevated = text(ROOT / "tests" / "powershell" / "Run-WindowsElevatedStartupRollback.ps1")
    lifecycle = text(ROOT / "tests" / "powershell" / "Run-WindowsInstallerLifecycle.ps1")
    assert "Current-user startup disable completes" in smoke
    assert "Startup restore preserves the exact command" in smoke
    assert "Get-NyxCleanupCandidates -Limit 1 -MaxVisitedFiles 1 -MaxSeconds 1" in smoke
    assert "Owner user has no write authority over machine journal" in elevated
    assert "TamperedPointerValue" in elevated
    assert "Restore ignores tampered user pointer" in elevated
    assert "Uninstall aborts with exit 6 when startup restoration conflicts" in lifecycle
    assert "Failed restore preserves active rollback journal" in lifecycle
    assert "Uninstall restores exact startup command before removal" in lifecycle


def test_machine_rollback_read_validates_protected_parent_chain_and_acl() -> None:
    source = text(APP / "actions" / "StartupActions.psm1")
    read = source[source.index("function Get-NyxMachineStartupRollbackState") : source.index("function Remove-NyxStartupRollbackJournal")]
    assert "@($paths.SecurityRoot,$paths.Root,$paths.Folder)" in read
    assert "AreAccessRulesProtected" in read
    assert "protected machine rollback directory chain is invalid" in read
    assert "protected machine rollback directory inherited an untrusted ACL" in read


def test_local_reproducibility_wrapper_is_present_and_network_free() -> None:
    wrapper_path = ROOT / "tools" / "build_and_verify_reproduction.py"
    assert wrapper_path.exists()
    wrapper = text(wrapper_path)
    assert "REPRODUCIBILITY_CHECK.json" in wrapper
    assert '"networkUsed": False' in wrapper
    assert '"githubUsed": False' in wrapper
    assert "sourceExactMatch" in wrapper
    for token in ["urllib", "requests", "http://", "https://"]:
        assert token not in wrapper


def test_builder_resolves_local_toolchain_without_container_specific_paths() -> None:
    builder = text(ROOT / "tools" / "build_release.py")
    assert 'shutil.which("clang++")' in builder
    assert 'shutil.which("lld-link")' in builder
    assert 'NYX_CLANG' in builder and 'NYX_LLD_LINK' in builder
    assert '/usr/local/swift/usr/bin' not in builder



def test_installer_finalization_is_quiet_aware_and_transactional() -> None:
    worker = text(APP / "workers" / "InstallWorker.ps1")
    native = text(ROOT / "native" / "installer.cpp")
    for token in [
        "[int]$Quiet=0",
        "function Get-NyxFileSnapshot",
        "function Restore-NyxFileSnapshot",
        "function Get-NyxRegistrySnapshot",
        "function Restore-NyxRegistrySnapshot",
        "$snapshotsCaptured=$true",
        "Restore-NyxFileSnapshot -Snapshot $startSnapshot",
        "Restore-NyxRegistrySnapshot -Snapshot $uninstallSnapshot",
        "if($Quiet -ne 1)",
    ]:
        assert token in worker
    install_state = worker.index("install-state.json")
    shortcut = worker.index("$shortcut=$shell.CreateShortcut", install_state)
    registry = worker.index("New-Item -Path $uninstallKey", shortcut)
    assert install_state < shortcut < registry
    assert "nyx_finalize(const WCHAR* target,BOOL desktop,BOOL quiet)" in native
    assert 'nyx_wcat(cmd,L" -Quiet ",4096)' in native
    assert "nyx_finalize(target,desktop,quiet)" in native



def test_installer_and_uninstaller_reject_reparse_backed_boundaries() -> None:
    native = text(ROOT / "native" / "installer.cpp")
    uninstaller = text(APP / "workers" / "UninstallWorker.ps1")
    for token in [
        "FILE_ATTRIBUTE_REPARSE_POINT",
        "nyx_ordinary_dir",
        "CREATE_NEW",
        "colliding temporary installation path",
        "reparse-backed existing installation directory",
        "reparse-backed installation parent directory",
    ]:
        assert token in native
    assert "The uninstall location is missing, invalid, or reparse-backed" in uninstaller
    assert "The application directory failed its safety boundary check" in uninstaller
    assert uninstaller.count("FileAttributes]::ReparsePoint") >= 2


def test_engineering_evidence_boundary_names_all_three_windows_suites() -> None:
    builder = text(ROOT / "tools" / "build_release.py")
    readme = text(ROOT / "README_FIRST.md")
    for token in ["normal-user smoke/rollback", "elevated all-users rollback", "installer lifecycle"]:
        assert token in builder
        assert token in readme
