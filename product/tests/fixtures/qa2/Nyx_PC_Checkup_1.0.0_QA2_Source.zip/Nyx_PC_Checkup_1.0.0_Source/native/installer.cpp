#include "win_types.hpp"
#include "payload.h"

static BOOL nyx_exists(const WCHAR* p){return GetFileAttributesW(p)!=INVALID_FILE_ATTRIBUTES;}
static BOOL nyx_ordinary_dir(const WCHAR* p){DWORD a=GetFileAttributesW(p);return a!=INVALID_FILE_ATTRIBUTES&&(a&FILE_ATTRIBUTE_DIRECTORY)&&!(a&FILE_ATTRIBUTE_REPARSE_POINT);}
static BOOL nyx_reparse(const WCHAR* p){DWORD a=GetFileAttributesW(p);return a!=INVALID_FILE_ATTRIBUTES&&(a&FILE_ATTRIBUTE_REPARSE_POINT);}
static void nyx_fail(BOOL quiet,const WCHAR* message,UINT code){if(!quiet)MessageBoxW(0,message,L"Nyx PC Checkup Setup",MB_OK|MB_ICONERROR);ExitProcess(code);}
static BOOL nyx_write_payload(const WCHAR* root){
    static WCHAR full[2048],parent[2048];
    for(unsigned long i=0;i<NYX_PAYLOAD_COUNT;i++){
        full[0]=parent[0]=0;
        nyx_wcopy(full,root,2048);nyx_wcat(full,L"\\",2048);nyx_wcat(full,NYX_PAYLOAD[i].path,2048);
        nyx_parent_dir(parent,full,2048);if(parent[0]){SHCreateDirectoryExW(0,parent,0);if(!nyx_ordinary_dir(parent))return FALSE;}
        if(nyx_exists(full))return FALSE;
        HANDLE h=CreateFileW(full,GENERIC_WRITE,0,0,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,0);if(h==INVALID_HANDLE_VALUE)return FALSE;
        unsigned long long remaining=NYX_PAYLOAD[i].size,offset=0;
        while(remaining){DWORD chunk=(remaining>0x40000000ULL)?0x40000000UL:(DWORD)remaining,written=0;if(!WriteFile(h,NYX_PAYLOAD[i].data+offset,chunk,&written,0)||written!=chunk){CloseHandle(h);return FALSE;}offset+=written;remaining-=written;}
        CloseHandle(h);
    }
    return TRUE;
}
static void nyx_schedule_remove(const WCHAR* dir){
    static WCHAR sys[512],cmdexe[1024],cmd[4096];sys[0]=cmdexe[0]=cmd[0]=0;GetEnvironmentVariableW(L"SystemRoot",sys,512);nyx_wcopy(cmdexe,sys,1024);nyx_wcat(cmdexe,L"\\System32\\cmd.exe",1024);
    nyx_wcat(cmd,L"\"",4096);nyx_wcat(cmd,cmdexe,4096);nyx_wcat(cmd,L"\" /d /c ping 127.0.0.1 -n 2 >nul & rmdir /s /q \"",4096);nyx_wcat(cmd,dir,4096);nyx_wcat(cmd,L"\"",4096);
    STARTUPINFOW si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;if(CreateProcessW(cmdexe,cmd,0,0,FALSE,CREATE_NO_WINDOW,0,0,&si,&pi)){CloseHandle(pi.hThread);CloseHandle(pi.hProcess);}
}
static DWORD nyx_finalize(const WCHAR* target,BOOL desktop,BOOL quiet){
    static WCHAR sys[512],ps[1024],worker[1600],cmd[4096];sys[0]=ps[0]=worker[0]=cmd[0]=0;GetEnvironmentVariableW(L"SystemRoot",sys,512);nyx_wcopy(ps,sys,1024);nyx_wcat(ps,L"\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",1024);
    nyx_wcopy(worker,target,1600);nyx_wcat(worker,L"\\app\\workers\\InstallWorker.ps1",1600);
    nyx_wcat(cmd,L"\"",4096);nyx_wcat(cmd,ps,4096);nyx_wcat(cmd,L"\" -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"",4096);nyx_wcat(cmd,worker,4096);nyx_wcat(cmd,L"\" -InstallRoot \"",4096);nyx_wcat(cmd,target,4096);nyx_wcat(cmd,L"\" -CreateDesktop ",4096);nyx_wcat(cmd,desktop?L"1":L"0",4096);nyx_wcat(cmd,L" -Quiet ",4096);nyx_wcat(cmd,quiet?L"1":L"0",4096);return nyx_run(ps,cmd,target,TRUE);
}
static void nyx_launch(const WCHAR* target){static WCHAR exe[1400],cmd[1800];exe[0]=cmd[0]=0;nyx_wcopy(exe,target,1400);nyx_wcat(exe,L"\\Nyx PC Checkup.exe",1400);nyx_wcat(cmd,L"\"",1800);nyx_wcat(cmd,exe,1800);nyx_wcat(cmd,L"\"",1800);STARTUPINFOW si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);if(CreateProcessW(exe,cmd,0,0,FALSE,0,0,target,&si,&pi)){CloseHandle(pi.hThread);CloseHandle(pi.hProcess);}}

extern "C" void __stdcall wWinMainCRTStartup(void){
    const WCHAR* command=GetCommandLineW();BOOL quiet=nyx_contains_i(command,L"/quiet");BOOL desktop=nyx_contains_i(command,L"/desktop");BOOL noLaunch=quiet||nyx_contains_i(command,L"/nolaunch");
    HANDLE running=OpenMutexW(SYNCHRONIZE,FALSE,L"Local\\DietrichAI.NyxPCCheckup.v1");if(running){CloseHandle(running);nyx_fail(quiet,L"Close Nyx PC Checkup before installing, upgrading, or repairing it.",10);}
    if(!quiet){
        int choice=MessageBoxW(0,L"Install Nyx PC Checkup 1.0.0 for the current Windows user?\n\nChoose Yes to also create a desktop shortcut.\nChoose No for a Start menu shortcut only.\nChoose Cancel to stop.\n\nThe app is local-first and installs no background service.",L"Nyx PC Checkup Setup",MB_YESNOCANCEL|MB_ICONQUESTION);
        if(choice==IDCANCEL)ExitProcess(0);desktop=(choice==IDYES);
    }
    static WCHAR local[1024],parent[1400],target[1600],stage[1700],backup[1700],failed[1700];
    local[0]=parent[0]=target[0]=stage[0]=backup[0]=failed[0]=0;
    if(!GetEnvironmentVariableW(L"LOCALAPPDATA",local,1024))nyx_fail(quiet,L"Setup could not find the current user's Local AppData folder.",11);
    nyx_wcopy(parent,local,1400);nyx_wcat(parent,L"\\Programs\\Dietrich AI Labs",1400);SHCreateDirectoryExW(0,parent,0);if(!nyx_ordinary_dir(parent))nyx_fail(quiet,L"Setup rejected an unsafe or reparse-backed installation parent directory.",11);
    nyx_wcopy(target,parent,1600);nyx_wcat(target,L"\\Nyx PC Checkup",1600);
    DWORD pid=GetCurrentProcessId();nyx_wcopy(stage,parent,1700);nyx_wcat(stage,L"\\Nyx PC Checkup.installing.",1700);nyx_append_uint(stage,pid,1700);
    nyx_wcopy(backup,parent,1700);nyx_wcat(backup,L"\\Nyx PC Checkup.rollback.",1700);nyx_append_uint(backup,pid,1700);
    nyx_wcopy(failed,parent,1700);nyx_wcat(failed,L"\\Nyx PC Checkup.failed.",1700);nyx_append_uint(failed,pid,1700);
    if(nyx_exists(stage)||nyx_exists(backup)||nyx_exists(failed))nyx_fail(quiet,L"Setup found a colliding temporary installation path and stopped without changing the existing installation.",12);
    SHCreateDirectoryExW(0,stage,0);if(!nyx_ordinary_dir(stage)||!nyx_write_payload(stage)){nyx_schedule_remove(stage);nyx_fail(quiet,L"Setup could not write the complete clean payload. The existing installation, if any, was not replaced.",12);}
    BOOL hadOld=nyx_exists(target);if(hadOld&&nyx_reparse(target)){nyx_schedule_remove(stage);nyx_fail(quiet,L"Setup rejected a reparse-backed existing installation directory.",13);}if(hadOld&&!nyx_ordinary_dir(target)){nyx_schedule_remove(stage);nyx_fail(quiet,L"Setup rejected an invalid existing installation path.",13);}if(hadOld&&!MoveFileExW(target,backup,MOVEFILE_WRITE_THROUGH)){nyx_schedule_remove(stage);nyx_fail(quiet,L"Setup could not create the upgrade rollback boundary. Close any open Nyx files and try again.",13);}
    if(!MoveFileExW(stage,target,MOVEFILE_WRITE_THROUGH)){if(hadOld)MoveFileExW(backup,target,MOVEFILE_WRITE_THROUGH);nyx_schedule_remove(stage);nyx_fail(quiet,L"Setup could not activate the new payload. The previous installation was restored.",14);}
    DWORD finalCode=nyx_finalize(target,desktop,quiet);if(finalCode!=0){MoveFileExW(target,failed,MOVEFILE_WRITE_THROUGH);if(hadOld)MoveFileExW(backup,target,MOVEFILE_WRITE_THROUGH);nyx_schedule_remove(failed);nyx_fail(quiet,L"Setup finalization failed. The previous installation was restored when one existed.",15);}
    if(hadOld)nyx_schedule_remove(backup);
    if(!quiet){
        if(noLaunch){MessageBoxW(0,hadOld?L"Nyx PC Checkup was upgraded or repaired successfully.":L"Nyx PC Checkup was installed successfully.",L"Nyx PC Checkup Setup",MB_OK|MB_ICONINFORMATION);}
        else{int launch=MessageBoxW(0,hadOld?L"Nyx PC Checkup was upgraded or repaired successfully.\n\nOpen it now?":L"Nyx PC Checkup was installed successfully.\n\nOpen it now?",L"Nyx PC Checkup Setup",MB_YESNO|MB_ICONINFORMATION);if(launch==IDYES)nyx_launch(target);}
    }
    ExitProcess(0);
}
