#!/usr/bin/env python3
"""Build the complete local Nyx PC Checkup 1.0.0 Engineering QA handoff.

This builder intentionally uses only local source and the LLVM tools already
present in the engineering environment.  It creates native x64 Windows PE
launchers, a self-contained per-user setup executable, a clean portable ZIP,
a source ZIP, test evidence, manifests, and one immutable QA handoff ZIP.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import platform
import shutil
import struct
import subprocess
import sys
import tempfile
import textwrap
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable, Sequence
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "src" / "app"
NATIVE = ROOT / "native"
BUILD = ROOT / "build"
BUILD_NATIVE = BUILD / "native"
STAGE_BASE = ROOT / "release_staging"
STAGE = STAGE_BASE / "Nyx_PC_Checkup_1.0.0_Portable"
DIST = ROOT / "dist"
EVIDENCE = ROOT / "evidence"
HANDOFF_BASE = ROOT / "handoff_staging"
HANDOFF = HANDOFF_BASE / "Nyx_PC_Checkup_1.0.0_Engineering_QA_Handoff"
VERSION = "1.0.0"
BUILD_ID = "2026.08.23-eng-qa2"
FIXED_ZIP_DT = (2026, 8, 23, 0, 0, 0)

CLANG = Path(os.environ.get("NYX_CLANG") or shutil.which("clang++") or "clang++")
LLD_LINK = Path(os.environ.get("NYX_LLD_LINK") or shutil.which("lld-link") or "lld-link")


class BuildError(RuntimeError):
    pass


def run(args: Sequence[str | os.PathLike[str]], *, cwd: Path | None = None, capture: bool = True) -> subprocess.CompletedProcess[str]:
    cmd = [str(x) for x in args]
    result = subprocess.run(cmd, cwd=cwd, text=True, capture_output=capture, check=False)
    if result.returncode != 0:
        raise BuildError(
            f"Command failed ({result.returncode}): {' '.join(cmd)}\n"
            f"STDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
        )
    return result


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temp.replace(path)


def clean_dir(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def copy_file(src: Path, dst: Path) -> None:
    if not src.is_file():
        raise BuildError(f"Required file is missing: {src}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def iter_files(root: Path) -> list[Path]:
    return sorted((p for p in root.rglob("*") if p.is_file()), key=lambda p: p.relative_to(root).as_posix().casefold())


def ensure_safe_tree(root: Path, *, forbidden_parts: set[str] | None = None) -> None:
    forbidden_parts = forbidden_parts or set()
    seen: set[str] = set()
    for path in iter_files(root):
        rel = path.relative_to(root).as_posix()
        pp = PurePosixPath(rel)
        if rel.startswith(("/", "\\")) or ".." in pp.parts:
            raise BuildError(f"Unsafe path in tree: {rel}")
        key = rel.casefold()
        if key in seen:
            raise BuildError(f"Case-colliding path in tree: {rel}")
        seen.add(key)
        if forbidden_parts.intersection(pp.parts):
            raise BuildError(f"Forbidden path in clean tree: {rel}")
        if path.is_symlink():
            raise BuildError(f"Symlink is not allowed in clean tree: {rel}")


def deterministic_zip(source_root: Path, output: Path, archive_root: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    if temp.exists():
        temp.unlink()
    ensure_safe_tree(source_root)
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as zf:
        for path in iter_files(source_root):
            rel = path.relative_to(source_root).as_posix()
            arc = f"{archive_root}/{rel}"
            info = zipfile.ZipInfo(arc, FIXED_ZIP_DT)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            zf.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    temp.replace(output)
    validate_zip(output)


def validate_zip(path: Path) -> None:
    seen: set[str] = set()
    with zipfile.ZipFile(path) as zf:
        bad = zf.testzip()
        if bad:
            raise BuildError(f"ZIP CRC failure in {path}: {bad}")
        for info in zf.infolist():
            name = info.filename
            pp = PurePosixPath(name)
            if name.startswith(("/", "\\")) or ".." in pp.parts or (len(name) > 1 and name[1] == ":"):
                raise BuildError(f"Unsafe ZIP path in {path}: {name}")
            key = name.casefold()
            if key in seen:
                raise BuildError(f"Duplicate/case-colliding ZIP path in {path}: {name}")
            seen.add(key)
            if ((info.external_attr >> 16) & 0o170000) == 0o120000:
                raise BuildError(f"Symlink entry in {path}: {name}")


def res_identifier(number: int) -> bytes:
    return struct.pack("<HH", 0xFFFF, number)


def resource_header(data_size: int, resource_type: int, resource_name: int, *, language: int = 1033, flags: int = 0x1030) -> bytes:
    identifiers = res_identifier(resource_type) + res_identifier(resource_name)
    pad = b"\0" * (-(8 + len(identifiers)) % 4)
    fixed = struct.pack("<IHHII", 0, flags, language, 0, 0)
    header_size = 8 + len(identifiers) + len(pad) + len(fixed)
    return struct.pack("<II", data_size, header_size) + identifiers + pad + fixed


def align4(data: bytes) -> bytes:
    return data + b"\0" * (-len(data) % 4)


def utf16z(value: str) -> bytes:
    return value.encode("utf-16le") + b"\0\0"


def version_block(key: str, value: bytes = b"", *, value_length: int | None = None, value_type: int = 1, children: Iterable[bytes] = ()) -> bytes:
    body = struct.pack("<HHH", 0, 0 if value_length is None else value_length, value_type) + utf16z(key)
    body = align4(body)
    body += value
    body = align4(body)
    for child in children:
        body += child
        body = align4(body)
    body = struct.pack("<H", len(body)) + body[2:]
    return body


def make_version_info(*, description: str, original_filename: str, internal_name: str) -> bytes:
    fixed = struct.pack(
        "<13I",
        0xFEEF04BD, 0x00010000,
        0x00010000, 0x00000000,
        0x00010000, 0x00000000,
        0x0000003F, 0,
        0x00040004, 1, 0, 0, 0,
    )
    strings = {
        "CompanyName": "Dietrich AI Labs",
        "FileDescription": description,
        "FileVersion": VERSION,
        "InternalName": internal_name,
        "LegalCopyright": "Copyright (c) 2026 Dietrich AI Labs",
        "OriginalFilename": original_filename,
        "ProductName": "Nyx PC Checkup",
        "ProductVersion": VERSION,
        "Comments": "Local-first Windows PC health and maintenance utility",
    }
    string_children = [
        version_block(k, utf16z(v), value_length=len(utf16z(v)) // 2, value_type=1)
        for k, v in strings.items()
    ]
    table = version_block("040904B0", b"", value_length=0, value_type=1, children=string_children)
    string_file_info = version_block("StringFileInfo", b"", value_length=0, value_type=1, children=[table])
    translation = version_block("Translation", struct.pack("<HH", 0x0409, 1200), value_length=4, value_type=0)
    var_file_info = version_block("VarFileInfo", b"", value_length=0, value_type=1, children=[translation])
    return version_block("VS_VERSION_INFO", fixed, value_length=len(fixed), value_type=0, children=[string_file_info, var_file_info])


def icon_resources(icon_path: Path) -> tuple[list[tuple[int, int, bytes]], bytes]:
    raw = icon_path.read_bytes()
    if len(raw) < 6:
        raise BuildError("Icon file is truncated")
    reserved, icon_type, count = struct.unpack_from("<HHH", raw, 0)
    if reserved != 0 or icon_type != 1 or count <= 0:
        raise BuildError("Icon file has an invalid header")
    icons: list[tuple[int, int, bytes]] = []
    group_entries = bytearray()
    for index in range(count):
        offset = 6 + index * 16
        width, height, colors, reserved_entry, planes, bits, size, image_offset = struct.unpack_from("<BBBBHHII", raw, offset)
        image = raw[image_offset:image_offset + size]
        if len(image) != size:
            raise BuildError("Icon image is truncated")
        resource_id = 101 + index
        icons.append((3, resource_id, image))
        group_entries += struct.pack("<BBBBHHIH", width, height, colors, reserved_entry, planes, bits, size, resource_id)
    group = struct.pack("<HHH", 0, 1, count) + bytes(group_entries)
    return icons, group


def write_resource_file(path: Path, *, description: str, original_filename: str, internal_name: str) -> None:
    manifest = (NATIVE / "app.manifest").read_bytes()
    icons, group = icon_resources(APP / "assets" / "nyx_pc_checkup.ico")
    entries: list[tuple[int, int, bytes]] = []
    entries.extend(icons)
    entries.append((14, 1, group))
    entries.append((16, 1, make_version_info(description=description, original_filename=original_filename, internal_name=internal_name)))
    entries.append((24, 1, manifest))
    output = bytearray(resource_header(0, 0, 0, language=0, flags=0))
    for typ, name, data in entries:
        output += resource_header(len(data), typ, name)
        output += align4(data)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(bytes(output))


def require_tools() -> None:
    for tool in [CLANG, LLD_LINK]:
        if not tool.is_file():
            raise BuildError(f"Required local build tool is missing: {tool}")


def make_import_library(definition: Path, output: Path) -> None:
    run([LLD_LINK, "/lib", "/machine:x64", f"/def:{definition}", f"/out:{output}"])


def compile_object(source: Path, output: Path, *, include_dirs: Sequence[Path] = ()) -> None:
    args: list[str | os.PathLike[str]] = [
        CLANG, "--target=x86_64-pc-windows-msvc", "-std=c++17", "-O2", "-ffreestanding",
        "-fno-exceptions", "-fno-rtti", "-fno-stack-protector", "-fno-ident", "-c", source, "-o", output,
    ]
    for include in include_dirs:
        args.extend(["-I", include])
    run(args)


def link_pe(output: Path, objects: Sequence[Path], resource: Path, libraries: Sequence[Path]) -> None:
    args: list[str | os.PathLike[str]] = [
        LLD_LINK, "/subsystem:windows,6.0", "/entry:wWinMainCRTStartup", "/nodefaultlib", "/machine:x64",
        "/dynamicbase", "/nxcompat", "/highentropyva", "/manifest:no", "/timestamp:0", "/opt:ref", "/opt:icf",
        f"/out:{output}",
    ]
    args.extend(objects)
    args.extend(libraries)
    args.append(resource)
    run(args)


def parse_pe(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    if data[:2] != b"MZ":
        raise BuildError(f"Not a PE file: {path}")
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe_offset:pe_offset + 4] != b"PE\0\0":
        raise BuildError(f"Invalid PE signature: {path}")
    machine, sections, timestamp = struct.unpack_from("<HHI", data, pe_offset + 4)
    opt = pe_offset + 24
    magic = struct.unpack_from("<H", data, opt)[0]
    subsystem = struct.unpack_from("<H", data, opt + 68)[0]
    dll_characteristics = struct.unpack_from("<H", data, opt + 70)[0]
    resource_rva, resource_size = struct.unpack_from("<II", data, opt + 112 + 2 * 8)
    import_rva, import_size = struct.unpack_from("<II", data, opt + 112 + 1 * 8)
    result = {
        "path": path.name,
        "size": path.stat().st_size,
        "sha256": sha256(path),
        "machine": f"0x{machine:04X}",
        "sections": sections,
        "timestamp": timestamp,
        "optionalHeaderMagic": f"0x{magic:04X}",
        "subsystem": subsystem,
        "dllCharacteristics": f"0x{dll_characteristics:04X}",
        "dynamicBase": bool(dll_characteristics & 0x40),
        "nxCompat": bool(dll_characteristics & 0x100),
        "highEntropyVa": bool(dll_characteristics & 0x20),
        "resourceRva": resource_rva,
        "resourceSize": resource_size,
        "importRva": import_rva,
        "importSize": import_size,
        "containsAsInvokerManifest": b"asInvoker" in data,
        "containsProductName": "Nyx PC Checkup".encode("utf-16le") in data,
    }
    if machine != 0x8664 or magic != 0x20B or subsystem != 2:
        raise BuildError(f"PE identity gate failed: {path}")
    if not (dll_characteristics & 0x40 and dll_characteristics & 0x100 and dll_characteristics & 0x20):
        raise BuildError(f"PE hardening flags missing: {path}")
    if not resource_rva or not resource_size or b"asInvoker" not in data:
        raise BuildError(f"PE resource/manifest gate failed: {path}")
    return result


def build_launchers() -> list[dict[str, object]]:
    require_tools()
    clean_dir(BUILD_NATIVE)
    for name in ["kernel32", "user32", "shell32"]:
        copy_file(NATIVE / "imports" / f"{name}.def", BUILD_NATIVE / f"{name}.def")
        make_import_library(BUILD_NATIVE / f"{name}.def", BUILD_NATIVE / f"{name}.lib")
    libraries = [BUILD_NATIVE / "kernel32.lib", BUILD_NATIVE / "user32.lib", BUILD_NATIVE / "shell32.lib"]
    specs = [
        ("launcher.cpp", "launcher.obj", "Nyx PC Checkup.exe", "Nyx PC Checkup", "Nyx PC Checkup.exe", "NyxPCCheckup"),
        ("uninstaller.cpp", "uninstaller.obj", "Uninstall Nyx PC Checkup.exe", "Nyx PC Checkup Uninstaller", "Uninstall Nyx PC Checkup.exe", "NyxPCCheckupUninstaller"),
    ]
    reports: list[dict[str, object]] = []
    for source_name, object_name, exe_name, description, original, internal in specs:
        obj = BUILD_NATIVE / object_name
        res = BUILD_NATIVE / (Path(object_name).stem + ".res")
        exe = BUILD_NATIVE / exe_name
        compile_object(NATIVE / source_name, obj, include_dirs=[NATIVE])
        write_resource_file(res, description=description, original_filename=original, internal_name=internal)
        link_pe(exe, [obj], res, libraries)
        reports.append(parse_pe(exe))
    return reports


def stage_portable() -> dict[str, object]:
    clean_dir(STAGE)
    copy_file(BUILD_NATIVE / "Nyx PC Checkup.exe", STAGE / "Nyx PC Checkup.exe")
    copy_file(BUILD_NATIVE / "Uninstall Nyx PC Checkup.exe", STAGE / "Uninstall Nyx PC Checkup.exe")

    for path in iter_files(APP):
        rel = path.relative_to(APP)
        if rel.as_posix() == "platform/linux/CONTRACT.md":
            continue
        if any(part in {"__pycache__", ".pytest_cache"} for part in rel.parts):
            continue
        copy_file(path, STAGE / "app" / rel)

    for name in ["README_FIRST.md", "LICENSE.txt", "THIRD_PARTY_NOTICES.txt", "VERSION.json", "SBOM.json"]:
        copy_file(ROOT / name, STAGE / name)
    copy_file(ROOT / "docs" / "USER_GUIDE.md", STAGE / "docs" / "USER_GUIDE.md")
    copy_file(ROOT / "docs" / "PRIVACY_AND_SECURITY.md", STAGE / "docs" / "PRIVACY_AND_SECURITY.md")
    copy_file(ROOT / "docs" / "INSTALL_UPGRADE_UNINSTALL.md", STAGE / "docs" / "INSTALL_UPGRADE_UNINSTALL.md")
    copy_file(ROOT / "docs" / "KNOWN_LIMITATIONS.md", STAGE / "docs" / "KNOWN_LIMITATIONS.md")

    forbidden = {"tests", "evidence", ".git", "__pycache__", ".pytest_cache", "source"}
    ensure_safe_tree(STAGE, forbidden_parts=forbidden)
    files = []
    for path in iter_files(STAGE):
        rel = path.relative_to(STAGE).as_posix()
        if rel == "PAYLOAD_MANIFEST.json":
            continue
        files.append({"path": rel, "size": path.stat().st_size, "sha256": sha256(path)})
    manifest = {
        "schema": "dietrich-ai-labs.nyx-pc-checkup.payload.v1",
        "product": "Nyx PC Checkup",
        "publisher": "Dietrich AI Labs",
        "version": VERSION,
        "build": BUILD_ID,
        "platform": "Windows 10/11 x64",
        "fileCount": len(files),
        "files": files,
    }
    atomic_json(STAGE / "PAYLOAD_MANIFEST.json", manifest)
    return manifest


def cpp_wide_literal(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'L"{escaped}"'


def generate_payload_header() -> Path:
    generated = NATIVE / "generated"
    clean_dir(generated)
    header = generated / "payload.h"
    files = iter_files(STAGE)
    lines = [
        "#pragma once",
        "#include \"win_types.hpp\"",
        "struct NyxPayloadEntry { const WCHAR* path; const BYTE* data; unsigned long long size; };",
        "",
    ]
    entries = []
    for index, path in enumerate(files):
        rel = path.relative_to(STAGE).as_posix().replace("/", "\\")
        data = path.read_bytes()
        symbol = f"NYX_PAYLOAD_DATA_{index}"
        lines.append(f"static const BYTE {symbol}[] = {{")
        for start in range(0, len(data), 24):
            chunk = data[start:start + 24]
            lines.append("    " + ",".join(f"0x{byte:02X}" for byte in chunk) + ",")
        if not data:
            lines.append("    0x00,")
        lines.append("};")
        entries.append((rel, symbol, len(data)))
    lines.append("")
    lines.append("static const NyxPayloadEntry NYX_PAYLOAD[] = {")
    for rel, symbol, size in entries:
        lines.append(f"    {{{cpp_wide_literal(rel)}, {symbol}, {size}ULL}},")
    lines.append("};")
    lines.append("static const unsigned long NYX_PAYLOAD_COUNT = (unsigned long)(sizeof(NYX_PAYLOAD)/sizeof(NYX_PAYLOAD[0]));")
    lines.append("")
    header.write_text("\n".join(lines), encoding="utf-8", newline="\n")
    return header


def build_setup() -> dict[str, object]:
    payload_header = generate_payload_header()
    obj = BUILD_NATIVE / "installer.obj"
    res = BUILD_NATIVE / "installer.res"
    setup = DIST / "Nyx_PC_Checkup_1.0.0_Setup.exe"
    DIST.mkdir(parents=True, exist_ok=True)
    compile_object(NATIVE / "installer.cpp", obj, include_dirs=[NATIVE, payload_header.parent])
    write_resource_file(
        res,
        description="Nyx PC Checkup Setup",
        original_filename="Nyx_PC_Checkup_1.0.0_Setup.exe",
        internal_name="NyxPCCheckupSetup",
    )
    libraries = [BUILD_NATIVE / "kernel32.lib", BUILD_NATIVE / "user32.lib", BUILD_NATIVE / "shell32.lib"]
    link_pe(setup, [obj], res, libraries)
    return parse_pe(setup)


def source_file_allowed(rel: PurePosixPath) -> bool:
    if len(rel.parts) == 1 and rel.name == "SOURCE_TREE_IDENTITY.json":
        return False
    if any(part in {".git", ".pytest_cache", "__pycache__", "dist", "release_staging", "handoff_staging", "evidence"} for part in rel.parts):
        return False
    if rel.parts[:2] == ("build", "native"):
        return False
    if rel.parts[:2] == ("native", "generated"):
        return False
    if rel.suffix.lower() in {".pyc", ".pyo", ".log", ".dmp"}:
        return False
    return True


def make_source_tree(temp_root: Path) -> Path:
    source_tree = temp_root / "Nyx_PC_Checkup_1.0.0_Source"
    source_tree.mkdir(parents=True)
    for path in iter_files(ROOT):
        rel = PurePosixPath(path.relative_to(ROOT).as_posix())
        if not source_file_allowed(rel):
            continue
        copy_file(path, source_tree / Path(*rel.parts))
    ensure_safe_tree(source_tree)
    return source_tree


def write_source_identity(source_tree: Path) -> dict[str, object]:
    records = []
    aggregate = hashlib.sha256()
    for path in iter_files(source_tree):
        rel = path.relative_to(source_tree).as_posix()
        digest = sha256(path)
        records.append({"path": rel, "size": path.stat().st_size, "sha256": digest})
        aggregate.update(rel.encode("utf-8") + b"\0" + str(path.stat().st_size).encode("ascii") + b"\0" + digest.encode("ascii") + b"\n")
    return {
        "schema": "dietrich-ai-labs.source-tree-identity.v1",
        "product": "Nyx PC Checkup",
        "version": VERSION,
        "build": BUILD_ID,
        "fileCount": len(records),
        "identityExcludes": ["SOURCE_TREE_IDENTITY.json"],
        "treeSha256": aggregate.hexdigest().upper(),
        "files": records,
    }


def build_archives() -> tuple[Path, Path, dict[str, object]]:
    clean_dir(DIST)
    portable = DIST / "Nyx_PC_Checkup_1.0.0_Portable.zip"
    deterministic_zip(STAGE, portable, "Nyx_PC_Checkup_1.0.0_Portable")
    with tempfile.TemporaryDirectory(prefix="nyx-source-") as tmp:
        temp = Path(tmp)
        source_tree = make_source_tree(temp)
        source_identity = write_source_identity(source_tree)
        atomic_json(source_tree / "SOURCE_TREE_IDENTITY.json", source_identity)
        source_zip = DIST / "Nyx_PC_Checkup_1.0.0_Source.zip"
        deterministic_zip(source_tree, source_zip, "Nyx_PC_Checkup_1.0.0_Source")
    return portable, source_zip, source_identity


def execute_tests() -> dict[str, object]:
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    lint_app = run([sys.executable, ROOT / "tools" / "ps_lint.py", APP])
    lint_windows = run([sys.executable, ROOT / "tools" / "ps_lint.py", ROOT / "tests" / "powershell"])
    pytest_result = run([sys.executable, "-m", "pytest", "-q"], cwd=ROOT)
    report = {
        "schema": "dietrich-ai-labs.engineering-test-report.v1",
        "product": "Nyx PC Checkup",
        "version": VERSION,
        "build": BUILD_ID,
        "environment": {
            "os": platform.platform(),
            "python": sys.version,
            "clang": run([CLANG, "--version"]).stdout.splitlines()[0],
            "lldLink": run([LLD_LINK, "--version"]).stdout.strip(),
            "windowsRuntimeExecuted": False,
        },
        "suites": [
            {"name": "PowerShell structural lint — app", "status": "PASS", "output": lint_app.stdout.strip()},
            {"name": "PowerShell structural lint — Windows tests", "status": "PASS", "output": lint_windows.stdout.strip()},
            {"name": "Python engineering contract, safety, PE, manifest, and archive suite", "status": "PASS", "output": pytest_result.stdout.strip()},
        ],
        "boundary": (
            "This Linux engineering environment validated source contracts, safety invariants, clean staging, archive safety, "
            "native x64 PE structure, embedded manifests/resources, and package identities. The three supplied PowerShell Windows "
            "suites (normal-user smoke/rollback, elevated all-users rollback, and installer lifecycle) require independent execution on Windows 10/11 x64."
        ),
        "verdict": "PASS WITH WINDOWS EXECUTION DEFERRED TO INDEPENDENT QA",
    }
    atomic_json(EVIDENCE / "ENGINEERING_TEST_REPORT.json", report)
    (EVIDENCE / "ENGINEERING_TEST_OUTPUT.txt").write_text(
        "PowerShell app lint\n====================\n" + lint_app.stdout +
        "\nPowerShell Windows-test lint\n==============================\n" + lint_windows.stdout +
        "\nPytest\n======\n" + pytest_result.stdout,
        encoding="utf-8",
    )
    return report


def packaging_report(payload: dict[str, object], source_identity: dict[str, object], pe_reports: list[dict[str, object]]) -> dict[str, object]:
    files = []
    for path in iter_files(DIST):
        files.append({"path": path.name, "size": path.stat().st_size, "sha256": sha256(path)})
    return {
        "schema": "dietrich-ai-labs.packaging-evidence.v1",
        "product": "Nyx PC Checkup",
        "version": VERSION,
        "build": BUILD_ID,
        "cleanStaging": {
            "path": "release_staging/Nyx_PC_Checkup_1.0.0_Portable",
            "payloadFileCount": payload["fileCount"],
            "payloadManifestSha256": sha256(STAGE / "PAYLOAD_MANIFEST.json"),
            "unexpectedFiles": 0,
            "symlinks": 0,
            "reparsePoints": "not applicable in Linux staging; Windows installer rejects reparse points during finalization",
        },
        "source": {"treeSha256": source_identity["treeSha256"], "fileCount": source_identity["fileCount"]},
        "nativePe": pe_reports,
        "artifacts": files,
        "authenticode": "Unsigned Engineering QA candidate; no code-signing certificate was supplied.",
    }


def write_environment_evidence(start_et: dt.datetime, stop_et: dt.datetime) -> None:
    elapsed = stop_et - start_et
    env = {
        "schema": "dietrich-ai-labs.engineering-environment.v1",
        "product": "Nyx PC Checkup",
        "version": VERSION,
        "build": BUILD_ID,
        "startEastern": start_et.isoformat(),
        "stopEastern": stop_et.isoformat(),
        "elapsedActiveBuildSessionSeconds": round(elapsed.total_seconds(), 3),
        "host": platform.platform(),
        "python": sys.version,
        "buildTools": {
            "clang": run([CLANG, "--version"]).stdout.splitlines()[0],
            "lldLink": run([LLD_LINK, "--version"]).stdout.strip(),
        },
        "networkBuildDependency": False,
        "githubUsed": False,
        "windowsRuntimeAvailable": False,
    }
    atomic_json(EVIDENCE / "BUILD_ENVIRONMENT_AND_TIMING.json", env)


def create_handoff(payload: dict[str, object], source_identity: dict[str, object], test_report: dict[str, object], packaging: dict[str, object]) -> Path:
    clean_dir(HANDOFF)
    copy_file(ROOT / "README_FIRST.md", HANDOFF / "README_FIRST.md")

    for name in ["Nyx_PC_Checkup_1.0.0_Setup.exe", "Nyx_PC_Checkup_1.0.0_Portable.zip"]:
        copy_file(DIST / name, HANDOFF / "candidate" / name)
    copy_file(DIST / "Nyx_PC_Checkup_1.0.0_Source.zip", HANDOFF / "source" / "Nyx_PC_Checkup_1.0.0_Source.zip")

    for path in iter_files(ROOT / "docs"):
        copy_file(path, HANDOFF / "docs" / path.name)
    copy_file(ROOT / "tests" / "test_engineering_contracts.py", HANDOFF / "tests" / "test_engineering_contracts.py")
    for path in iter_files(ROOT / "tests" / "powershell"):
        copy_file(path, HANDOFF / "tests" / "powershell" / path.name)
    copy_file(ROOT / "tools" / "ps_lint.py", HANDOFF / "tests" / "tools" / "ps_lint.py")

    for path in iter_files(EVIDENCE):
        copy_file(path, HANDOFF / "evidence" / path.name)
    for name in ["VERSION.json", "SBOM.json", "LICENSE.txt", "THIRD_PARTY_NOTICES.txt"]:
        copy_file(ROOT / name, HANDOFF / "metadata" / name)
    copy_file(STAGE / "PAYLOAD_MANIFEST.json", HANDOFF / "metadata" / "PAYLOAD_MANIFEST.json")
    atomic_json(HANDOFF / "metadata" / "SOURCE_TREE_IDENTITY.json", source_identity)

    gate = {
        "schema": "dietrich-ai-labs.engineering-gate.v1",
        "product": "Nyx PC Checkup",
        "version": VERSION,
        "build": BUILD_ID,
        "engineeringVerdict": "READY FOR INDEPENDENT WINDOWS QA",
        "sourceAndPackagingTests": test_report["verdict"],
        "windowsRuntimeAndInstallerLifecycle": "NOT EXECUTED IN LINUX ENGINEERING ENVIRONMENT — REQUIRED FROM QA",
        "releaseAuthorization": False,
        "nextAuthority": "Independent QA: PASS / CONDITIONAL PASS / HOLD / FAIL",
        "candidateSetupSha256": sha256(HANDOFF / "candidate" / "Nyx_PC_Checkup_1.0.0_Setup.exe"),
        "candidatePortableSha256": sha256(HANDOFF / "candidate" / "Nyx_PC_Checkup_1.0.0_Portable.zip"),
    }
    atomic_json(HANDOFF / "ENGINEERING_GATE.json", gate)

    # Master manifest intentionally excludes itself and SHA256SUMS to avoid circular identities.
    manifest_files = []
    for path in iter_files(HANDOFF):
        rel = path.relative_to(HANDOFF).as_posix()
        if rel in {"MASTER_MANIFEST.json", "SHA256SUMS.txt"}:
            continue
        manifest_files.append({"path": rel, "size": path.stat().st_size, "sha256": sha256(path)})
    master = {
        "schema": "dietrich-ai-labs.master-handoff-manifest.v1",
        "product": "Nyx PC Checkup",
        "version": VERSION,
        "build": BUILD_ID,
        "candidateStatus": "Engineering QA candidate — release blocked pending independent Windows QA",
        "fileCount": len(manifest_files),
        "files": manifest_files,
        "payloadManifestSha256": sha256(STAGE / "PAYLOAD_MANIFEST.json"),
        "sourceTreeSha256": source_identity["treeSha256"],
        "packagingEvidenceSha256": sha256(EVIDENCE / "PACKAGING_EVIDENCE.json"),
    }
    atomic_json(HANDOFF / "MASTER_MANIFEST.json", master)

    sums = []
    for path in iter_files(HANDOFF):
        rel = path.relative_to(HANDOFF).as_posix()
        if rel == "SHA256SUMS.txt":
            continue
        sums.append(f"{sha256(path)}  {rel}")
    (HANDOFF / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")

    ensure_safe_tree(HANDOFF, forbidden_parts={".git", "__pycache__", ".pytest_cache"})
    final_zip = DIST / "Nyx_PC_Checkup_1.0.0_Engineering_QA_Handoff.zip"
    deterministic_zip(HANDOFF, final_zip, HANDOFF.name)
    return final_zip


def validate_handoff_archive(path: Path) -> None:
    """Verify the final immutable handoff from inside the ZIP itself."""
    validate_zip(path)
    root = HANDOFF.name + "/"
    with zipfile.ZipFile(path) as zf:
        names = {info.filename for info in zf.infolist() if not info.is_dir()}
        required = {
            root + "MASTER_MANIFEST.json",
            root + "SHA256SUMS.txt",
            root + "ENGINEERING_GATE.json",
            root + "candidate/Nyx_PC_Checkup_1.0.0_Setup.exe",
            root + "candidate/Nyx_PC_Checkup_1.0.0_Portable.zip",
            root + "source/Nyx_PC_Checkup_1.0.0_Source.zip",
        }
        if not required <= names:
            raise BuildError(f"Final handoff is missing required entries: {sorted(required - names)}")
        manifest = json.loads(zf.read(root + "MASTER_MANIFEST.json"))
        expected = {entry["path"]: entry for entry in manifest["files"]}
        actual_names = {
            name[len(root):]
            for name in names
            if name.startswith(root) and name[len(root):] not in {"MASTER_MANIFEST.json", "SHA256SUMS.txt"}
        }
        if set(expected) != actual_names:
            raise BuildError("Final handoff master-manifest inventory does not match the archive")
        for rel, entry in expected.items():
            data = zf.read(root + rel)
            if len(data) != int(entry["size"]) or hash_bytes(data) != entry["sha256"]:
                raise BuildError(f"Final handoff master-manifest identity mismatch: {rel}")
        sum_lines = zf.read(root + "SHA256SUMS.txt").decode("utf-8").splitlines()
        sums: dict[str, str] = {}
        for line in sum_lines:
            digest, sep, rel = line.partition("  ")
            if not sep or rel in sums:
                raise BuildError("Final handoff SHA256SUMS format or uniqueness check failed")
            sums[rel] = digest
        sum_actual = {
            name[len(root):]
            for name in names
            if name.startswith(root) and name[len(root):] != "SHA256SUMS.txt"
        }
        if set(sums) != sum_actual:
            raise BuildError("Final handoff SHA256SUMS inventory does not match the archive")
        for rel, digest in sums.items():
            if hash_bytes(zf.read(root + rel)) != digest:
                raise BuildError(f"Final handoff SHA256SUMS mismatch: {rel}")
        gate = json.loads(zf.read(root + "ENGINEERING_GATE.json"))
        if gate["candidateSetupSha256"] != hash_bytes(zf.read(root + "candidate/Nyx_PC_Checkup_1.0.0_Setup.exe")):
            raise BuildError("Final handoff setup identity does not match ENGINEERING_GATE.json")
        if gate["candidatePortableSha256"] != hash_bytes(zf.read(root + "candidate/Nyx_PC_Checkup_1.0.0_Portable.zip")):
            raise BuildError("Final handoff portable identity does not match ENGINEERING_GATE.json")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--keep-intermediates", action="store_true", help="Retain compiler objects and generated payload header")
    args = parser.parse_args()
    eastern = ZoneInfo("America/New_York")
    start_et = dt.datetime.now(tz=eastern)
    try:
        for path in [STAGE_BASE, DIST, EVIDENCE, HANDOFF_BASE]:
            clean_dir(path)
        pe_reports = build_launchers()
        payload = stage_portable()
        portable, source_zip, source_identity = build_archives()
        setup_report = build_setup()
        pe_reports.append(setup_report)
        # build_archives cleaned DIST before setup, so portable/source remain and setup was added.
        test_report = execute_tests()
        packaging = packaging_report(payload, source_identity, pe_reports)
        atomic_json(EVIDENCE / "PACKAGING_EVIDENCE.json", packaging)
        atomic_json(EVIDENCE / "PE_INSPECTION.json", {"schema": "dietrich-ai-labs.pe-inspection.v1", "files": pe_reports})
        stop_et = dt.datetime.now(tz=eastern)
        write_environment_evidence(start_et, stop_et)
        final_zip = create_handoff(payload, source_identity, test_report, packaging)
        validate_handoff_archive(final_zip)
        summary = {
            "handoff": str(final_zip),
            "size": final_zip.stat().st_size,
            "sha256": sha256(final_zip),
            "setup": {"path": str(DIST / "Nyx_PC_Checkup_1.0.0_Setup.exe"), "size": (DIST / "Nyx_PC_Checkup_1.0.0_Setup.exe").stat().st_size, "sha256": sha256(DIST / "Nyx_PC_Checkup_1.0.0_Setup.exe")},
            "portable": {"path": str(portable), "size": portable.stat().st_size, "sha256": sha256(portable)},
            "source": {"path": str(source_zip), "size": source_zip.stat().st_size, "sha256": sha256(source_zip), "treeSha256": source_identity["treeSha256"]},
            "tests": test_report["suites"],
            "engineeringVerdict": "READY FOR INDEPENDENT WINDOWS QA",
            "finalHandoffInternalAudit": "PASS",
        }
        atomic_json(DIST / "BUILD_SUMMARY.json", summary)
        print(json.dumps(summary, indent=2))
        if not args.keep_intermediates:
            for cache in [ROOT / ".pytest_cache", ROOT / "tests" / ".pytest_cache", ROOT / "tests" / "__pycache__"]:
                if cache.exists():
                    shutil.rmtree(cache)
        return 0
    except Exception as exc:
        print(f"BUILD FAILED: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
