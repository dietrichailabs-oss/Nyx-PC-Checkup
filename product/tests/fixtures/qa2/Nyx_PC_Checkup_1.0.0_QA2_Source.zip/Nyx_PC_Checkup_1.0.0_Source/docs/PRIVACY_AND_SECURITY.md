# Privacy and Security Notes

## Privacy defaults

Nyx PC Checkup has no telemetry, analytics, advertising, tracking, account, cloud synchronization, automatic report upload, or remote inventory. It does not inspect browser history, cookies, passwords, authentication tokens, document contents, product keys, or hardware serial numbers.

**Privacy: Everything analyzed by PC Checkup stays on this computer unless you explicitly export it.**

A single bounded DNS resolution to Microsoft’s Windows connectivity-check hostname is used only during the Network Basics check. The check records success/failure, not addresses, and does not change DNS, proxy, firewall, routing, or adapter settings.

## Local data

Per-user data is stored under `%LOCALAPPDATA%\Dietrich AI Labs\Nyx PC Checkup`. Logs rotate with a small cap and are redacted. Scan history stores the latest structured result. Action history is minimized. Current-user startup rollback records are encrypted using Windows DPAPI CurrentUser and are bound to the Windows profile. For all-users changes, authoritative rollback data is stored under `%ProgramData%\DietrichAI.NyxPCCheckup\startup-rollback` with protected ACLs for Administrators and SYSTEM; the current user receives read access and a DPAPI pointer only.

## Privilege model

Ordinary launch, Quick Check, Full Check, report export, and current-user actions run without elevation. Administrator approval is requested only when the user explicitly confirms a supported all-users startup change or restoration. Declining elevation leaves the application usable. The elevated worker verifies SHA-256 of the exact user-confirmed request before parsing it. All-users rollback restoration ignores user-pointer source/command fields and reads its write authority only from the protected machine journal.

## File-system safety

Storage and Downloads checks skip directory reparse points and apply file/time bounds. Cleanup operations do not accept arbitrary paths from the UI. They perform bounded enumeration of allowlisted roots, compare stable candidate IDs, length, and timestamp, and validate every parent component for reparse/junction substitution twice—including immediately before using the system Recycle Bin.

## Registry safety

Read checks access supported Windows status and inventory locations. The only implemented registry modification is an explicitly confirmed startup disable/restore within the fixed Run/RunOnce allowlist plus per-user uninstall registration during setup. Nyx does not run a registry cleaner or edit Windows Update, Defender, firewall, service, network, browser, or policy configuration.

## Package safety

The runtime payload is allowlist-built. Setup rejects temporary-path collisions and reparse-backed installation boundaries; the uninstaller independently revalidates its exact install/app directories before importing modules or scheduling removal. The installed payload verifies path, size, SHA-256, exact file count, and absence of reparse points before registration. Source, tests, logs, caches, credentials, user data, Git metadata, and QA evidence are excluded from the installed runtime.

## Signing status

This Engineering QA candidate is unsigned. Windows may show a publisher/reputation warning. Code signing is a release-management gate and must be applied only to the exact QA/Sable/Iris-approved immutable candidate, followed by hash/signature validation and final artifact QA.
