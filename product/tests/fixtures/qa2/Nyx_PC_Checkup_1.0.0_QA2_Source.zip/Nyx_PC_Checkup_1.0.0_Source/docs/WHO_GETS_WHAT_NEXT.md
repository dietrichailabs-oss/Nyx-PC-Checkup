# Who Gets What Next

## Independent QA

**Receives:** Exact master handoff ZIP; installer; portable ZIP; source ZIP; master/payload manifests; sizes and SHA-256; SBOM; module map/contracts; Engineering test evidence; Windows smoke/lifecycle scripts; QA matrix.  
**Purpose:** Independent functional, adversarial, safety, permission, privacy, UI, packaging, install/upgrade/repair/uninstall, and regression validation.  
**Authority:** PASS / CONDITIONAL PASS / HOLD / FAIL.  
**Blocked pending decision:** Sable, Iris, Release Manager, and public release. QA must not silently edit Engineering source.

## Engineering on QA correction

**Receives:** QA report, exact failing artifact identity, evidence, reproduction steps, severity, and suspected module boundary.  
**Purpose:** Correct defects in a new build without altering QA evidence.  
**Authority:** Build and resubmit only; Engineering does not approve its own release.  
**Blocked pending decision:** Any corrected byte identity requires applicable full/regression retesting.

## Sable — Security & Privacy

**Receives:** Exact QA-approved candidate and hash; payload/master manifests; SBOM; package; action/rollback design; logging/report redaction evidence; installer/uninstaller evidence.  
**Purpose:** Security/privacy review of package, secrets, logging, deletion, registry/elevation, DPAPI and protected machine-journal rollback, local data, Windows Security interaction, dependencies, installer behavior, telemetry absence, and permissions.  
**Authority:** APPROVE / CONDITIONAL / HOLD.  
**Blocked pending decision:** Compliance and release publication remain blocked where Sable approval is required.

## Iris — Compliance and Licensing

**Receives:** Exact candidate identity; SBOM; license/notices; dependency/build information; product/security/privacy claims; limitations; installer/package information.  
**Purpose:** Licensing, Windows API/claim/disclosure, and distribution review.  
**Authority:** APPROVE / CONDITIONAL / HOLD.  
**Blocked pending decision:** Public descriptions, website/download claims, and release publication.

## Final exact-artifact QA

**Receives:** The exact post-signing/post-packaging candidate intended for release, matching approvals and release manifest.  
**Purpose:** Confirm signatures, hashes, version progression, install/launch/uninstall, and byte identity after any release-operation change.  
**Authority:** PASS / HOLD.  
**Blocked pending decision:** Publication.

## Release Manager / Release Butler

**Receives:** Exact fully approved immutable installer/portable artifacts, hashes, signatures, manifest, SBOM, notices, rollback package, and approval records.  
**Purpose:** Stage and publish only the approved artifacts.  
**Authority:** May publish; may stop distribution on identity/integrity uncertainty; may not override QA/Sable/Iris HOLD.  
**Blocked pending decision:** Dietrich AI Labs public release until all required approvals match the exact bytes.
