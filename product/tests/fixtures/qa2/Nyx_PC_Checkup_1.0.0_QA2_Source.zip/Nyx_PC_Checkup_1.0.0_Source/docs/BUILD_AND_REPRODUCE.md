# Build and Reproduce

## Prerequisites

- Python 3.11 or later
- LLVM/Clang with `clang++` and `lld-link` capable of targeting `x86_64-pc-windows-msvc` (available on `PATH`, or set `NYX_CLANG` and `NYX_LLD_LINK`)
- The repository-provided minimal Windows import-library definitions
- `pytest`

No downloaded application runtime dependency is bundled. The target uses Windows PowerShell 5.1 and Windows/.NET components present on supported Windows installations.

## Build

From the project root:

```text
python3 tools/build_and_verify_reproduction.py
python3 -m pytest -q
```

The preferred wrapper runs the local build, rebuilds the generated source ZIP from a separate temporary root, requires exact setup/portable/source SHA-256 matches, and then records `evidence/REPRODUCIBILITY_CHECK.json`. The underlying build script deletes and recreates `release_staging/` and `dist/`, compiles the launcher/uninstaller, copies only explicit runtime files, generates and verifies `PAYLOAD_MANIFEST.json`, generates the embedded payload header, compiles the installer, creates deterministic ZIPs, emits SHA-256 manifests and evidence, and builds the master QA handoff.

## Determinism notes

ZIP entry timestamps are fixed and entries are sorted. JSON is normalized. The native compiler may still encode toolchain-specific PE metadata, so reproduce using the tool versions recorded in `evidence/BUILD_ENVIRONMENT_AND_TIMING.json` and compare both hashes and `evidence/PE_INSPECTION.json`.

## Windows verification

After copying the immutable handoff to a clean Windows VM, run all three PowerShell scripts in `tests/powershell/` under their documented standard/elevated/disposable-VM contexts and preserve their JSON output. Do not edit the candidate in place. Any correction requires a new version/build identity, rebuilt manifests, new hashes, and applicable regression.
