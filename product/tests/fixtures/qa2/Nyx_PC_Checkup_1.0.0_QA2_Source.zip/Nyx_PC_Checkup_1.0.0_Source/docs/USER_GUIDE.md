# User Guide

## Install

Open `Nyx_PC_Checkup_1.0.0_Setup.exe`. Choose whether to create a desktop shortcut. The program installs for the current Windows user and should not request administrator access for installation or ordinary scans.

## Check the PC

Open Nyx PC Checkup and select **Check My PC** for the fast check or **Run Full Check** for folder analysis, Downloads, cleanup preview, battery/drive information, performance, and installed applications. Progress remains visible and a scan can be cancelled. Cancellation preserves completed results.

The result language means:

- **Good — No action needed:** the available evidence did not show a meaningful problem.
- **Needs Attention — Recommended action:** the evidence indicates a real reliability, storage, backup, update, security, or connectivity concern.
- **Optional — Your choice:** the PC can operate normally; the suggestion may improve convenience or reclaim space.
- **Unknown — Could not determine:** Windows did not provide enough reliable information. Unknown is not treated as a failure.

## Review startup apps

The Startup page explains where each supported item starts, whether its file still exists, and whether administrator approval is needed. Disabling an entry is always explicit. Nyx records protected rollback state before changing the entry. A disabled item remains listed with **Re-enable**.

Do not disable security software, touchpad/audio utilities, backup tools, cloud-sync clients, or hardware support utilities unless you understand the consequence.

## Use cleanup safely

Run a Full Check, open **Cleanup**, review every candidate, select only desired items, read the total and consequence, and confirm. Nothing is preselected. Supported files are sent to the Windows Recycle Bin; emptying the Recycle Bin is identified as permanent. A failure leaves the file in place and is reported.

Nyx does not automatically delete Documents, photos, videos, general Downloads content, browser profiles, Windows Update files, restore points, installer caches required by Windows, app databases, cloud-sync data, saved games, or development files.

## Open official Windows settings

Nyx redirects update, security, backup, storage, and installed-app actions to the corresponding Windows interface. It does not reimplement Windows Update, replace antivirus, alter firewall rules, uninstall apps automatically, install drivers, or change DNS/proxy settings.

## Export a report

After a scan, choose **Export report**, review the preview, select TXT, JSON, or PDF, and choose a destination. The default report is minimized and redacted. It stays local unless you decide to send it.

## Settings and local data

Choose Dark, Light, or Follow Windows theme. Notifications are disabled by default and are in-app only in Version 1. The local data folder and log-deletion action are available from Settings.

## Uninstall

Use Windows Installed Apps or run `Uninstall Nyx PC Checkup.exe`. The uninstaller restores active reversible startup changes first. You may choose whether to remove local settings, logs, scan history, and action history. It preserves recovery data if a startup item cannot be restored.
