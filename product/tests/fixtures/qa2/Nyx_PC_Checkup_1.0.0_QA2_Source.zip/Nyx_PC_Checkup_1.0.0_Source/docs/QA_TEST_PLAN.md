# Independent QA Test Plan

QA must assume Engineering missed something and must not repair source silently. Record Eastern Time start/stop/elapsed, exact artifact name/size/SHA-256, Windows edition/build, architecture, privilege context, VM snapshot, findings, evidence, and final PASS / CONDITIONAL PASS / HOLD / FAIL.


## Supplied executable Windows gates

Run all scripts from the immutable handoff and preserve their JSON evidence:

1. `Run-WindowsSmokeTests.ps1` as a normal user. It parses all runtime scripts in Windows PowerShell 5.1, executes health-rule/report/configuration/cleanup bounds, proves Quick Check is read-only, and performs an exact HKCU startup disable/restore round trip.
2. `Run-WindowsElevatedStartupRollback.ps1 -DestructiveCleanVmAcknowledged` from an elevated Windows PowerShell 5.1 session in a disposable VM. It creates one temporary HKLM Run fixture, verifies the protected ProgramData ACL/journal, intentionally tampers with the user DPAPI pointer, and proves restore uses machine authority.
3. `Run-WindowsInstallerLifecycle.ps1 -SetupPath <exact setup> -DestructiveCleanVmAcknowledged` from a disposable clean VM. It verifies fresh install, app-running rejection, repair, an uninstall-abort conflict, successful restore/uninstall, reinstall, purge, and leftovers.

These scripts supplement rather than replace independent exploratory and adversarial QA.

## Intake and identity

- Verify outer ZIP hash, CRC, traversal safety, duplicate/case-collision safety, and manifest.
- Verify installer and portable SHA-256 against `SHA256SUMS.txt`.
- Verify PE x64 GUI identity, no unexpected imports, no signature claim, and version/build text in app.
- Compare installed files exactly with `PAYLOAD_MANIFEST.json`; confirm source/tests/evidence/logs/secrets are absent.

## Fresh install and launch

- Standard-user fresh install with and without desktop shortcut.
- Confirm per-user path, Start-menu shortcut, icon, working directory, uninstall registration, and no UAC for install.
- Launch from shortcut and installed executable; confirm no dev path/runtime bundle required.
- Confirm one instance, clean startup, close, relaunch, and no resident process/service/task after exit.
- Test Windows 10 and 11 x64 where available.

## Quick and Full Check

- Healthy machine acceptance sentence.
- Quick Check scope and duration.
- Full Check progress, UI responsiveness, cancellation, partial result preservation, retry, and concurrent file changes.
- One failed module must not cancel unrelated modules.
- Confirm scans make no file, registry, update, security, firewall, network, uninstall, driver, or service modification.

## Functional matrices

- Storage boundaries immediately below/at/above absolute and percentage thresholds.
- Profile folders empty/large/access denied/Unicode/long paths/reparse points/network drive/offline/removable/millions of files.
- Downloads age/type/size boundaries, old installers/archives, duplicates, same-size nonduplicates, disappearing/locked files.
- Startup HKCU/HKLM, Run/RunOnce/WOW6432, current/common Startup folders, broken command, quoted command, environment variables, publisher absent, unsupported value types.
- Updates: current, pending, restart pending, APIs unavailable, empty history, history access denied.
- Security: Defender active/inactive, third-party AV, multiple AV, firewall partial/off, Secure Boot/TPM/encryption available/unavailable.
- Backup: recent successful supported task, configured without recent success, no supported indicator, third-party backup caveat.
- Battery: desktop, laptop, charge only, capacities available, ordinary aging, severe wear, malformed values.
- Drive: healthy, warning, unknown, missing Storage module/reliability counters.
- Performance: ordinary/high snapshot; verify no optimizer/process killer.
- Network: online, adapter up/no Internet, disconnected, DNS timeout/failure, API unavailable; verify no configuration changes.
- Installed apps: HKCU/HKLM/WOW6432 duplicates, missing fields, Unicode, large counts; verify only Windows uninstall redirect.

## Destructive and reversible actions

- Confirm no item is selected by default and exact count/bytes/consequence shown.
- Cleanup cancel at confirmation; candidate changes between scan/action; locked/deleted/reparse-swapped/file-size-changed candidate; partial failure reporting.
- Recycle Bin move and separately confirmed empty operation.
- Prove arbitrary path injection is rejected.
- Startup disable cancel; stale ID; command changed; unsupported value kind; current-user change; all-users UAC accept/decline.
- Interrupt current-user startup action before and after modification; verify DPAPI journal and recovery. For all-users actions, verify ProgramData ACL inheritance is disabled, Administrators/SYSTEM retain write authority, the owner has read but not write authority, and a tampered DPAPI pointer cannot redirect elevated restoration.
- Restore with original location free, same content already restored, conflicting value/file, missing backup, wrong Windows user.
- Uninstall with active current-user and all-users rollback; inject an original-name conflict and prove exit 6 occurs before program files, registration, shortcuts, or recovery data are removed. Remove the conflict and prove exact restoration precedes successful uninstall.

## Reports, privacy, and logs

- Preview required for TXT/JSON/PDF.
- Verify usernames, profile paths, IP addresses, email addresses, tokens, passwords, API keys, authorization headers, serials, product keys, browser data, and document contents are excluded/redacted.
- Test malformed evidence and Unicode.
- Confirm local-only behavior with packet/process monitoring; the only expected outbound-capable operation is the bounded DNS resolution during Network Basics.
- Confirm log rotation/cap/redaction/delete and no upload.

## UI and accessibility

- Dark, Light, Follow Windows.
- 100%, 125%, 150%, 200% scaling; 1366×768 and common laptop displays.
- No clipping/overlap, keyboard navigation, focus visibility, screen-reader labels where exposed, color-blind usability, statuses not color-only.
- Plain language, no alarmism, no fake score, no placeholder controls, no dead buttons.

## Upgrade, repair, uninstall

- Same-version repair; prior-version upgrade fixture when available; interrupted stage/activation/finalization and rollback.
- App-running install rejection.
- Quiet install, quiet uninstall preserve data, explicit purge.
- Clean uninstall shortcuts/registry/install directory; no services/tasks/drivers/firewall/network leftovers.
- Reinstall after uninstall and after preserve-data uninstall.

## Verdict gate

PASS requires no release blocker and exact immutable artifact success across functional, safety, privacy, UI, and lifecycle gates. Any candidate byte change invalidates the prior artifact verdict.
