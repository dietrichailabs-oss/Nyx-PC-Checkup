# Nyx PC Checkup 1.0.0 — Engineering QA Candidate

Initial complete Version 1 candidate.

Highlights include plain-language Quick and Full checks; deterministic Good/Needs Attention/Optional/Unknown states; system, storage, Downloads, update, security, startup, backup, battery, drive, performance, installed-app, uptime, network, and cleanup-preview modules; cancellable read-only scans; explicit safe redirects; DPAPI-protected current-user rollback plus administrator-protected all-users rollback; bounded, parent-chain-revalidated, user-selected Recycle Bin cleanup; privacy-safe TXT/JSON/PDF export; light/dark/Windows themes; local rotating logs; and a per-user rollback-capable clean-payload installer.

This is an unsigned Engineering candidate for independent QA, not a public release.

Engineering candidate revision `2026.08.23-eng-qa2` closes draft packaging and safety regressions: embedded native manifests, bounded cleanup traversal, repeated junction checks before deletion, request-hash-bound elevated actions, protected all-users rollback authority, transactional quiet-aware installer finalization, reparse/collision-safe installer and uninstaller boundaries, fail-closed uninstall restoration, validated configuration, conservative in-app notifications, Windows 11 caption accuracy, and forced cleanup of read-only scan workers on close.
