# Module Contracts and Failure Behavior

## Result contract

Every health check returns an object with `CheckId`, `Category`, `Name`, `Status`, `Severity`, `Finding`, `Reason`, `Evidence`, `Recommendation`, `ActionSafetyLevel`, `Timestamp`, `DataSource`, `RequiresElevation`, `Complete`, `ErrorReason`, and optional `Details`. Status is one of `Good`, `NeedsAttention`, `Optional`, or `Unknown`.

A check must never return a fabricated healthy state when its data source failed. Unsupported, incomplete, denied, malformed, or missing data becomes **Unknown** or an explicitly incomplete result. Check exceptions are isolated by `Invoke-NyxIsolatedCheck`.

## Read-only check contract

A module under `checks/` may query local operating-system and file metadata, perform a bounded DNS resolution test, and hash bounded duplicate candidates. It must not delete or move files, write startup configuration, change Windows Update or security settings, uninstall software, change networking, request elevation, or upload data.

Long-running file checks accept a cancel marker and enforce configuration bounds. Reparse directories are skipped. Access-denied and disappearing-file events are counted or isolated.

## Health-rule contract

Thresholds are loaded from `health_rules/rules.json`. UI code may display results but may not reinterpret the thresholds. Boundary behavior is covered by static/reference tests and the Windows PowerShell smoke suite.

Key storage boundaries are deliberately conservative: critically low space requires a combination of small absolute free bytes and low percentage, with a hard floor for exceptionally low bytes. Thirty gigabytes free is not automatically critical.

## Action contract

`ActionWorker.ps1` accepts only UUID-paired request/result files in the app-owned local temp directory. The UI passes SHA-256 of the exact confirmed request on the process command line; the worker reads the bytes once, verifies that hash and the confirmation marker, and parses only the verified copy. It accepts only three operations: `DisableStartup`, `EnableStartup`, and `Cleanup`.

Startup actions operate only on the five allowlisted Run/RunOnce locations and the exact current-user/common Startup folders. The worker receives a stable ID, then re-enumerates current state. Current-user rollback state is protected with DPAPI CurrentUser. All-users entries request elevation only for that action and use an administrator-protected ProgramData journal as authority; the DPAPI user record is a pointer and cannot authorize an elevated registry or file write. Restore validates journal identity, owner SID, ACL protection, parent-directory reparse status, source boundary, and file backup identity before acting.

Cleanup actions accept candidate IDs only. They re-enumerate approved roots, reject reparse points/directories, verify candidate identity and metadata, and use the Windows Recycle Bin. They do not permit arbitrary input paths.

## Report contract

Reports include version, general system class, result statuses, explanations, recommendations, timestamps, data-source names, and minimized evidence. They exclude document contents, browser data, passwords, tokens, product keys, hardware serials, unnecessary usernames, and IP addresses by default. Export occurs only after preview.

## Configuration contract

Configuration is local JSON. Unknown entries do not become executable behavior. Theme, booleans, log limits, action-history limits, and scan/hash limits are type-checked and clamped to documented safety ranges. Missing values fall back to defaults. Oversized, reparse-backed, malformed, or otherwise corrupt files are quarantined locally and defaults are restored. No configuration enables telemetry or remote upload.

## Logging contract

Logs are local, rotated, size-capped, and redacted. Production logging records module outcomes and errors, not private file contents. The user can delete logs from Settings.

## Installer contract

The installer must not copy the project tree. It writes the embedded allowlisted payload to a staging sibling, creates an upgrade rollback sibling, activates by same-volume rename, and runs `InstallWorker.ps1`. The worker verifies exact manifest path/size/hash/file count before creating shortcuts or uninstall registration. Before changing shortcuts or uninstall registration, the worker snapshots their prior state. Failure restores those external integration snapshots and the native installer restores the prior payload when present; quiet setup never blocks on an error dialog.

## Uninstaller contract

Uninstall validates the exact per-user installation root. It attempts to restore every Nyx-disabled startup item before removing the program. If any restoration fails, uninstall exits 6 before removing the application directory, shortcut, uninstall registration, or local recovery data. Normal quiet uninstall preserves local user data; `/purgedata` is explicit and occurs only after every restore succeeds.
