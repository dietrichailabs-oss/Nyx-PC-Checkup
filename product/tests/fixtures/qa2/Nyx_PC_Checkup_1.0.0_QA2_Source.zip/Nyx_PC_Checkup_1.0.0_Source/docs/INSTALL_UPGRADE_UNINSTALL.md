# Install, Upgrade, Repair, and Uninstall

## Fresh install

Run `Nyx_PC_Checkup_1.0.0_Setup.exe` as the target standard user. The default location is:

`%LOCALAPPDATA%\Programs\Dietrich AI Labs\Nyx PC Checkup`

Interactive setup offers a desktop shortcut choice and always creates a Start-menu shortcut. Silent QA syntax:

`Nyx_PC_Checkup_1.0.0_Setup.exe /quiet /nolaunch`

Add `/desktop` to request a desktop shortcut in quiet mode.

## Upgrade or repair

Run the same or newer setup while Nyx is closed. Setup rejects colliding temporary paths, junctions/symbolic links at its staging/rollback/target boundaries, and any pre-existing embedded payload file. Setup writes and verifies a clean sibling payload, renames the existing install to a rollback sibling, activates the new payload, and finalizes registration. Before finalization changes shortcuts or uninstall registration, it snapshots their exact prior state. A finalization failure restores those external records, removes the failed new payload, and restores the previous install. Quiet setup suppresses all finalization dialogs.

Running 1.0.0 setup over 1.0.0 exercises the repair/reinstall path. The application contains no in-app updater.

## Uninstall

Use Windows Installed Apps, the Start-menu uninstall registration, or:

`"%LOCALAPPDATA%\Programs\Dietrich AI Labs\Nyx PC Checkup\Uninstall Nyx PC Checkup.exe"`

Silent QA syntax preserving local data:

`Uninstall Nyx PC Checkup.exe /quiet`

Explicit silent removal of local data:

`Uninstall Nyx PC Checkup.exe /quiet /purgedata`

Before removal, the uninstaller attempts to restore every active startup entry disabled by Nyx. Current-user rollback is read from DPAPI; all-users rollback is read from the protected ProgramData machine journal after action-specific UAC. If any restore fails, the uninstaller exits 6 before removing application files, shortcuts, uninstall registration, or recovery data. Normal uninstall leaves no service, driver, task, browser setting, firewall rule, or background process because none is installed.

## Installer exit codes

- `0` success or user-cancelled interactive setup before change
- `10` application is running
- `11` user installation root unavailable
- `12` payload write failure
- `13` rollback boundary failure
- `14` activation failure
- `15` finalization/manifest/registration failure

The uninstaller returns `0` on complete success, `5` when elevation for restore is cancelled/fails, and `6` when one or more startup restores fail.
