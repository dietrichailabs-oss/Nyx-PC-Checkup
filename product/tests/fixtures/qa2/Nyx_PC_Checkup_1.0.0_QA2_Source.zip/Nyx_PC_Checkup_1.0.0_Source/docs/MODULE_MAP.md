# Module Map

| Area | Module | Responsibility |
|---|---|---|
| Shell | `app/NyxPCCheckup.ps1` | Startup, single instance, DPI, global error boundary, shutdown |
| Core | `core/Models.psm1` | Structured result and deterministic summary model |
| Core | `core/Paths.psm1` | Installed/data locations and directory initialization |
| Core | `core/Configuration.psm1` | Defaults, local persistence, corrupt-config recovery |
| Core | `core/Diagnostics.psm1` | Local rotating logs and redaction |
| Core | `core/Privacy.psm1` | Username/path/IP/secret/email redaction |
| Core | `core/CheckupEngine.psm1` | Check isolation and atomic last-scan persistence |
| Core | `core/ActionHistory.psm1` | Action history, DPAPI user state/pointers, bounded active rollback discovery |
| Rules | `health_rules/HealthRules.psm1` | Storage, uptime, battery, performance decisions |
| Rules | `health_rules/rules.json` | Central documented thresholds |
| Checks | `checks/SystemInfo.psm1` | Human-readable system overview |
| Checks | `checks/StorageHealth.psm1` | System-drive free-space state |
| Checks | `checks/StorageScan.psm1` | Bounded user-folder sizes and largest files |
| Checks | `checks/DownloadsAnalysis.psm1` | Age/type/size/duplicate candidate classification |
| Checks | `checks/StartupApps.psm1` | Supported startup entry inventory and state |
| Checks | `checks/WindowsUpdates.psm1` | Pending/restart/history indicators with uncertainty |
| Checks | `checks/SecurityStatus.psm1` | Antivirus, firewall, Secure Boot, TPM, encryption indicators |
| Checks | `checks/BackupStatus.psm1` | File History and Windows Backup indicators |
| Checks | `checks/BatteryHealth.psm1` | Charge/capacity/estimated wear when available |
| Checks | `checks/PerformanceSnapshot.psm1` | One-time CPU, memory, disk, process snapshot |
| Checks | `checks/DriveHealth.psm1` | Windows Storage health/reliability indicators |
| Checks | `checks/InstalledApps.psm1` | Searchable installed-app inventory |
| Checks | `checks/Uptime.psm1` | Uptime and restart-pending interpretation |
| Checks | `checks/NetworkBasics.psm1` | Adapter/profile status and bounded DNS test |
| Checks | `checks/CleanupScan.psm1` | Approved cleanup candidate preview only |
| Actions | `actions/StartupActions.psm1` | Confirmed reversible startup disable/restore |
| Actions | `actions/CleanupActions.psm1` | Confirmed recycle-bin cleanup with revalidation |
| Reports | `reports/ReportExport.psm1` | Privacy-safe report model, preview text, export |
| Reports | `reports/PdfWriter.psm1` | Dependency-free simple PDF summary writer |
| UI | `ui/Theme.psm1` | Dark/light/Follow Windows palettes |
| UI | `ui/Controls.psm1` | Reusable accessible controls and status pills |
| UI | `ui/Dialogs.psm1` | Preview and detail dialogs |
| UI | `ui/MainWindow.psm1` | Navigation, pages, scan progress, explicit actions |
| Workers | `workers/ScanWorker.ps1` | Read-only scan orchestration and cancellation |
| Workers | `workers/ActionWorker.ps1` | Validated action dispatch and isolation |
| Workers | `workers/InstallWorker.ps1` | Payload verification and per-user registration |
| Workers | `workers/UninstallWorker.ps1` | Startup rollback, shortcuts/registry/data cleanup |
| Platform | `platform/windows/WindowsHelpers.psm1` | Windows API helpers and stable IDs |
| Platform | `platform/linux/CONTRACT.md` | Future adapter contract; no Version 1 implementation |
| Native | `native/launcher.cpp` | Native x64 app launcher |
| Native | `native/installer.cpp` | Clean-payload, rollback-capable per-user installer |
| Native | `native/uninstaller.cpp` | Native x64 uninstaller launcher |
