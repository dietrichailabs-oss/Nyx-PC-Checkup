# Architecture — Nyx PC Checkup 1.0.0

## Goals

Nyx PC Checkup is a local-first Windows health utility for normal users. Its architecture separates read-only observation, deterministic interpretation, user interface, privileged/reversible actions, report export, and packaging so a defect in one check does not silently modify the computer or terminate unrelated checks.

## Runtime shape

The installed runtime consists of a small native x64 launcher and a modular Windows PowerShell 5.1 application. The launcher invokes the app from its installed location without requiring an administrator token. The UI is WinForms and uses background worker processes for scans. There is no service, scheduled task, resident tray process, updater, remote account, analytics client, or network upload component.

## Layer boundaries

1. **Native shell** — finds the installed app, starts Windows PowerShell, and returns its exit code. It contains no health logic.
2. **Application shell** — single-instance lifecycle, DPI setup, logging boundary, navigation, global UI state, and error boundary.
3. **Core** — structured result model, paths, configuration recovery, privacy redaction, rotating diagnostics, result aggregation, scan persistence, and action history.
4. **Health rules** — centralized thresholds and deterministic state decisions. UI modules do not own threshold logic.
5. **Read-only checks** — each check returns one or more structured results and is isolated by the check engine.
6. **Workers** — scan and action processes communicate through UUID-named files under the application-owned local temporary directory. Paths, names, sizes, and reparse-point status are validated before use.
7. **Actions** — startup and cleanup operations are separate from scan modules. Each action requires an explicit confirmation marker from the UI and validates current state immediately before changing it.
8. **Reports** — create privacy-minimized TXT, JSON, or simple PDF output only after preview.
9. **Platform adapters** — Windows-specific registry, security, update, startup, recycle-bin, paths, and installer behavior remain outside platform-neutral result/rule contracts.

## Scan flow

`Nyx PC Checkup.exe` → `app/NyxPCCheckup.ps1` → `ui/MainWindow.psm1` → `workers/ScanWorker.ps1`.

The worker imports only read-oriented modules, emits progress as JSON Lines, checks a cancel marker between modules and inside long file scans, preserves partial results, writes a read-only scan envelope, and atomically persists the most recent scan. Individual check failures are converted to **Unknown** results instead of crashing the scan.

Quick Check includes system overview, system-drive space, update indicators, security indicators, startup entries, backup indicators, uptime, and network basics. Full Check adds folder and largest-file analysis, Downloads classification and bounded duplicate candidates, cleanup preview, battery when present, drive health, performance snapshot, and installed applications.

## Action flow

The UI writes a UUID-bound request after showing an exact human confirmation, hashes the exact request bytes, and passes that SHA-256 on the worker command line. `ActionWorker.ps1` reads once, verifies the hash and confirmation marker, then parses only those verified bytes before revalidating the path and operation. This binds an elevated UAC launch to the action the user actually confirmed. It re-enumerates startup entries or cleanup candidates rather than trusting stale UI objects.

Startup disable uses this sequence:

1. Validate the source against the fixed Run-key/Startup-folder allowlist.
2. Confirm the entry still matches the scanned command or file hash.
3. Capture value kind, command, location, elevation requirement, and file hash/length where applicable.
4. For a current-user entry, write and atomically activate a DPAPI CurrentUser-protected rollback journal. For an all-users entry, first write an administrator-owned, inheritance-disabled ProgramData journal; then write a DPAPI CurrentUser pointer containing display identity only.
5. Revalidate the authority boundary and apply the single requested change. Elevated restore obtains source path, value name, command, and file-backup identity only from the protected machine journal, never from the user-writable pointer.
6. Append privacy-safe action history.

A power loss or process interruption after step 4 retains the recovery journal. Restore refuses to overwrite a conflicting registry value or file.

Cleanup uses this sequence:

1. Re-enumerate only approved cleanup roots.
2. Match only selected stable candidate IDs.
3. Revalidate ordinary-file status, reparse-point status, size, and last-write time.
4. Send supported files to the Windows Recycle Bin one at a time.
5. Report exact successes, failures, and bytes moved.

Recycle Bin emptying is explicitly identified and separately handled as irreversible.

## Data layout

Per-user data is beneath `%LOCALAPPDATA%\Dietrich AI Labs\Nyx PC Checkup` and contains validated configuration, rotating logs, the last scan, action history, current-user encrypted startup journals, all-users journal pointers, and a bounded temporary IPC directory. Authoritative all-users rollback state is stored beneath `%ProgramData%\DietrichAI.NyxPCCheckup\startup-rollback` with ACL inheritance disabled and write authority restricted to Administrators and SYSTEM. Normal uninstall preserves user data unless the user explicitly chooses purge; rollback data is never purged when startup restoration fails.

## Packaging

Release staging is allowlist-only. Native setup rejects colliding or reparse-backed staging, rollback, failed, parent, and existing-target paths and creates embedded payload files with create-new semantics. The installer embeds only the staged runtime. It writes to a same-volume temporary directory, verifies the complete payload manifest, creates an upgrade rollback boundary, atomically activates the new payload, captures existing shortcut/uninstall-registration state, creates the new integration, and restores both the prior payload and external integration when finalization fails. Quiet setup suppresses worker dialogs.
