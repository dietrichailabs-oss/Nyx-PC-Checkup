# Known Limitations — Engineering QA Candidate

1. **Windows execution evidence is pending independent QA.** The candidate was produced in a Linux engineering environment. Static source contracts, safety invariants, archive manifests, native PE structure, and clean-package contents were tested there. Actual WinForms rendering, Windows PowerShell 5.1 execution, OS API behavior, installer lifecycle, UAC/ProgramData ACL behavior, DPI scaling, shortcut behavior, and uninstall leftovers must be executed on Windows using the three supplied test scripts and QA matrix.
2. **Unsigned candidate.** The Engineering build has no Authenticode signature and may trigger Windows reputation warnings. Signing belongs after approval and creates a new byte identity requiring final validation.
3. **Windows status APIs are heterogeneous.** Security, update, backup, battery, drive, Secure Boot, TPM, encryption, and reliability information varies by Windows edition, hardware, firmware, permissions, and installed providers. Nyx returns Unknown rather than guessing.
4. **Backup detection is intentionally limited.** Version 1 detects supported File History/Windows Backup indicators and cannot prove that every third-party/cloud backup exists or is restorable.
5. **Update status is not patch assurance.** Nyx reads supported local update/restart/history indicators and opens Windows Update. It does not guarantee that every security update is installed.
6. **Drive health is not a failure guarantee.** Nyx reports Windows Storage health warnings where available; a healthy result means only that no warning was reported.
7. **Duplicate detection is bounded and advisory.** Full Check hashes only bounded same-size candidates under configured size/count limits. Matching content is shown as a candidate and is never automatically removed.
8. **File-system scans are bounded.** Very large profiles, access-denied folders, changing files, offline locations, and reparse points can produce partial results. Completeness is shown.
9. **Network check performs one DNS lookup.** It does not scan devices, capture traffic, inspect browsing history, or change network configuration.
10. **No background monitor.** Version 1 performs manual scans only. Notifications are conservative, in-app, and disabled by default.
11. **No Linux runtime.** The Linux directory documents a future adapter contract only; Version 1 is Windows 10/11 x64.
12. **No automatic remediation.** Updates, antivirus, firewall, backups, installed applications, drivers, services, and network settings remain under Windows/user control.
